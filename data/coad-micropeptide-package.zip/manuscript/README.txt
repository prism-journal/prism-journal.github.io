TCGA-COAD EXPLORATORY MANUSCRIPT

Main deliverable: main.pdf (15 pages)
Editable source: main.tex

BUILD
From this directory, run pdflatex three times to resolve all author-year
citations and figure/table references:

    pdflatex -interaction=nonstopmode -halt-on-error main.tex
    pdflatex -interaction=nonstopmode -halt-on-error main.tex
    pdflatex -interaction=nonstopmode -halt-on-error main.tex

The manuscript was compiled with pdfTeX / TeX Live 2026. It uses the supplied
preamble.tex and PGFPlots 1.18, plus geometry, lmodern, microtype, graphicx,
booktabs, tabularx, array, natbib, caption, and hyperref. All seven figures
are imported as editable TikZ/PGFPlots TeX. No external bitmap is required.
references.tex is a self-contained author-year bibliography; BibTeX is not
needed for this build. references.bib is included for journal conversion.

SOURCE AND NUMERICAL PROVENANCE
results.json is an unchanged copy of the supplied single-marker-follow-up
results. Numeric macros and statistical table rows were generated from it.
regenerate_numbers.py rebuilds these inputs and references.tex using the
frozen metadata; it does not fit models. Results are rounded for reporting.

Original analysis package: ../coad_single_marker_followup/
Original filtering log: ../coad_analysis_extended/audit.log
The requested audit log is copied to provenance/analysis_extended_audit.log.
The numerical audit, single-marker validation, fold-level C-indices, final
coefficient table, retrieved source metadata, figure-data verification,
and successful build log are included under provenance/.

The title follows the supplied title verbatim. The author is Leo Lee. Affiliations, funding, conflicts, and institutional
declarations were not supplied and have not been invented. No corresponding-
author footnote is required by this article template.

REPORTING DECISIONS
- The 93.4th random-panel percentile belongs only to the four-gene panel.
- Only the final full-primary-cohort refit retained LINC00675 alone;
  fold-specific models had varying inclusion of other transcripts.
- Only three-year OS AUC satisfied the retained all-fold support rule.
- The median-split log-rank comparison is descriptive and nonsignificant.
- Bootstrap intervals condition on fitted held-out predictions and do not
  rerun model fitting or post-hoc marker selection.
- The expanded DFI rule allows stages I-IV, but no stage IV patient had
  valid DFI; actual expanded DFI observations are stages I-III.
- Population wording distinguishes recorded race from missing race.
- RNA abundance, peptide abundance, and peptide activity are distinguished.
- Recurrence-specific biology and elastic-net dilution remain hypotheses.
- GSE39582 is proposed validation only; array probe coverage and endpoint
  harmonization must be established before claiming external validation.

FIGURE PRESENTATION
The supplied figures were preserved as TeX inputs. Presentation-only edits
to manuscript copies of figures 1-6 shortened legends, separated marker
labels, improved hazard-ratio ticks, and moved tiny plot notes into captions.
All original plotted data tables and axis coordinates were verified unchanged.
Figure 7 uses the supplied caption-free plot and separate caption file,
including the unadjusted log-rank p-value, as intended by the analysis bundle.
The original annotated figure-7 source is also retained in figures/.

REFERENCE RETRIEVAL
Thirteen original research sources were retrieved through live web search.
The five original marker papers are Ge 2021, Zheng 2023, Li 2020,
Huang 2017, and Zhu 2020. Exact metadata, DOI links, and claim limits appear
in provenance/reference_retrieval.json. Several direct publisher/PMC/GEO
page opens encountered JavaScript, cookie, or reCAPTCHA access challenges;
retrievable indexed original-source content and PubMed records supplied
the evidence. These access limitations are documented in that JSON.

QUALITY CHECKS
All manuscript pages were rendered and visually inspected after the final
successful compile. Figure legends, tick labels, tables, citations, and
references were checked. The final build has no errors, unresolved
references/citations, or overfull boxes. One harmless underfull-box message
arises from the forest-plot input. See validation.json and the build log.

AUTHOR AND DISCLOSURE UPDATE
The author is Leo Lee. The Methods include Use of AI Tools; Acknowledgements
and an AI-writing declaration precede References. These declarations include
author-supplied assertions of human review.
The disclosure explicitly acknowledges AI-assisted drafting and revision of
the Abstract, Discussion, and Conclusion. The Abstract itself has no AI notice.
The author plans to independently rewrite the main sections from the study
data and results before submission; this has not yet occurred. The disclosure
will be reviewed after those revisions. The current AI-assisted sections and
the interim declaration are also supplied as standalone LaTeX blocks.
