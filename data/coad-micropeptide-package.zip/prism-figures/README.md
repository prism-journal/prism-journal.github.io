# Figure drawing code (PRISM, not the author)

`figs.py` redraws all eight figures of the published version in one house style.
The author's original PGFPlots/TikZ sources are untouched, in `manuscript/figures/`.

Nothing is recomputed where it can be read instead:

  * Figures 5 (ROC) and 6 (calibration) parse their coordinates straight out of
    the author's `fig2_roc.tex` and `fig5_calib.tex`, so they plot exactly the
    numbers he published.
  * Figures 2 and 7 rebuild Kaplan-Meier curves from his per-patient held-out
    predictions. The script asserts the resulting group sizes and event counts
    against the ones in his own figure legends (69/6, 68/12, 214/40, 214/53 for
    panel risk; 69/12, 68/6 for the expression median split) and will not draw
    if they disagree.
  * Figures 1, 3 and 4 read his frozen outputs directly.
  * Figure 8 is the journal's own null; see `prism-single-gene-null/`.

Figure 3 is the one that changed meaning rather than appearance. It was a forest
plot of a single coefficient, which is a whole figure spent on one number; it now
shows how often each transcript was retained across the 25 outer folds (23, 18,
16, 12), which is reported in the text and was not plotted anywhere.

Colours are two validated categorical slots - blue #2a78d6 and orange #eb6834 -
which clear the colour-vision-deficiency and contrast checks for every pair used
here, with grey for de-emphasis. Identity is never carried by colour alone: every
two-series panel also has a legend, and the emphasised transcript in Figure 4
carries a background band as well as position.

    python3 -I figs.py
