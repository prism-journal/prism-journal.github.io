"""Redraw the paper's figures in one house style.

The data is not recomputed where it can be read: ROC and calibration coordinates
are parsed straight out of the author's PGFPlots sources, so those panels plot
exactly the numbers he published. Kaplan-Meier curves are rebuilt from his
per-patient held-out predictions and are checked against the group sizes and
event counts in his own legends before anything is drawn.

Colours are the two validated categorical slots (blue, orange) plus greys; the
palette passes the CVD and contrast checks for every pair used here. One series
never gets a legend box, two always do, and emphasis is carried by colour
against grey rather than by eight competing hues.
"""
import json, re, sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

A = Path("/private/tmp/claude-501/-Users-henry-PRISM/"
         "4dd32c8f-d03e-4a4f-8ce5-5606ef9e3171/scratchpad/leo_extract")
NULLDIR = Path("/private/tmp/claude-501/-Users-henry-PRISM/"
               "4dd32c8f-d03e-4a4f-8ce5-5606ef9e3171/scratchpad/leo_null")
OUT = Path("/private/tmp/claude-501/-Users-henry-PRISM/"
           "4dd32c8f-d03e-4a4f-8ce5-5606ef9e3171/scratchpad/leo_build/figures")
PRIM = A / "analysis/cohorts/primary_dfi_stage_ii_iii"
OSC = A / "analysis/cohorts/secondary_os_all_stages"
FIGS = A / "manuscript/figures"

BLUE, ORANGE = "#2a78d6", "#eb6834"
INK, SUB, GRID, GREY = "#1a1a19", "#52514e", "#E6E4E0", "#A9A69F"
FAINT = "#C9C6C0"

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Helvetica Neue", "Helvetica", "Arial", "DejaVu Sans"],
    "font.size": 11.5, "text.color": INK,
    "axes.labelcolor": SUB, "axes.edgecolor": "#CFCCC6", "axes.linewidth": .9,
    "xtick.color": SUB, "ytick.color": SUB, "xtick.labelsize": 10.5,
    "ytick.labelsize": 10.5, "axes.labelsize": 11.5, "axes.titlesize": 12.5,
    "axes.titleweight": "semibold", "axes.titlecolor": INK,
    "figure.facecolor": "white", "axes.facecolor": "white",
    "legend.frameon": False, "legend.fontsize": 10.5,
})


def frame(ax, grid="y"):
    ax.spines[["top", "right"]].set_visible(False)
    if grid:
        ax.grid(axis=grid, color=GRID, linewidth=.8)
        ax.set_axisbelow(True)
    ax.tick_params(length=3.5, width=.9)


def save(fig, n, note=""):
    fig.savefig(OUT / f"figure-{n}.png", dpi=220, facecolor="white",
                bbox_inches="tight", pad_inches=0.16)
    plt.close(fig)
    print(f"  figure-{n}.png  {note}")


def tikz_tables(path):
    src = Path(path).read_text(encoding="utf-8")
    out = []
    for m in re.finditer(r"\\addplot\s*\[([^\]]*)\]\s*\n?table\s*\{%\n(.*?)\n\};", src, re.S):
        rows = []
        for line in m.group(2).strip().split("\n"):
            p = line.split()
            if len(p) >= 2:
                try:
                    rows.append([float(p[0]), float(p[1])])
                except ValueError:
                    pass
        if rows:
            out.append((m.group(1), np.asarray(rows)))
    return out


def km(time, event):
    """Kaplan-Meier with Greenwood log-log pointwise 95% limits."""
    t = np.asarray(time, float); e = np.asarray(event, bool)
    order = np.argsort(t); t, e = t[order], e[order]
    uniq = np.unique(t[e])
    s, cum, S, lo, hi, ts = 1.0, 0.0, [1.0], [1.0], [1.0], [0.0]
    for u in uniq:
        n_at = int((t >= u).sum()); d = int(((t == u) & e).sum())
        if n_at == 0:
            continue
        s *= 1 - d / n_at
        cum += d / (n_at * (n_at - d)) if n_at > d else 0
        ts.append(u); S.append(s)
        if s in (0.0, 1.0) or cum <= 0:
            lo.append(s); hi.append(s)
        else:
            se = np.sqrt(cum) / abs(np.log(s))
            a, b = np.log(-np.log(s)) - 1.96 * se, np.log(-np.log(s)) + 1.96 * se
            lo.append(float(np.exp(-np.exp(b)))); hi.append(float(np.exp(-np.exp(a))))
    return np.array(ts), np.array(S), np.array(lo), np.array(hi)


def km_panel(ax, groups, xlab, ylab, title, xmax, colors=(BLUE, ORANGE),
             legend_loc="lower left"):
    M = 365.25 / 12
    for (lab, t, e), col in zip(groups, colors):
        ts, S, lo, hi = km(t, e)
        tm = ts / M
        ax.step(tm, S, where="post", color=col, linewidth=2.0, zorder=3)
        ax.fill_between(tm, lo, hi, step="post", color=col, alpha=.11, linewidth=0, zorder=1)
        cen = np.sort(np.asarray(t, float)[~np.asarray(e, bool)]) / M
        if len(cen):
            Sc = S[np.clip(np.searchsorted(tm, cen, side="right") - 1, 0, len(S) - 1)]
            ax.plot(cen, Sc, "|", color=col, markersize=5, markeredgewidth=1.1, zorder=4)
        ax.plot([], [], color=col, linewidth=2.0, label=lab)
    ax.legend(loc=legend_loc, handlelength=1.5, borderpad=.3, labelspacing=.5)
    ax.set_xlim(0, xmax); ax.set_ylim(0, 1.03)
    ax.set_xlabel(xlab); ax.set_ylabel(ylab); ax.set_title(title, loc="left", pad=10)
    frame(ax)


# ----------------------------------------------------------------- figure 1
def fig1_panel_null():
    v = pd.read_csv(PRIM / "random_panel_scores.tsv", sep="\t")["c_index"].to_numpy(float)
    C, deg = 0.6087102867051357, int((v == 0.5).sum())
    fig, ax = plt.subplots(figsize=(8.4, 4.9))
    live = v[v != 0.5]
    ax.hist(live, bins=np.arange(.36, .78, .01), color=BLUE, alpha=.85,
            edgecolor="white", linewidth=.6, zorder=2)
    ax.bar(0.5, deg, width=.0092, color=GREY, edgecolor="white", linewidth=.6, zorder=3)
    ax.annotate(f"{deg} panels fitted nothing\nand score exactly 0.500",
                xy=(0.5, deg), xytext=(0.408, deg * .80), color=SUB, fontsize=10.2,
                ha="left", va="top",
                arrowprops=dict(arrowstyle="-", color=GREY, linewidth=1.0,
                                shrinkA=0, shrinkB=4))
    ax.axvline(C, color=ORANGE, linewidth=2.2, zorder=5)
    ax.annotate(f"Micropeptide-source panel\n{C:.3f}  ·  93.4th percentile  ·  $p$ = 0.067",
                xy=(C, deg * .62), xytext=(C - .012, deg * .62), color=ORANGE,
                fontsize=10.8, fontweight="semibold", va="center", ha="right")
    ax.set_xlabel("Held-out Harrell C-index, primary DFI")
    ax.set_ylabel("Random four-gene panels")
    ax.set_title("The panel does not separate from random four-gene panels", loc="left", pad=12)
    ax.set_xlim(.36, .78)
    frame(ax)
    save(fig, 1, f"panel null, {deg} degenerate")


# ----------------------------------------------------------------- figure 2
def _risk_groups(path):
    d = pd.read_csv(path, sep="\t")
    g = d.groupby("patient_id").agg(pct=("risk_percentile", "mean"),
                                    time=("time", "first"), event=("event", "first"))
    med = g.pct.median()
    lo, hi = g[g.pct <= med], g[g.pct > med]
    return lo, hi


def fig2_km_risk():
    lo, hi = _risk_groups(PRIM / "oof_predictions.tsv")
    lo2, hi2 = _risk_groups(OSC / "oof_predictions.tsv")
    for got, want in ((len(lo), 69), (int(lo.event.sum()), 6), (len(hi), 68),
                      (int(hi.event.sum()), 12), (len(lo2), 214), (int(lo2.event.sum()), 40),
                      (len(hi2), 214), (int(hi2.event.sum()), 53)):
        assert got == want, f"risk grouping mismatch: {got} != {want}"
    fig, axes = plt.subplots(1, 2, figsize=(11.4, 4.7))
    km_panel(axes[0], [(f"Lower panel risk  (n = 69, 6 events)", lo.time, lo.event),
                       (f"Higher panel risk  (n = 68, 12 events)", hi.time, hi.event)],
             "Months since diagnosis", "DFI event-free probability",
             "a   Primary DFI, stages II/III", 150)
    km_panel(axes[1], [(f"Lower panel risk  (n = 214, 40 deaths)", lo2.time, lo2.event),
                       (f"Higher panel risk  (n = 214, 53 deaths)", hi2.time, hi2.event)],
             "Months since diagnosis", "Overall survival probability",
             "b   Secondary OS, stages I–IV", 150)
    fig.tight_layout(w_pad=3)
    save(fig, 2, "KM by panel risk (group counts verified)")


# ----------------------------------------------------------------- figure 3
def fig3_retention():
    audit = json.load(open(PRIM / "outer_fold_audit.json"))
    names = {"ENSG00000263429": "LINC00675\nTMEM238L", "ENSG00000233101": "HOXB-AS3",
             "ENSG00000153363": "LINC00467", "ENSG00000236081": "ELFN1-AS1"}
    cnt = {k: 0 for k in names}
    for f in audit:
        for g in f.get("retained", []):
            if g in cnt:
                cnt[g] += 1
    order = sorted(cnt, key=cnt.get, reverse=True)
    vals = [cnt[k] for k in order]
    cols = [ORANGE if k == "ENSG00000263429" else GREY for k in order]
    fig, ax = plt.subplots(figsize=(8.0, 4.3))
    bars = ax.barh([names[k] for k in order][::-1], vals[::-1], color=cols[::-1],
                   height=.62, zorder=3)
    for b, v in zip(bars, vals[::-1]):
        ax.annotate(f"{v} of 25", (v, b.get_y() + b.get_height() / 2),
                    xytext=(7, 0), textcoords="offset points", va="center",
                    fontsize=10.8, color=SUB)
    ax.set_xlim(0, 29); ax.set_xlabel("Outer folds in which the transcript was retained")
    ax.set_title("Only one transcript survived the final refit, but all four were "
                 "used along the way", loc="left", pad=12, fontsize=12)
    ax.annotate("Final full-cohort refit kept LINC00675 alone\n"
                "HR 0.88 per training SD, on a selection-naive interval",
                xy=(.99, .99), xycoords="axes fraction", ha="right", va="top",
                fontsize=10.2, color=SUB)
    frame(ax, grid="x")
    save(fig, 3, f"retention {dict(zip([names[k].split(chr(10))[0] for k in order], vals))}")


# ----------------------------------------------------------------- figure 4
def fig4_single():
    rows = [("LINC00467", .462, .343, .582, .431, .394, .469),
            ("ELFN1-AS1", .367, .305, .436, .588, .519, .655),
            ("LINC00675\nTMEM238L", .700, .583, .819, .502, .435, .563),
            ("HOXB-AS3", .515, .380, .652, .451, .420, .484)]
    fig, ax = plt.subplots(figsize=(10.2, 5.2))
    x = np.arange(len(rows)); w = .33
    ax.axvspan(1.58, 2.42, color="#F4F2EE", zorder=0)
    for k, (off, col, lab, pan) in enumerate(
            [(-w / 2, BLUE, "Primary DFI, stages II/III", .609),
             (w / 2, ORANGE, "All-stage overall survival", .548)]):
        c = [r[1 + 3 * k] for r in rows]
        lo = [r[1 + 3 * k] - r[2 + 3 * k] for r in rows]
        hi = [r[3 + 3 * k] - r[1 + 3 * k] for r in rows]
        ax.bar(x + off, c, w, color=col, alpha=.9, zorder=3, label=lab)
        ax.errorbar(x + off, c, yerr=[lo, hi], fmt="none", ecolor=col,
                    elinewidth=1.5, capsize=4, capthick=1.5, zorder=4)
        ax.axhline(pan, xmax=.80, color=col, linestyle=(0, (5, 4)),
                   linewidth=1.3, zorder=2)
        ax.annotate(f"panel  {pan:.3f}", (3.42, pan), xytext=(0, 0),
                    textcoords="offset points", ha="left", va="center",
                    color=col, fontsize=10)
    ax.axhline(.5, xmax=.80, color=GREY, linewidth=1.1, zorder=2)
    ax.annotate("chance  0.500", (3.42, .5), xytext=(0, 0), textcoords="offset points",
                ha="left", va="center", color=SUB, fontsize=10)
    ax.set_xticks(x); ax.set_xticklabels([r[0] for r in rows])
    ax.set_xlim(-.6, 4.35)
    ax.set_ylim(0, 1.0); ax.set_ylabel("Held-out Harrell C-index")
    ax.set_title("Three of four transcripts are at or below chance for recurrence",
                 loc="left", pad=12)
    ax.legend(loc="upper left", handlelength=1.2, labelspacing=.45,
              borderpad=.4)
    frame(ax)
    save(fig, 4, "single-transcript discrimination")


# ----------------------------------------------------------------- figure 5
def fig5_roc():
    t = tikz_tables(FIGS / "fig2_roc.tex")
    curve = max(t, key=lambda z: len(z[1]))[1]
    fig, ax = plt.subplots(figsize=(6.4, 5.6))
    ax.plot([0, 1], [0, 1], color=GREY, linestyle=(0, (5, 4)), linewidth=1.2, zorder=2)
    ax.plot(curve[:, 0], curve[:, 1], color=BLUE, linewidth=2.2, zorder=3)
    ax.fill_between(curve[:, 0], curve[:, 0], curve[:, 1],
                    where=curve[:, 1] >= curve[:, 0], color=BLUE, alpha=.10,
                    linewidth=0, zorder=1)
    ax.annotate("chance", (.72, .66), color=SUB, fontsize=10.2, rotation=0)
    ax.annotate("3-year overall survival\nAUC 0.543  (95% CI, 0.459–0.620)",
                xy=(.04, .93), xycoords="axes fraction", va="top", color=INK,
                fontsize=11, fontweight="semibold")
    ax.annotate("The only horizon that met the fold-support rules.\n"
                "5-year OS and both DFI horizons were not estimable.",
                xy=(.04, .80), xycoords="axes fraction", va="top", color=SUB, fontsize=10)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.set_xlabel("False-positive rate"); ax.set_ylabel("True-positive rate")
    ax.set_title("Time-dependent discrimination is barely above chance", loc="left", pad=12)
    ax.set_aspect("equal")
    frame(ax, grid=None)
    save(fig, 5, f"ROC, {len(curve)} points parsed")


# ----------------------------------------------------------------- figure 6
def fig6_calib():
    t = tikz_tables(FIGS / "fig5_calib.tex")
    series = [(o, d) for o, d in t if "mark=*" in o]
    bars = [(o, d) for o, d in t if "forget plot" in o]
    fig, ax = plt.subplots(figsize=(6.6, 5.4))
    lim = .48
    ax.plot([0, lim], [0, lim], color=GREY, linestyle=(0, (5, 4)), linewidth=1.2, zorder=2)
    ax.annotate("perfect calibration", (lim * .62, lim * .62), rotation=45,
                color=SUB, fontsize=9.8, ha="center", va="bottom")
    for (o, d), col, lab in zip(series, (BLUE, ORANGE), ("3 years", "5 years")):
        mycol = col
        for ob, db in bars:
            if col == BLUE and "steelblue" not in ob: continue
            if col == ORANGE and "chocolate" not in ob: continue
            if abs(db[0, 0] - db[1, 0]) < 1e-9:
                ax.plot(db[:, 0], db[:, 1], color=mycol, linewidth=1.5, alpha=.9, zorder=3)
        ax.plot(d[:, 0], d[:, 1], "o", color=mycol, markersize=9,
                markeredgecolor="white", markeredgewidth=1.4, zorder=5, label=lab)
    ax.set_xlim(0, lim); ax.set_ylim(0, lim)
    ax.set_xlabel("Mean predicted DFI event probability")
    ax.set_ylabel("Observed (Kaplan–Meier) probability")
    ax.set_title("Descriptive calibration, with the axes on the data", loc="left", pad=12)
    ax.legend(loc="lower right", title=None)
    ax.annotate("Unsupported bins are omitted; intervals are pointwise.\n"
                "This does not establish clinical calibration.",
                xy=(.03, .96), xycoords="axes fraction", va="top", color=SUB, fontsize=9.8)
    ax.set_aspect("equal")
    frame(ax, grid=None)
    save(fig, 6, f"calibration, {len(series)} series parsed")


# ----------------------------------------------------------------- figure 7
def fig7_median_split():
    g = pd.read_csv(PRIM / "linc00675_expression_km_groups.tsv", sep="\t")
    lo = g[g.expression_group == "low"]; hi = g[g.expression_group == "high"]
    for got, want in ((len(lo), 69), (int(lo.event.sum()), 12),
                      (len(hi), 68), (int(hi.event.sum()), 6)):
        assert got == want, f"median-split mismatch: {got} != {want}"
    fig, ax = plt.subplots(figsize=(7.6, 5.0))
    km_panel(ax, [("Low LINC00675  (n = 69, 12 events)", lo.time, lo.event),
                  ("High LINC00675  (n = 68, 6 events)", hi.time, hi.event)],
             "Months since diagnosis", "DFI event-free probability",
             "A post hoc median split does not separate recurrence", 150,
             colors=(ORANGE, BLUE), legend_loc="lower right")
    ax.annotate("log-rank $p$ = 0.115", xy=(.035, .09), xycoords="axes fraction",
                fontsize=11.5, fontweight="semibold", color=INK)
    ax.annotate("Cut at the whole-cohort expression median, for display only;\n"
                "it never entered Cox fitting or cross-validated scoring.",
                xy=(.035, .02), xycoords="axes fraction", fontsize=9.8, color=SUB)
    save(fig, 7, "median split (group counts verified)")


# ----------------------------------------------------------------- figure 8
def fig8_gene_null():
    c = np.asarray(json.load(open(NULLDIR / "null.json"))["c_indices"])
    mask = np.asarray(json.load(open(NULLDIR / "gate_mask.json"))["mask"], bool)
    sub, T = c[mask], 0.7004570122074015
    q99 = float(np.quantile(sub, .99))
    fig, ax = plt.subplots(figsize=(8.4, 4.9))
    ax.hist(sub, bins=np.arange(.30, .78, .0135), color=BLUE, alpha=.85,
            edgecolor="white", linewidth=.6, zorder=2)
    ax.axvline(.5, color=GREY, linewidth=1.2, linestyle=(0, (5, 4)), zorder=3)
    ax.annotate("chance", (.5, ax.get_ylim()[1] * .97), xytext=(-5, 0),
                textcoords="offset points", ha="right", va="top", color=SUB, fontsize=10)
    top = ax.get_ylim()[1]
    ax.set_ylim(0, top * 1.42)
    ax.axvline(q99, color=FAINT, linewidth=1.6, zorder=3)
    ax.annotate(f"99th percentile of the null  {q99:.3f}", (q99, top * 1.04),
                xytext=(-7, 0), textcoords="offset points", ha="right", va="center",
                color=SUB, fontsize=9.8)
    ax.axvline(T, color=ORANGE, linewidth=2.2, zorder=5)
    ax.annotate(f"LINC00675/TMEM238L  {T:.3f}\n"
                f"98.9th percentile  ·  $p$ = 0.014\n"
                f"4.2% once corrected for best-of-four",
                xy=(T, top * 1.30), xytext=(-9, 0),
                textcoords="offset points", ha="right", va="center",
                color=ORANGE, fontsize=10.6, fontweight="semibold")
    ax.set_xlabel("Held-out Harrell C-index, primary DFI")
    ax.set_ylabel(f"Random single genes (n = {len(sub)})")
    ax.set_title("The missing null: random genes matched on measurability",
                 loc="left", pad=12)
    ax.set_xlim(.30, .78)
    frame(ax)
    save(fig, 8, f"gene null, n={len(sub)}, 99th pct {q99:.4f}")


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    print("redrawing:")
    fig1_panel_null(); fig2_km_risk(); fig3_retention(); fig4_single()
    fig5_roc(); fig6_calib(); fig7_median_split(); fig8_gene_null()
    print("done")
