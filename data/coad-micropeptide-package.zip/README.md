# TCGA-COAD manuscript and reproducibility package

This archive contains the editable manuscript, the analysis code used for its frozen results, figure sources, and supporting audits. The manuscript evaluates micropeptide-source **RNA expression**, not measured peptide abundance. The analysis is exploratory and internally validated; GSE39582 is a proposed external-validation resource, not a completed validation.

## Contents

| Directory | Contents and role |
|---|---|
| `manuscript/` | Latest manuscript PDF and LaTeX, author information, bibliography, numerical macros, frozen results, and editable TikZ/PGFPlots figures. |
| `analysis/` | Current `analysis.py`, `survival_metrics.py`, `analysis_figures.py`, `fast_cox.py`, the GDC downloader, requirements, frozen results, logs, cohort outputs, and original analysis figures. Start with `analysis/README.md`. |
| `project_scripts/` | Other project-authored Python scripts, preserving their original relative paths. These include historical implementation, checking, and packaging scripts; they are provenance, not alternative authoritative pipelines. |
| `intermediate_results/` | Saved audits, cross-validation splits, random-panel outputs, gene-ID annotations, and model-result checkpoints. Historical and QA paths are retained separately; they are not additional scientific replications. |

The original expression matrices, raw STAR files, TCGA-CDR workbook, derived expression matrices, Python environments, and TeX runtime are excluded. Selected derived clinical/outcome tables and patient identifiers may remain in the analysis/audit outputs. Obtain the two original input files separately for a full rerun; exact sources, filenames, and SHA-256 hashes are in `analysis/README.md`.

## Rebuild the manuscript

Install a TeX distribution with pdfLaTeX, PGFPlots 1.18, TikZ, `geometry`, `lmodern`, `microtype`, `graphicx`, `booktabs`, `tabularx`, `array`, `natbib`, `caption`, and `hyperref`. From the extracted archive root:

```sh
cd manuscript
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

The bibliography is supplied in `references.tex`, so this build needs no BibTeX step. `references.bib` is retained for journal conversion. The seven figures are TeX inputs; no image-generation service is needed to rebuild them. The existing numerical macros can be used directly. If available in this directory, `python3 regenerate_numbers.py` regenerates numerical macros, table rows, and `references.tex` from the frozen JSON and retrieved-reference metadata; it does not fit models or replace the author block.

## Rerun the analysis

Use Python 3.12 (the original environment used 3.12.14), install `analysis/requirements-analysis.txt`, and retrieve the documented Xena and CDR inputs. From the archive root, after setting up the environment and `data/`:

```sh
.venv/bin/python analysis/analysis.py --data-dir data --output-dir rerun_outputs --work-dir rerun_work --input-scale xena-log2-counts --n-random 1000 --bootstrap 1000 --jobs 8
```

Full nested cross-validation and 3,000 random-panel evaluations can require substantial computation. New output/cache directories preserve the archived results. Platform and dependency differences can affect numerical reproducibility. `analysis/requirements.txt` and the identical ZIP-root `requirements.txt` preserve the exact original environment snapshot; that snapshot contains an unrelated, local-only `artifact_tool_v2` dependency and is not a portable installation target. Use the 10 core pinned packages in `analysis/requirements-analysis.txt` for a fresh analysis environment. `analysis/results.json` records the analysis package versions and input hashes. See the analysis guide before using the included GDC downloader: its patient-column raw-count matrix is **not** a drop-in replacement for the Xena input.

Historical scripts may contain original-workspace paths or depend on excluded input/cache files. The supported rerun entry point is `analysis/analysis.py` with its three adjacent helper modules. Saved audits document checks performed during development; running the main analysis does not automatically rerun every independent audit or reconstruct the complete manuscript layout.

## AI-assistance disclosure

OpenAI Codex assisted with literature retrieval, analysis-code development, numerical and methodological checking, figure preparation, manuscript drafting/editing, and package assembly. Human author names and affiliations are supplied by the user; the AI system is not an author. The listed authors are responsible for reviewing the source data, code, statistical methods, citations, interpretation, authorship and disclosures, and for approving the final submission. AI assistance included drafting and revising the Abstract, Discussion, and Conclusion. Statements in the manuscript about independent human review are author-supplied attestations; they are distinct from the automated checks documented in the included audits. No external clinical validation is claimed. The author plans to independently rewrite the main sections using the study data and results before submission; that rewrite is pending, and the declaration will be reviewed afterward.

## Archive checks and complete inventory

`manifest.sha256.json` records file hashes. `provenance/source_to_archive_manifest.json` maps each copied file to its original project path, and `provenance/package_validation.json` records inclusion/exclusion checks. Every project-authored Python path is preserved under `project_scripts/`, including historical copies. Third-party Python/TeX installations are not project-authored code and are excluded. The source-data exclusions also cover full transformed-expression caches.
