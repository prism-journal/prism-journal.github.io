"""Referee-requested analyses for PRISM-WP-003 (Henry Wang, minor revision).

Major point 1: proportional-hazards diagnostics for the four transcripts, by the
Grambsch-Therneau correlation test on Schoenfeld residuals.

Major point 3: whether LINC00675 is a proxy for stage, by comparing a stage-only
model with stage + LINC00675 on the author's own 25 outer folds.

Major point 2: the best-of-four calibration restated with the sampling scheme
made explicit, and recomputed without replacement since the four candidates are
four distinct genes.

Usage: python3 -I revision.py <matrix.tsv.gz> <archive-root> <out.json>
"""
import json, re, sys
import numpy as np
import pandas as pd

MATRIX, ARCHIVE, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
COHORT = f"{ARCHIVE}/analysis/cohorts/primary_dfi_stage_ii_iii"
MARKERS = {"ENSG00000153363": "LINC00467", "ENSG00000236081": "ELFN1-AS1",
           "ENSG00000263429": "LINC00675/TMEM238L", "ENSG00000233101": "HOXB-AS3"}
SPEC = re.compile(r"TCGA-[A-Z0-9]{2}-[A-Z0-9]{4}-01[A-Z](?:-.*)?")


def cox_efron_mv(Z, time, event, iters=60, tol=1e-11):
    """Newton-Raphson Cox with Efron ties, p covariates. Returns beta and -H."""
    order = np.lexsort((~event, time))
    Z, time, event = Z[order], time[order], event[order]
    n, p = Z.shape
    uniq = np.unique(time[event])
    groups = [(int(np.searchsorted(time, t, "left")),
               np.flatnonzero((time == t) & event)) for t in uniq]
    beta = np.zeros(p)
    for _ in range(iters):
        eta = Z @ beta
        eta -= eta.max()
        w = np.exp(eta)
        Zw = Z * w[:, None]
        cw = np.cumsum(w[::-1])[::-1]
        cZw = np.cumsum(Zw[::-1], axis=0)[::-1]
        cZZw = np.cumsum((Z[:, :, None] * Z[:, None, :]) * w[:, None, None],
                         axis=0)[::-1].cumsum(axis=0)[::-1] if False else None
        # outer-product running sums
        ZZw = np.einsum("ni,nj->nij", Z, Zw)
        cZZw = np.cumsum(ZZw[::-1], axis=0)[::-1]
        g = np.zeros(p); H = np.zeros((p, p))
        for start, D in groups:
            d = len(D)
            S_R, T_R, Q_R = cw[start], cZw[start], cZZw[start]
            S_D, T_D, Q_D = w[D].sum(), Zw[D].sum(0), ZZw[D].sum(0)
            g += Z[D].sum(0)
            for k in range(d):
                f = k / d
                S = S_R - f * S_D
                T = T_R - f * T_D
                Q = Q_R - f * Q_D
                m = T / S
                g -= m
                H += Q / S - np.outer(m, m)
        try:
            step = np.linalg.solve(H, g)
        except np.linalg.LinAlgError:
            break
        beta = beta + step
        if np.max(np.abs(step)) < tol:
            break
    return beta, H


def schoenfeld_ph(z, time, event, transform="rank"):
    """Grambsch-Therneau correlation test for one covariate.

    Statistic  [sum_i (g_i - gbar) r_i]^2 / sum_i (g_i - gbar)^2 V_i  ~ chi2(1),
    with r_i the Schoenfeld residual and V_i the risk-set variance at event i.
    """
    from scipy.stats import chi2
    beta, _ = cox_efron_mv(z[:, None], time, event)
    b = float(beta[0])
    order = np.argsort(time)
    t, e, x = time[order], event[order], z[order]
    ev = np.flatnonzero(e)
    r, V, g = [], [], []
    for i in ev:
        risk = t >= t[i]
        xr = x[risk]
        w = np.exp(b * xr)
        p = w / w.sum()
        mu = float((p * xr).sum())
        r.append(float(x[i] - mu))
        V.append(float((p * (xr - mu) ** 2).sum()))
        g.append(t[i])
    r, V, g = np.asarray(r), np.asarray(V), np.asarray(g)
    if transform == "rank":
        gg = pd.Series(g).rank(method="average").to_numpy(float)
    else:
        gg = g.astype(float)
    gc = gg - gg.mean()
    denom = float((gc ** 2 * V).sum())
    if denom <= 0:
        return dict(beta=b, chisq=float("nan"), p=float("nan"), n_events=len(ev))
    stat = float((gc * r).sum()) ** 2 / denom
    rho = float(np.corrcoef(gc, r / np.sqrt(np.maximum(V, 1e-12)))[0, 1])
    return dict(beta=b, chisq=stat, p=float(chi2.sf(stat, 1)),
                rho=rho, n_events=int(len(ev)))


def concordance(time, event, risk):
    t, e = np.asarray(time, float)[:, None], np.asarray(event, bool)[:, None]
    comp = e & ((t < t.T) | ((t == t.T) & ~e.T))
    i, j = np.where(comp)
    if not len(i):
        return 0.0, 0
    d = np.asarray(risk, float)[i] - np.asarray(risk, float)[j]
    tie = np.abs(d) <= 1e-8
    return float(((d > 0) & ~tie).sum() + .5 * tie.sum()), int(len(i))


# ------------------------------------------------------------------ data
blob = json.load(open(f"{COHORT}/cv_splits.json"))
patients = np.asarray(blob["patient_order"], dtype=str)
splits = blob["splits"]
elig = pd.read_csv(f"{COHORT}/eligible_patients.tsv", sep="\t").set_index(
    "bcr_patient_barcode").loc[patients]
time = elig["DFI.time"].to_numpy(float)
event = elig["DFI"].to_numpy().astype(bool)
stage_raw = elig["ajcc_pathologic_tumor_stage"].astype(str).to_numpy()
# the cohort is stage II/III only; collapse substages to the clinical contrast
stage_iii = np.asarray([s.startswith("Stage III") for s in stage_raw], float)
print(f"cohort {len(patients)} patients, {int(event.sum())} events; "
      f"stage III {int(stage_iii.sum())}, stage II {int((1 - stage_iii).sum())}")

x = pd.read_csv(MATRIX, sep="\t", index_col=0)
x.index = x.index.astype(str).str.replace(r"\.\d+(?=_PAR_Y$|$)", "", regex=True)
primary = sorted(s for s in x.columns if SPEC.fullmatch(s))
sel = pd.DataFrame({"specimen_id": primary}); sel["patient_id"] = sel.specimen_id.str[:12]
ch = sel.loc[~sel.patient_id.duplicated()]
x = x.loc[:, ch.specimen_id.to_numpy()]; x.columns = ch.patient_id.to_numpy()
x = x.loc[:, patients]
vals = np.expm1(x.to_numpy(float) * np.log(2))
cpm = (vals / vals.sum(axis=0)[None, :] * 1e6).T
logx = np.log2(cpm + 1)
genes = x.index.to_numpy(dtype=str)
gi = {g: i for i, g in enumerate(genes)}

res = {}

# ---------------------------------------- major point 1: proportional hazards
print("\nproportional-hazards test (Grambsch-Therneau, rank transform):")
ph = {}
for ens, name in MARKERS.items():
    z = logx[:, gi[ens]]
    z = (z - z.mean()) / z.std()
    out = schoenfeld_ph(z, time, event)
    ph[name] = out
    print(f"  {name:20s} beta {out['beta']:+.4f}  chi2 {out['chisq']:6.3f}  "
          f"p = {out['p']:.3f}  rho {out['rho']:+.3f}")
res["proportional_hazards"] = ph

# ------------------------------- major point 3: is it a proxy for stage?
def heldout_c(build):
    tot = {}
    for sp in splits:
        tr, te = np.asarray(sp["train"]), np.asarray(sp["test"])
        Ztr, Zte = build(tr), build(te)
        keep = Ztr.std(axis=0) > 1e-12
        if not keep.any():
            risk = np.zeros(len(te))
        else:
            mu, sd = Ztr[:, keep].mean(0), Ztr[:, keep].std(0)
            A = (Ztr[:, keep] - mu) / sd
            B = (Zte[:, keep] - mu) / sd
            beta, _ = cox_efron_mv(A, time[tr], event[tr])
            beta[np.abs(beta) < 1e-4] = 0.0
            risk = B @ beta
        num, den = concordance(time[te], event[te], risk)
        s = tot.setdefault(sp["seed"], [0.0, 0])
        s[0] += num; s[1] += den
    return float(np.mean([a / b for a, b in tot.values()]))

L = logx[:, gi["ENSG00000263429"]]
models = {
    "stage only": lambda idx: stage_iii[idx][:, None],
    "LINC00675 only": lambda idx: L[idx][:, None],
    "stage + LINC00675": lambda idx: np.column_stack([stage_iii[idx], L[idx]]),
}
print("\nheld-out C-index on the author's 25 folds:")
cs = {}
for k, f in models.items():
    cs[k] = heldout_c(f)
    print(f"  {k:22s} {cs[k]:.4f}")
print(f"  increment from adding LINC00675 to stage: "
      f"{cs['stage + LINC00675'] - cs['stage only']:+.4f}")
res["stage_adjusted"] = {"c_index": cs,
                         "increment_over_stage": cs["stage + LINC00675"] - cs["stage only"],
                         "events": int(event.sum()),
                         "events_per_variable": round(int(event.sum()) / 2, 1)}

# full-cohort coefficients, for direction and attenuation
Zf = np.column_stack([stage_iii, (L - L.mean()) / L.std()])
bf, Hf = cox_efron_mv(Zf, time, event)
se = np.sqrt(np.diag(np.linalg.inv(Hf)))
bL, _ = cox_efron_mv(((L - L.mean()) / L.std())[:, None], time, event)
print(f"\nfull-cohort Cox, LINC00675 alone      : beta {float(bL[0]):+.4f} "
      f"(HR {np.exp(float(bL[0])):.3f})")
print(f"full-cohort Cox, with stage adjusted  : beta {bf[1]:+.4f} "
      f"(HR {np.exp(bf[1]):.3f}, 95% CI {np.exp(bf[1]-1.96*se[1]):.3f}-{np.exp(bf[1]+1.96*se[1]):.3f})")
print(f"                 stage III coefficient: beta {bf[0]:+.4f} (HR {np.exp(bf[0]):.3f})")
res["full_cohort_cox"] = {
    "linc_alone_beta": float(bL[0]), "linc_alone_hr": float(np.exp(bL[0])),
    "linc_adj_beta": float(bf[1]), "linc_adj_hr": float(np.exp(bf[1])),
    "linc_adj_hr_lo": float(np.exp(bf[1] - 1.96 * se[1])),
    "linc_adj_hr_hi": float(np.exp(bf[1] + 1.96 * se[1])),
    "stage_beta": float(bf[0]), "stage_hr": float(np.exp(bf[0])),
    "attenuation_pct": float(100 * (1 - abs(bf[1]) / abs(float(bL[0])))),
}

# ------------------------------- major point 2: best-of-four, both schemes
c = np.asarray(json.load(open("null.json"))["c_indices"])
mask = np.asarray(json.load(open("gate_mask.json"))["mask"], bool)
sub, T = c[mask], 0.7004570122074015
rng = np.random.default_rng(99)
withrep = sub[rng.integers(0, len(sub), size=(200000, 4))].max(1)
idx = np.argsort(rng.random((200000, len(sub))), axis=1)[:, :4]
without = sub[idx].max(1)
print(f"\nbest-of-four >= {T:.4f}:  with replacement {100*(withrep>=T).mean():.2f}%"
      f"   without replacement {100*(without>=T).mean():.2f}%")
res["best_of_four"] = {
    "with_replacement": float((withrep >= T).mean()),
    "without_replacement": float((without >= T).mean()),
    "ties": "a resample counts when its maximum is >= the observed C-index",
    "resamples": 200000, "pool": int(len(sub)),
}
json.dump(res, open(OUT, "w"), indent=1)
print("\nwritten", OUT)
