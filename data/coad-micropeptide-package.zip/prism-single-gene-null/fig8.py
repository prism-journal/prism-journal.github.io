"""Figure 8: the expression-matched random single-gene null.

Drawn to match the author's existing figures, which are matplot2tikz exports:
same steel blue for the distribution, same chocolate for the marker line, same
dashed grey for chance, same serif type.
"""
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BLUE, ORANGE, GREY = "#2463A6", "#CF6938", "#B0B0B0"
plt.rcParams.update({
    "font.family": "serif", "font.size": 11, "axes.linewidth": .8,
    "axes.edgecolor": "#333333", "xtick.direction": "out", "ytick.direction": "out",
})

c = np.asarray(json.load(open("null.json"))["c_indices"])
ok = np.asarray(json.load(open("gate_mask.json"))["mask"], dtype=bool)
sub, T = c[ok], 0.7004570122074015

fig, ax = plt.subplots(figsize=(7.4, 5.0), dpi=240)
bins = np.arange(0.30, 0.80 + 1e-9, 0.0125)
ax.hist(sub, bins=bins, color=BLUE, edgecolor="white", linewidth=.5,
        label=f"Expression-matched random genes (n={len(sub)})")
ax.axvline(0.5, color=GREY, linestyle="--", linewidth=1.1, label="Chance (0.50)")
ax.axvline(T, color=ORANGE, linewidth=1.6,
           label=f"LINC00675/TMEM238L ({T:.3f})")
q99 = np.quantile(sub, .99)
ax.axvline(q99, color="#555555", linestyle=":", linewidth=1.1,
           label=f"99th percentile of the null ({q99:.3f})")
ax.set_xlabel("Held-out Harrell C-index, primary DFI")
ax.set_ylabel("Number of random genes")
ax.set_title("Random single-gene comparison, genes matched on measurability")
ax.set_xlim(0.30, 0.80)
ax.legend(frameon=False, fontsize=9.5, loc="upper right")
ax.spines[["top", "right"]].set_visible(False)
ax.grid(axis="y", color="#E8E8E8", linewidth=.7)
ax.set_axisbelow(True)
fig.tight_layout()
fig.savefig("figure-8.png", facecolor="white")
print(f"figure-8.png written; n={len(sub)}, >=target {int((sub>=T).sum())}, 99th pct {q99:.4f}")
