"""Restrict the single-gene null to genes that could actually have been candidates.

The author's own caveat on the panel null is that random genes were not matched
to the candidates by expression. Most of the 1,000 random single genes produce no
model at all, which makes 0.700 look more extreme than it should. The measurement
gate is a pure expression criterion with no outcome in it, so restricting the null
to genes that pass it in all 25 folds - as all four candidates do - is a fair
like-for-like comparison.
"""
import json, re, sys
import numpy as np, pandas as pd

MATRIX, ARCHIVE = sys.argv[1], sys.argv[2]
COHORT = f"{ARCHIVE}/analysis/cohorts/primary_dfi_stage_ii_iii"
MARKERS = ["ENSG00000153363", "ENSG00000236081", "ENSG00000263429", "ENSG00000233101"]
SPEC = re.compile(r"TCGA-[A-Z0-9]{2}-[A-Z0-9]{4}-01[A-Z](?:-.*)?")

blob = json.load(open(f"{COHORT}/cv_splits.json"))
patients = np.asarray(blob["patient_order"], dtype=str); splits = blob["splits"]

x = pd.read_csv(MATRIX, sep="\t", index_col=0)
x.index = x.index.astype(str).str.replace(r"\.\d+(?=_PAR_Y$|$)", "", regex=True)
primary = sorted(s for s in x.columns if SPEC.fullmatch(s))
sel = pd.DataFrame({"specimen_id": primary}); sel["patient_id"] = sel.specimen_id.str[:12]
chosen = sel.loc[~sel.patient_id.duplicated()]
x = x.loc[:, chosen.specimen_id.to_numpy()]; x.columns = chosen.patient_id.to_numpy()
x = x.loc[:, patients]
values = np.expm1(x.to_numpy(dtype=np.float64) * np.log(2))
cpm = (values / values.sum(axis=0)[None, :] * 1e6).T
genes = x.index.to_numpy(dtype=str)

gidx = {g: i for i, g in enumerate(genes)}
mark_idx = np.asarray([gidx[g] for g in MARKERS])
rng = np.random.default_rng(20261013)
pool = np.setdiff1d(np.arange(len(genes)), mark_idx)
draw = rng.choice(pool, size=1000, replace=False)

def gate_all_folds(idx):
    ok = np.ones(len(idx), dtype=bool)
    for sp in splits:
        tr = np.asarray(sp["train"])
        ok &= np.mean(cpm[np.ix_(tr, idx)] >= 1.0, axis=0) >= 0.2
    return ok

mk = gate_all_folds(mark_idx)
print(f"  candidates passing the gate in all 25 folds: {int(mk.sum())}/4")
ok = gate_all_folds(draw)
print(f"  random genes passing the gate in all 25 folds: {int(ok.sum())}/1000")

c = np.asarray(json.load(open("null.json"))["c_indices"])
T = 0.7004570122074015
sub = c[ok]
ge = int((sub >= T).sum())
p = (1 + ge) / (len(sub) + 1)
print(f"\n  expression-matched null: n = {len(sub)}")
print(f"    mean {sub.mean():.4f}  median {np.median(sub):.4f}  "
      f"degenerate {int((sub==0.5).sum())} ({(sub==0.5).mean()*100:.1f}%)")
print(f"    >= 0.7005: {ge}  -> one-sided p = {p:.4f}")
print(f"    percentile of LINC00675: {(np.sum(sub<T)+0.5*np.sum(sub==T))/len(sub)*100:.1f}")
for q in (90, 95, 99):
    print(f"    {q}th pct {np.quantile(sub, q/100):.4f}")
r2 = rng.integers(0, len(sub), size=(200000, 4))
b4 = sub[r2].max(axis=1)
print(f"    best of 4 matched genes >= target: {(b4>=T).mean()*100:.2f}%")
json.dump({"n_matched": int(len(sub)), "ge": ge, "p": p,
           "percentile": float((np.sum(sub<T)+0.5*np.sum(sub==T))/len(sub)*100),
           "degenerate": int((sub==0.5).sum()),
           "q90": float(np.quantile(sub,.90)), "q95": float(np.quantile(sub,.95)),
           "q99": float(np.quantile(sub,.99)), "max": float(sub.max()),
           "p_best_of_four": float((b4>=T).mean())}, open("matched.json","w"), indent=1)
