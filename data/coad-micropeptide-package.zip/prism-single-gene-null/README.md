# The random single-gene null (added by PRISM, not by the author)

The submitted study built an empirical null for its four-gene panel and none for
a single gene, which left its headline number — a held-out C-index of 0.700 for
LINC00675/TMEM238L — with nothing to be measured against. This directory holds
the missing comparison. It is the journal's work. The author's material is
everywhere else in the archive and was not modified.

## What it does

`null.py` draws 1,000 genes uniformly from the 60,656 remaining after the four
candidates are removed, and puts each through the author's own frozen fold
assignments, measurement gate, training-only imputation and scaling, unpenalised
univariate Cox fit and concordance rule.

    python3 -I null.py TCGA-COAD.star_counts.tsv.gz <archive-root> null.json

`lifelines` and `scikit-survival` could not be installed in the environment used,
so the per-fold Cox fit (Efron ties) and the Harrell concordance counts are
re-implemented here. The script therefore refuses to emit a null until the
re-implementation reproduces the author's recorded results:

  * all four published single-marker C-indices, to the last decimal recorded;
  * all 100 per-fold C-indices, comparable-pair counts and coefficients
    (4 markers x 25 folds);
  * the archived per-sample library sizes, exactly.

`run.log` is the output of the accepted run. The expression matrix is not
included; download it from the address in the author's `analysis/README.md` and
check its SHA-256 against the hash in his `results.json` before using it, which
`null.py` assumes you have done.

One convention is worth stating because it drives the shape of the result: a
fitted coefficient below 1e-4 in absolute value is set to zero. That is the
author's own RETENTION_THRESHOLD from `analysis.py`. It is why a gene that fits
nothing scores exactly 0.500 rather than some arbitrary value, and it is what
lifelines arrives at by halting its Newton iteration early.

## What it found

Against all 1,000 draws, LINC00675 sits at the 99.7th percentile (p = 0.004).
That overstates the case: 710 of the 1,000 produce no model at all and score
exactly 0.500, so the comparator is 71% inert.

`matched.py` restricts the draws to the 279 that pass the measurement gate in all
25 outer folds, which is what all four candidate transcripts do. That criterion
uses expression only and no outcome. Within it, LINC00675 is at the 98.9th
percentile (p = 0.014), against a null whose own 99th percentile is 0.6993.

Because the marker was reported as the best of four candidates, the honest figure
is the chance that the maximum of four genes drawn from the matched null reaches
0.700. Across 200,000 resamples that is **4.2%**.

So the marker clears its first real test, narrowly, on 18 events, in the cohort
where it was found. It remains untested outside that cohort and against clinical
risk factors.

`fig8.py` draws the matched null; `figure-8.png` is Figure 8 of the paper.
