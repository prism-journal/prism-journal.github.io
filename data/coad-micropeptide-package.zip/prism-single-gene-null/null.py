"""The random single-gene null the study never computed.

Section 10 of the paper names this as the decisive missing comparison: the
four-gene panel has an empirical null, LINC00675 alone has none, so its 0.700
has nothing to be measured against. This computes it, reusing the author's own
frozen folds, his gate, his preprocessing and his scoring rule.

lifelines and scikit-survival are not installable here, so the per-fold Cox fit
and the concordance count are re-implemented and then *validated* against the
author's recorded per-fold coefficients, C-indices and comparable-pair counts
for all four markers across all 25 folds. If those 100 rows do not reproduce,
the null is not comparable and the script refuses to emit one.

Usage: python3 -I null.py <matrix.tsv.gz> <archive-root> <out.json>
"""
import json, re, sys
import numpy as np
import pandas as pd

MATRIX, ARCHIVE, OUT = (sys.argv[1], sys.argv[2], sys.argv[3])
COHORT = f"{ARCHIVE}/analysis/cohorts/primary_dfi_stage_ii_iii"
MARKERS = {"ENSG00000153363": "LINC00467", "ENSG00000236081": "ELFN1-AS1",
           "ENSG00000263429": "LINC00675/TMEM238L", "ENSG00000233101": "HOXB-AS3"}
SPEC = re.compile(r"TCGA-[A-Z0-9]{2}-[A-Z0-9]{4}-01[A-Z](?:-.*)?")


def load_expression(patients):
    """Reproduce the author's specimen selection and sample-local CPM exactly."""
    x = pd.read_csv(MATRIX, sep="\t", index_col=0)
    x.index = x.index.astype(str).str.replace(r"\.\d+(?=_PAR_Y$|$)", "", regex=True)
    primary = sorted(s for s in x.columns if SPEC.fullmatch(s))
    sel = pd.DataFrame({"specimen_id": primary})
    sel["patient_id"] = sel.specimen_id.str[:12]
    chosen = sel.loc[~sel.patient_id.duplicated()]
    x = x.loc[:, chosen.specimen_id.to_numpy()]
    x.columns = chosen.patient_id.to_numpy()
    x = x.loc[:, patients]
    values = np.expm1(x.to_numpy(dtype=np.float64) * np.log(2))
    library = values.sum(axis=0)
    cpm = (values / library[None, :] * 1e6).T
    return cpm, np.log2(cpm + 1), x.index.to_numpy(dtype=str), library


def cox_efron(z, time, event, iters=40, tol=1e-10):
    """Newton-Raphson univariate Cox with Efron ties, vectorised across columns."""
    order = np.lexsort((~event, time))
    z, time, event = z[order], time[order], event[order]
    n, G = z.shape
    uniq = np.unique(time[event])
    groups = []
    for t in uniq:
        start = int(np.searchsorted(time, t, side="left"))
        D = np.flatnonzero((time == t) & event)
        groups.append((start, D, len(D)))
    beta = np.zeros(G)
    for _ in range(iters):
        eta = z * beta
        eta -= eta.max(axis=0, keepdims=True)          # overflow guard; cancels out
        w = np.exp(eta)
        zw, z2w = z * w, z * z * w
        cw = np.cumsum(w[::-1], axis=0)[::-1]
        czw = np.cumsum(zw[::-1], axis=0)[::-1]
        cz2w = np.cumsum(z2w[::-1], axis=0)[::-1]
        grad = np.zeros(G); hess = np.zeros(G)
        for start, D, d in groups:
            S_R, T_R, Q_R = cw[start], czw[start], cz2w[start]
            S_D, T_D, Q_D = w[D].sum(0), zw[D].sum(0), z2w[D].sum(0)
            grad += z[D].sum(0)
            k = np.arange(d)[:, None] / d
            S = S_R[None, :] - k * S_D[None, :]
            T = T_R[None, :] - k * T_D[None, :]
            Q = Q_R[None, :] - k * Q_D[None, :]
            ratio = T / S
            grad -= ratio.sum(0)
            hess -= (Q / S - ratio ** 2).sum(0)
        step = np.where(np.abs(hess) > 1e-12, grad / np.where(hess == 0, 1, hess), 0.0)
        beta = beta - step
        if np.nanmax(np.abs(step)) < tol:
            break
    return beta


def concordance(time, event, risk):
    """Harrell numerator and comparable-pair denominator, vectorised over columns."""
    t, e = time[:, None], event[:, None]
    comparable = e & ((t < t.T) | ((t == t.T) & ~e.T))
    i, j = np.where(comparable)
    if not len(i):
        return np.zeros(risk.shape[1]), 0
    d = risk[i] - risk[j]
    tie = np.abs(d) <= 1e-8
    conc = (d > 0) & ~tie
    return conc.sum(0) + 0.5 * tie.sum(0), len(i)


def score_genes(cols_idx, cpm, logx, y, splits):
    """Per-fold held-out C for each column, then pair-weight within seed and average."""
    G = len(cols_idx)
    totals = {}
    perfold = []
    for sp in splits:
        tr, te = np.asarray(sp["train"]), np.asarray(sp["test"])
        a, b = logx[np.ix_(tr, cols_idx)], logx[np.ix_(te, cols_idx)]
        gate = (np.mean(cpm[np.ix_(tr, cols_idx)] >= 1.0, axis=0) >= 0.2) & np.isfinite(a).any(axis=0)
        med = np.nanmedian(np.where(np.isfinite(a), a, np.nan), axis=0)
        a = np.where(np.isfinite(a), a, med); b = np.where(np.isfinite(b), b, med)
        mu, sd = a.mean(axis=0), a.std(axis=0)
        live = gate & (sd > 1e-12)
        za = np.zeros_like(a); zb = np.zeros_like(b)
        za[:, live] = (a[:, live] - mu[live]) / sd[live]
        zb[:, live] = (b[:, live] - mu[live]) / sd[live]
        beta = np.zeros(G)
        if live.any():
            beta[live] = cox_efron(za[:, live], y.time.to_numpy()[tr], y.event.to_numpy()[tr])
        # The author's own convention, RETENTION_THRESHOLD in analysis.py: a coefficient
        # this small is numerical noise and must not manufacture a ranking for what is
        # effectively an empty model. lifelines reaches the same place by halting its
        # Newton iteration early, which is why the archive records exact zeros and why a
        # quarter of the random four-gene panels score exactly 0.500.
        beta[np.abs(beta) < 1e-4] = 0.0
        risk = zb * beta[None, :]
        risk[:, ~live] = 0.0
        num, den = concordance(y.time.to_numpy()[te], y.event.to_numpy()[te], risk)
        totals.setdefault(sp["seed"], np.zeros((2, G)))
        totals[sp["seed"]][0] += num
        totals[sp["seed"]][1] += den
        perfold.append({"seed": sp["seed"], "fold": sp["fold"], "den": int(den),
                        "num": num, "beta": beta, "live": live})
    c = np.mean([t[0] / t[1] for t in totals.values()], axis=0)
    return c, perfold


splits_blob = json.load(open(f"{COHORT}/cv_splits.json"))
patients = np.asarray(splits_blob["patient_order"], dtype=str)
splits = splits_blob["splits"]
elig = pd.read_csv(f"{COHORT}/eligible_patients.tsv", sep="\t")
elig = elig.set_index("bcr_patient_barcode").loc[patients]
y = pd.DataFrame({"time": elig["DFI.time"].to_numpy(float),
                  "event": elig["DFI"].to_numpy().astype(bool)})
print(f"cohort: {len(patients)} patients, {int(y.event.sum())} events, {len(splits)} splits")

cpm, logx, genes, library = load_expression(patients)
print(f"matrix: {len(genes)} genes x {len(patients)} selected specimens")
lib_ref = elig["library_size_recovered_counts"].to_numpy(float)
lib_err = np.max(np.abs(library - lib_ref) / lib_ref)
print(f"library sizes vs archive: max relative error {lib_err:.3e}")
if lib_err > 1e-9:
    sys.exit("specimen selection does not reproduce the archived library sizes")

# ---------------------------------------------------------------- validation
gidx = {g: i for i, g in enumerate(genes)}
cols_idx = np.asarray([gidx[g] for g in MARKERS])
cmark, perfold = score_genes(cols_idx, cpm, logx, y, splits)
ref_rows = pd.read_csv(f"{COHORT}/single_marker_fold_cindices.tsv", sep="\t")
bad = 0
for k, ens in enumerate(MARKERS):
    ref = json.load(open(f"{COHORT}/single_markers/{ens}_folds.json"))
    for f, r in zip(perfold, ref):
        assert (f["seed"], f["fold"]) == (r["seed"], r["fold"])
        cmine = f["num"][k] / f["den"] if f["den"] else None
        if r["c_index"] is not None and abs(cmine - r["c_index"]) > 1e-9: bad += 1
        if f["den"] != r["comparable_pairs"]: bad += 1
        # C-index and pair counts must match exactly. Coefficients are allowed a looser
        # tolerance: lifelines stops its Newton iteration on a decrement criterion, so it
        # lands a little short of the optimum on well-determined folds. That shifts no
        # ranking, hence no C-index.
        if r["coefficient"] is not None and abs(f["beta"][k] - r["coefficient"]) > 2e-3: bad += 1
print(f"validation: {len(MARKERS)*len(splits)} folds checked, {bad} mismatches")
pub = {"ENSG00000153363": 0.4621138032195014, "ENSG00000236081": 0.3669170498603873,
       "ENSG00000263429": 0.7004570122074015, "ENSG00000233101": 0.5152539749956194}
for k, ens in enumerate(MARKERS):
    print(f"  {MARKERS[ens]:20s} mine {cmark[k]:.10f}  archive {pub[ens]:.10f}  "
          f"d={abs(cmark[k]-pub[ens]):.2e}")
if bad or max(abs(cmark[k] - pub[e]) for k, e in enumerate(MARKERS)) > 1e-9:
    sys.exit("re-implementation does not reproduce the archive; refusing to emit a null")
print("re-implementation reproduces the archive exactly\n")

# ------------------------------------------------------------------ the null
rng = np.random.default_rng(20261013)
pool = np.setdiff1d(np.arange(len(genes)), cols_idx)
draw = rng.choice(pool, size=1000, replace=False)
CH = 100
cs = []
for s in range(0, len(draw), CH):
    chunk = draw[s:s + CH]
    c, _ = score_genes(chunk, cpm, logx, y, splits)
    cs.append(c)
    print(f"  scored {s + len(chunk):4d}/1000 random genes", flush=True)
cs = np.concatenate(cs)
target = pub["ENSG00000263429"]
ge = int((cs >= target).sum())
res = {
    "n_random_genes": int(len(cs)), "target_marker": "LINC00675/TMEM238L",
    "target_c_index": target,
    "random_mean": float(cs.mean()), "random_median": float(np.median(cs)),
    "random_sd": float(cs.std(ddof=1)),
    "degenerate_exactly_half": int((cs == 0.5).sum()),
    "n_ge_target": ge,
    "percentile_of_target": float((np.sum(cs < target) + 0.5 * np.sum(cs == target)) / len(cs) * 100),
    "one_sided_empirical_p": float((1 + ge) / (len(cs) + 1)),
    "quantiles": {q: float(np.quantile(cs, q / 100)) for q in (50, 75, 90, 95, 99)},
    "max_random": float(cs.max()),
    "seed": 20261013,
}
json.dump({"summary": res, "c_indices": cs.tolist()}, open(OUT, "w"), indent=1)
print("\n" + json.dumps(res, indent=1))
