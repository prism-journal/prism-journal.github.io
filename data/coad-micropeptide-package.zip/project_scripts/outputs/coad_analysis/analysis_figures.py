"""Publication-oriented plots for internally validated TCGA-COAD DFI models.

The calling analysis supplies all predictions and metric estimates.  This module
does not refit a prediction model or silently replace unavailable estimates.
Exports use the maintained ``matplot2tikz`` package directly:
https://github.com/ErwindeGelder/matplot2tikz
"""

from __future__ import annotations

from pathlib import Path
import re
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplot2tikz
import numpy as np
import pandas as pd
from lifelines import KaplanMeierFitter


BLUE = "#2463a6"
ORANGE = "#cf6938"
GREY = "#697581"
DAYS_PER_MONTH = 365.25 / 12.0


def _axes(title: str, xlabel: str, ylabel: str):
    fig, ax = plt.subplots(figsize=(7.2, 5.5))
    ax.set(title=title, xlabel=xlabel, ylabel=ylabel)
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color="#e8e8e8", linewidth=0.6)
    ax.set_axisbelow(True)
    return fig, ax


def _note(ax, text: str) -> None:
    ax.text(
        0.0,
        -0.21,
        text,
        ha="left",
        va="top",
        transform=ax.transAxes,
        fontsize=8,
        color=GREY,
        clip_on=False,
    )


def _save(fig, directory: Path, stem: str) -> dict[str, str]:
    fig.tight_layout()
    png = directory / f"{stem}.png"
    tex = directory / f"{stem}.tex"
    fig.savefig(png, dpi=180, bbox_inches="tight", facecolor="white")
    # matplot2tikz leaves prose verbatim. Escape ordinary text only after the
    # PNG has been saved; raw '%' would otherwise comment out the TeX line.
    # Explicit TeX line breaks also preserve the two-line explanatory notes.
    for artist in fig.findobj(matplotlib.text.Text):
        content = artist.get_text()
        if "$" not in content:
            content = re.sub(r"(?<!\\)([%&#_])", r"\\\1", content)
            content = content.replace("\n", r"\\")
            artist.set_text(content)
    # Data remain embedded in .tex, so the file can be moved without sidecars.
    matplot2tikz.save(
        tex,
        figure=fig,
        encoding="utf-8",
        axis_width="12cm",
        axis_height="8cm",
        externalize_tables=False,
        strict=True,
        extra_axis_parameters=["clip=false"],
        extra_tikzpicture_parameters=["every node/.append style={align=left}"],
        float_format=".8g",
    )
    plt.close(fig)
    return {"png": str(png), "tex": str(tex)}


def _plot_km(directory: Path, patients: pd.DataFrame) -> dict[str, Any]:
    needed = ["time", "event", "risk_percentile"]
    d = patients.dropna(subset=needed).copy()
    fig, ax = _axes(
        "DFI by internally validated risk group",
        "Time from DFI origin (months)",
        "Probability of remaining DFI event-free",
    )
    threshold = float(d["risk_percentile"].median()) if len(d) else np.nan
    high = d["risk_percentile"].gt(threshold)
    group_info = {}
    if d.empty or high.nunique() < 2:
        ax.text(0.5, 0.5, "Risk groups not separable", transform=ax.transAxes,
                ha="center", va="center")
        status = "not_estimable"
    else:
        status = "ok"
        for flag, label, color in [(False, "Low risk", BLUE), (True, "High risk", ORANGE)]:
            group = d.loc[high.eq(flag)]
            label_text = f"{label} (n={len(group)}, events={int(group['event'].sum())})"
            km = KaplanMeierFitter(alpha=0.05)
            km.fit(group["time"].to_numpy() / DAYS_PER_MONTH,
                   event_observed=group["event"].astype(bool).to_numpy())
            sf = km.survival_function_.iloc[:, 0]
            ci = km.confidence_interval_survival_function_
            ax.step(sf.index, sf.to_numpy(), where="post", label=label_text,
                    color=color, linewidth=1.8)
            ax.fill_between(ci.index, ci.iloc[:, 0], ci.iloc[:, 1], step="post",
                            color=color, alpha=0.12, linewidth=0)
            # Mark actual censoring times rather than arbitrary regular ticks.
            censored = km.event_table.loc[km.event_table["censored"].gt(0)].index
            if len(censored):
                ax.plot(censored, km.predict(censored), "+", color=color,
                        markersize=4, markeredgewidth=0.6)
            group_info[label] = {"n": len(group), "events": int(group["event"].sum())}
        ax.legend(loc="lower left", frameon=False, fontsize=9)
    ax.set_ylim(0, 1.02)
    ax.set_xlim(left=0)
    _note(ax, "Repeated out-of-fold predictions; median split is descriptive.\n"
              "Shading: pointwise KM 95% CI; + marks censoring. No external validation.")
    return {**_save(fig, directory, "fig1_km"), "status": status,
            "median_risk_percentile": threshold, "groups": group_info}


def _plot_roc(directory: Path, roc: dict) -> dict[str, Any]:
    fig, ax = _axes("Cumulative/dynamic DFI ROC", "False-positive rate", "True-positive rate")
    ax.plot([0, 1], [0, 1], linestyle="--", color=GREY, linewidth=0.9, label="Chance")
    unsupported = []
    for horizon, color in [("36", BLUE), ("60", ORANGE)]:
        curve = roc.get(horizon, roc.get(int(horizon), {}))
        fpr = np.asarray(curve.get("fpr", []), dtype=float)
        tpr = np.asarray(curve.get("tpr", []), dtype=float)
        auc = curve.get("auc")
        if (len(fpr) and len(fpr) == len(tpr) and auc is not None
                and np.isfinite(float(auc)) and np.isfinite(fpr).all() and np.isfinite(tpr).all()):
            ax.plot(fpr, tpr, color=color, linewidth=1.8,
                    label=f"{horizon} months (AUC={float(auc):.3f})")
        else:
            unsupported.append(f"{horizon} months: not estimable")
    ax.set(xlim=(0, 1), ylim=(0, 1.02))
    ax.legend(loc="lower right", frameon=False)
    if unsupported:
        ax.text(0.04, 0.95, "\n".join(unsupported), transform=ax.transAxes,
                va="top", fontsize=9, color=GREY)
    _note(ax, "IPCW estimated from outer training folds; ROC summarizes held-out folds.\n"
              "Repeated nested cross-validation is internal validation.")
    return {**_save(fig, directory, "fig2_roc"), "unsupported": unsupported}


def _plot_forest(directory: Path, forest: pd.DataFrame) -> dict[str, Any]:
    fig, ax = _axes("Exploratory final-model coefficients", "Hazard ratio per training SD", "")
    ax.axvline(1.0, color=GREY, linestyle="--", linewidth=0.9)
    if forest.empty:
        ax.text(0.5, 0.5, "No transcript retained", transform=ax.transAxes,
                ha="center", va="center")
        ax.set(xlim=(0.5, 2), yticks=[])
    else:
        d = forest.copy().reset_index(drop=True)
        valid = np.isfinite(d[["hr", "lower", "upper"]]).all(axis=1)
        valid &= d[["hr", "lower", "upper"]].gt(0).all(axis=1)
        d = d.loc[valid].reset_index(drop=True)
        y = np.arange(len(d))
        labels = d["marker"].astype(str).tolist()
        for i, row in d.iterrows():
            ax.plot([row["lower"], row["upper"]], [i, i], color=BLUE, linewidth=1.5)
            ax.plot([row["hr"]], [i], "s", color=BLUE, markersize=6)
            ax.plot([row["lower"], row["lower"]], [i-0.07, i+0.07], color=BLUE)
            ax.plot([row["upper"], row["upper"]], [i-0.07, i+0.07], color=BLUE)
        ax.set_yticks(y, labels=labels)
        ax.set_ylim(-0.7, max(len(d)-0.3, 0.7))
        ax.invert_yaxis()
        ax.set_xscale("log")
        if d.empty:
            ax.text(0.5, 0.5, "Finite coefficient intervals unavailable",
                    transform=ax.transAxes, ha="center")
    _note(ax, "Full eligible-cohort refit after tuning; elastic-net estimates are shrunken.\n"
              "Wald intervals are descriptive and do not account for model selection.")
    return _save(fig, directory, "fig3_forest")


def _plot_null(directory: Path, null_cindices, real_cindex: float) -> dict[str, Any]:
    values = np.asarray(null_cindices, dtype=float)
    values = values[np.isfinite(values)]
    fig, ax = _axes("Random four-gene panel comparison", "Held-out Harrell C-index", "Number of random panels")
    if len(values):
        ax.hist(values, bins=min(35, max(5, int(np.sqrt(len(values))))),
                color=BLUE, alpha=0.78, edgecolor="white", linewidth=0.5,
                label=f"Random panels (n={len(values)})")
    if real_cindex is not None and np.isfinite(real_cindex):
        ax.axvline(real_cindex, color=ORANGE, linewidth=2.2,
                   label=f"Micropeptide-source panel ({real_cindex:.3f})")
    ax.axvline(0.5, color=GREY, linewidth=1, linestyle="--", label="Chance (0.50)")
    ax.legend(loc="upper right", frameon=True, framealpha=0.95,
              facecolor="white", edgecolor="none", fontsize=9)
    _note(ax, "Same nested cross-validation and fold-specific preprocessing for all panels.\n"
              "Random panels are an empirical comparator, not assumed to score 0.50.")
    return {**_save(fig, directory, "fig4_null"), "finite_random_panels": len(values)}


def _plot_calibration(directory: Path, calibration: dict) -> dict[str, Any]:
    fig, ax = _axes("Descriptive calibration of DFI event risk",
                    "Mean held-out predicted DFI event probability", "KM-estimated DFI event probability")
    ax.plot([0, 1], [0, 1], linestyle="--", color=GREY, linewidth=0.9,
            label="Ideal calibration")
    unsupported = []
    for horizon, color in [("36", BLUE), ("60", ORANGE)]:
        data = calibration.get(horizon, calibration.get(int(horizon), {}))
        points = data.get("points", [])
        valid = [p for p in points if all(p.get(k) is not None and np.isfinite(p[k])
                                        for k in ["predicted", "observed", "lower", "upper"])]
        if not valid:
            unsupported.append(f"{horizon} months: not estimable")
            continue
        valid.sort(key=lambda p: p["predicted"])
        pred = np.array([p["predicted"] for p in valid])
        obs = np.array([p["observed"] for p in valid])
        low = np.array([p["lower"] for p in valid])
        high = np.array([p["upper"] for p in valid])
        ax.plot(pred, obs, "o-", color=color, linewidth=1.5,
                markersize=5, label=f"{horizon} months")
        # Draw intervals as ordinary line artists for reliable PGFPlots export.
        for p, o, lo, hi in zip(pred, obs, low, high):
            ax.plot([p, p], [lo, hi], color=color, linewidth=1)
            ax.plot([p-0.006, p+0.006], [lo, lo], color=color, linewidth=1)
            ax.plot([p-0.006, p+0.006], [hi, hi], color=color, linewidth=1)
    if unsupported:
        ax.text(0.04, 0.96, "\n".join(unsupported), transform=ax.transAxes,
                va="top", fontsize=9, color=GREY)
    ax.set(xlim=(0, 1), ylim=(0, 1.02))
    ax.legend(loc="lower right", frameon=False, fontsize=9)
    _note(ax, "Patient-level predictions averaged across held-out repeats; descriptive risk bins.\n"
              "Bars: pointwise KM 95% CI. Unsupported bins are omitted.")
    return {**_save(fig, directory, "fig5_calib"), "unsupported": unsupported}


def write_preamble(path: str | Path) -> str:
    """Write packages needed by the generated PGFPlots figures."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        "% Include this file in the LaTeX document preamble.\n"
        "% Include figures in the body with \\input{figures/fig1_km.tex}.\n"
        "\\usepackage[T1]{fontenc}\n"
        "\\usepackage[utf8]{inputenc}\n"
        "\\usepackage{amsmath}\n"
        "\\usepackage{xcolor}\n"
        "\\usepackage{tikz}\n"
        "\\usepackage{pgfplots}\n"
        "\\usepgfplotslibrary{groupplots,dateplot,fillbetween}\n"
        "\\usetikzlibrary{patterns,shapes.arrows,plotmarks}\n"
        "\\pgfplotsset{compat=1.18}\n"
        "\\DeclareUnicodeCharacter{2212}{\\ensuremath{-}}\n",
        encoding="utf-8",
    )
    return str(path)


def export_figures(
    figures_dir: str | Path,
    plotting_data: dict[str, Any],
    forest_df: pd.DataFrame,
    null_cindices,
    real_cindex: float,
    preamble_path: str | Path | None = None,
) -> dict[str, Any]:
    """Save the five requested PNG/TikZ figures and their PGFPlots preamble.

    ``plotting_data`` is the second result of ``evaluate_oof`` and contains
    ``patients``, ``roc``, and ``calibration``.  Patients have columns ``time``
    (DFI days), ``event``, ``risk_percentile``, ``s36`` and ``s60``. The source of
    those predictions must be outer test folds. ``forest_df`` contains columns
    ``marker``, ``ensembl``, ``coef``, ``hr``, ``lower``, ``upper`` for retained
    coefficients in the standardized full-cohort refit.
    """
    directory = Path(figures_dir)
    directory.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 10,
        "axes.titlesize": 12, "axes.labelsize": 10,
        "legend.fontsize": 9, "axes.unicode_minus": False,
    })
    paths = {
        "km": _plot_km(directory, plotting_data["patients"]),
        "roc": _plot_roc(directory, plotting_data.get("roc", {})),
        "forest": _plot_forest(directory, forest_df),
        "null": _plot_null(directory, null_cindices, real_cindex),
        "calibration": _plot_calibration(directory, plotting_data.get("calibration", {})),
    }
    preamble = Path(preamble_path) if preamble_path is not None else directory.parent / "preamble.tex"
    paths["preamble"] = write_preamble(preamble)
    return paths
