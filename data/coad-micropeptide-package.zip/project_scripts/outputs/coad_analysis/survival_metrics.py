"""Held-out DFI evaluation, with no cross-fold risk comparisons.

Times are in days. Each patient has exactly one OOF prediction per CV seed.
``fold_training[(seed, fold)]`` supplies the training outcomes (time, event).
Bootstrap intervals condition on fitted models and training censoring estimates;
they do not repeat model selection and are not external-validation intervals.

Primary references, retrieved 2026-10-13:
https://scikit-survival.readthedocs.io/en/stable/api/generated/sksurv.metrics.cumulative_dynamic_auc.html
https://scikit-survival.readthedocs.io/en/stable/api/generated/sksurv.metrics.concordance_index_censored.html
https://scikit-survival.readthedocs.io/en/stable/api/generated/sksurv.nonparametric.kaplan_meier_estimator.html
"""

from __future__ import annotations

from collections import defaultdict
from typing import Mapping

import numpy as np
import pandas as pd
from lifelines import KaplanMeierFitter
from sklearn.metrics import roc_curve
from sksurv.metrics import concordance_index_censored, cumulative_dynamic_auc
from sksurv.nonparametric import CensoringDistributionEstimator, kaplan_meier_estimator
from sksurv.util import Surv


DEFAULT_HORIZONS = {"36": 3.0 * 365.25, "60": 5.0 * 365.25}
SUPPORT_RULES = {
    "minimum_test_cases": 3,
    "minimum_test_controls": 5,
    "minimum_training_beyond_horizon": 10,
    "minimum_training_censoring_survival": 0.05,
    "required_supported_outer_folds": "all",
}


def _surv(frame):
    return Surv.from_arrays(frame["event"].to_numpy(bool), frame["time"].to_numpy(float))


def concordance_counts(time, event, risk):
    """Return Harrell concordance numerator and comparable-pair denominator."""
    try:
        _, concordant, discordant, tied_risk, _ = concordance_index_censored(
            np.asarray(event, bool), np.asarray(time, float), np.asarray(risk, float)
        )
    except ValueError:
        return 0.0, 0.0
    return float(concordant + 0.5 * tied_risk), float(concordant + discordant + tied_risk)


def primary_c_index(oof):
    """Pair-weight folds within each seed, then average the seed estimates."""
    totals = defaultdict(lambda: np.zeros(2, dtype=float))
    for (seed, _), frame in oof.groupby(["seed", "fold"], sort=True):
        totals[seed] += concordance_counts(frame.time, frame.event, frame.risk)
    if not totals or any(v[1] <= 0 for v in totals.values()):
        return float("nan")
    return float(np.mean([v[0] / v[1] for v in totals.values()]))


def _concordance_pairs(frame, patient_index):
    time = frame["time"].to_numpy(float)
    event = frame["event"].to_numpy(bool)
    risk = frame["risk"].to_numpy(float)
    comparable = event[:, None] & (
        (time[:, None] < time[None, :])
        | ((time[:, None] == time[None, :]) & ~event[None, :])
    )
    i, j = np.where(comparable)
    difference = risk[i] - risk[j]
    ties = np.abs(difference) <= 1e-8
    success = np.where(ties, 0.5, difference > 0).astype(float)
    ids = frame["patient_id"].map(patient_index).to_numpy(int)
    return ids[i], ids[j], success, np.ones(len(i), dtype=float)


def _combine_pairs(parts):
    return tuple(np.concatenate([part[k] for part in parts]) for k in range(4))


def _estimate_from_pairs(pairs_by_seed, multiplicity=None):
    estimates = []
    for i, j, concordant, base_weight in pairs_by_seed.values():
        weight = base_weight if multiplicity is None else base_weight * multiplicity[i] * multiplicity[j]
        denominator = weight.sum()
        if denominator <= 0:
            return float("nan")
        estimates.append(float(np.dot(weight, concordant) / denominator))
    return float(np.mean(estimates)) if estimates else float("nan")


def _interval(values, requested):
    good = np.asarray(values, dtype=float)
    good = good[np.isfinite(good)]
    if len(good) < max(20, int(np.ceil(0.9 * requested))):
        return None
    return [float(v) for v in np.quantile(good, [0.025, 0.975])]


def _auc_fold(frame, training, horizon, patient_index):
    """Use only horizon-relevant events, preserving every dynamic control."""
    time = frame["time"].to_numpy(float)
    event = frame["event"].to_numpy(bool)
    risk = frame["risk"].to_numpy(float)
    cases = event & (time <= horizon)
    controls = time > horizon
    support = {
        "test_cases": int(cases.sum()),
        "test_controls": int(controls.sum()),
        "test_censored_by_horizon": int(((~event) & (time <= horizon)).sum()),
        "training_beyond_horizon": int((training["time"] > horizon).sum()),
        "training_censoring_survival": None,
    }
    reasons = []
    if support["test_cases"] < SUPPORT_RULES["minimum_test_cases"]:
        reasons.append("fewer than 3 held-out DFI events by horizon")
    if support["test_controls"] < SUPPORT_RULES["minimum_test_controls"]:
        reasons.append("fewer than 5 held-out observations beyond horizon")
    if support["training_beyond_horizon"] < SUPPORT_RULES["minimum_training_beyond_horizon"]:
        reasons.append("fewer than 10 training observations beyond horizon")
    train_y = _surv(training)
    try:
        censoring = CensoringDistributionEstimator().fit(train_y)
        g_horizon = float(censoring.predict_proba(np.array([horizon]))[0])
        support["training_censoring_survival"] = g_horizon
        if g_horizon < SUPPORT_RULES["minimum_training_censoring_survival"]:
            reasons.append("training censoring survival below 0.05")
    except ValueError as exc:
        reasons.append(f"training censoring distribution unsupported: {exc}")
    if reasons:
        return {"support": support, "status": "not estimable", "reason": "; ".join(reasons)}

    # Administrative censoring immediately after the horizon is mathematically
    # neutral for AUC(t): later events are controls at t. It avoids requesting
    # irrelevant IPCW values beyond the training follow-up range. No observation
    # is removed, and no event at/before the horizon is recoded.
    cap = np.nextafter(float(horizon), np.inf)
    capped = frame[["time", "event"]].copy()
    capped["time"] = np.minimum(time, cap)
    capped["event"] = event & (time <= horizon)
    test_y = _surv(capped)
    try:
        auc = float(cumulative_dynamic_auc(train_y, test_y, risk, [horizon])[0][0])
        ipcw = censoring.predict_ipcw(test_y)
    except ValueError as exc:
        return {"support": support, "status": "not estimable", "reason": str(exc)}
    if not np.isfinite(auc):
        return {"support": support, "status": "not estimable", "reason": "non-finite IPCW AUC"}

    case_i = np.flatnonzero(cases)
    control_i = np.flatnonzero(controls)
    i = np.repeat(case_i, len(control_i))
    j = np.tile(control_i, len(case_i))
    difference = risk[i] - risk[j]
    success = np.where(np.abs(difference) <= 1e-8, 0.5, difference > 0).astype(float)
    weights = ipcw[i]
    manual = float(np.dot(success, weights) / weights.sum())
    if not np.isclose(manual, auc, rtol=1e-7, atol=1e-8):
        raise ValueError(f"IPCW pair calculation disagrees with scikit-survival: {manual} vs {auc}")
    known = cases | controls
    # sklearn's weighted ROC uses the same case IPCW; controls have unit weight.
    sample_weight = np.where(cases[known], ipcw[known], 1.0)
    fpr, tpr, _ = roc_curve(cases[known].astype(int), risk[known], sample_weight=sample_weight)
    ids = frame["patient_id"].map(patient_index).to_numpy(int)
    return {
        "status": "estimable", "reason": "", "support": support, "auc": auc,
        "pairs": (ids[i], ids[j], success, weights),
        "fpr": fpr, "tpr": tpr, "pair_weight": float(weights.sum()),
    }


def _calibration(patients, horizon, column):
    data = patients.loc[np.isfinite(patients[column]), ["time", "event", column]].copy()
    if len(data) < 20:
        return {"status": "not estimable", "reason": "fewer than 20 finite held-out predictions", "points": []}
    data["prediction"] = 1.0 - data[column]
    bins = min(3, len(data) // 20, int(data.prediction.nunique()))
    data["bin"] = 0 if bins <= 1 else pd.qcut(data.prediction, q=bins, labels=False, duplicates="drop")
    points, omissions = [], []
    for _, group in data.groupby("bin", dropna=False):
        n_events = int(((group.time <= horizon) & group.event.astype(bool)).sum())
        n_controls = int((group.time > horizon).sum())
        if len(group) < 20 or n_events < 3 or n_controls < 5:
            omissions.append(f"unsupported bin (n={len(group)}, cases={n_events}, controls={n_controls})")
            continue
        km = KaplanMeierFitter().fit(group.time, group.event.astype(bool))
        survival = float(km.predict(horizon))
        interval = km.confidence_interval_.loc[km.confidence_interval_.index <= horizon].iloc[-1]
        points.append({
            "n": int(len(group)), "predicted": float(group.prediction.mean()),
            "observed": 1.0 - survival,
            "lower": float(1.0 - interval.iloc[1]), "upper": float(1.0 - interval.iloc[0]),
            "events_by_horizon": n_events, "controls_beyond_horizon": n_controls,
        })
    return {
        "status": "estimable" if points else "not estimable",
        "reason": "; ".join(omissions), "points": points,
        "method": "descriptive KM incidence in up to three bins of repeat-averaged held-out probability; pointwise log-log KM 95% intervals",
    }


def evaluate_oof(
    oof: pd.DataFrame,
    fold_training: Mapping[tuple, pd.DataFrame],
    n_bootstrap: int = 1000,
    seed: int = 20261013,
    horizons: Mapping[str, float] | None = None,
):
    """Return JSON-ready metrics and figure data (the latter includes a DataFrame).

    Required OOF columns: seed, fold, patient_id, time, event, risk, s36, s60,
    risk_percentile. risk_percentile must use the outer TRAINING risk ECDF.
    s36/s60 are outer-model survival probabilities, not binary classifications.
    """
    horizons = DEFAULT_HORIZONS if horizons is None else dict(horizons)
    required = {"seed", "fold", "patient_id", "time", "event", "risk", "risk_percentile"}
    required |= {f"s{k}" for k in horizons}
    missing = required - set(oof.columns)
    if missing:
        raise ValueError(f"Missing OOF columns: {sorted(missing)}")
    if oof.duplicated(["seed", "patient_id"]).any():
        raise ValueError("Each patient must have exactly one OOF prediction per seed")
    for column in ["time", "event"]:
        if (oof.groupby("patient_id")[column].nunique(dropna=False) != 1).any():
            raise ValueError(f"Patient outcome {column} differs across repetitions")
    seeds = sorted(oof.seed.unique())
    if (oof.groupby("patient_id").size() != len(seeds)).any():
        raise ValueError("Every patient must occur in every CV seed")
    if not np.isfinite(oof[["time", "risk", "risk_percentile"]].to_numpy(float)).all():
        raise ValueError("Non-finite outcomes or risk scores")
    if (oof.time <= 0).any() or not set(oof.event.unique()) <= {0, 1, False, True}:
        raise ValueError("DFI times must be positive; event must be binary")

    outcomes = oof.drop_duplicates("patient_id").set_index("patient_id")[["time", "event"]]
    ids = sorted(outcomes.index)
    patient_index = {value: i for i, value in enumerate(ids)}
    n = len(ids)
    c_parts = defaultdict(list)
    auc_parts = {label: defaultdict(list) for label in horizons}
    auc_folds = {label: [] for label in horizons}
    fold_c = []
    for (cv_seed, fold), frame in oof.groupby(["seed", "fold"], sort=True):
        training = fold_training[(cv_seed, fold)]
        c_parts[cv_seed].append(_concordance_pairs(frame, patient_index))
        numerator, denominator = concordance_counts(frame.time, frame.event, frame.risk)
        fold_c.append({
            "seed": int(cv_seed), "fold": int(fold), "n": len(frame),
            "events": int(frame.event.sum()), "comparable_pairs": int(denominator),
            "c_index": numerator / denominator if denominator > 0 else None,
        })
        for label, horizon in horizons.items():
            result = _auc_fold(frame, training, horizon, patient_index)
            result["seed"] = int(cv_seed)
            result["fold"] = int(fold)
            if result["status"] == "estimable":
                auc_parts[label][cv_seed].append(result["pairs"])
            auc_folds[label].append(result)
    c_pairs = {key: _combine_pairs(value) for key, value in c_parts.items()}
    c_point = _estimate_from_pairs(c_pairs)
    if not np.isclose(c_point, primary_c_index(oof), rtol=1e-10, atol=1e-10):
        raise ValueError("Bootstrap pair definitions disagree with scikit-survival Harrell C")
    auc_pairs = {}
    for label in horizons:
        if all(r["status"] == "estimable" for r in auc_folds[label]):
            auc_pairs[label] = {key: _combine_pairs(value) for key, value in auc_parts[label].items()}

    bootstrap = {"c_index": [], **{label: [] for label in auc_pairs}}
    rng = np.random.default_rng(seed)
    for _ in range(n_bootstrap):
        multiplicity = np.bincount(rng.integers(0, n, size=n), minlength=n)
        bootstrap["c_index"].append(_estimate_from_pairs(c_pairs, multiplicity))
        for label, pairs in auc_pairs.items():
            bootstrap[label].append(_estimate_from_pairs(pairs, multiplicity))

    follow_time, follow_probability = kaplan_meier_estimator(
        outcomes.event.to_numpy(bool), outcomes.time.to_numpy(float), reverse=True
    )
    crossing = np.flatnonzero(follow_probability <= 0.5)
    median_followup = float(follow_time[crossing[0]]) if len(crossing) else None
    c_seed = {str(k): _estimate_from_pairs({k: v}) for k, v in c_pairs.items()}
    metrics = {
        "eligible_patients": n, "DFI_events": int(outcomes.event.sum()),
        "median_followup_days": median_followup,
        "median_followup_months": median_followup / (365.25 / 12.0) if median_followup is not None else None,
        "followup_method": "reverse Kaplan-Meier, with event-first handling of tied event/censoring times",
        "c_index": c_point if np.isfinite(c_point) else None,
        "c_index_ci95": _interval(bootstrap["c_index"], n_bootstrap),
        "c_index_by_seed": c_seed, "c_index_outer_folds": fold_c,
        "c_index_method": "Harrell C: sum concordance counts within outer folds per seed, then average seeds; no cross-fold risk comparisons",
        "bootstrap": {
            "replicates_requested": int(n_bootstrap),
            "valid_c_index_replicates": int(np.isfinite(bootstrap["c_index"]).sum()),
            "method": "patient-cluster percentile bootstrap; one resampling multiplicity vector shared across all CV repetitions",
            "limitation": "conditional on fitted CV models and training censoring distributions; model selection is not rerun inside bootstrap",
            "seed": int(seed),
        },
        "auc_support_rules": SUPPORT_RULES.copy(), "auc": {},
    }
    plotting = {"roc": {}, "calibration": {}}
    for label, horizon in horizons.items():
        records = auc_folds[label]
        diagnostics = [{k: v for k, v in r.items() if k not in {"pairs", "fpr", "tpr", "pair_weight"}} for r in records]
        summary = {
            "horizon_days": float(horizon),
            "events_by_horizon": int(((outcomes.time <= horizon) & outcomes.event.astype(bool)).sum()),
            "observed_beyond_horizon": int((outcomes.time > horizon).sum()),
            "censored_by_horizon": int(((outcomes.time <= horizon) & ~outcomes.event.astype(bool)).sum()),
            "outer_fold_diagnostics": diagnostics,
        }
        if label not in auc_pairs:
            failures = [r for r in records if r["status"] != "estimable"]
            reason = f"{len(failures)}/{len(records)} outer folds fail prespecified support; " + "; ".join(
                f"seed {r['seed']} fold {r['fold']}: {r['reason']}" for r in failures[:5]
            )
            summary.update(status="not estimable", value=None, ci95=None, reason=reason)
            plotting["roc"][label] = {"status": "not estimable", "reason": reason, "auc": None, "fpr": [], "tpr": []}
        else:
            point = _estimate_from_pairs(auc_pairs[label])
            summary.update(status="estimable", value=point, ci95=_interval(bootstrap[label], n_bootstrap), reason="")
            summary["valid_bootstrap_replicates"] = int(np.isfinite(bootstrap[label]).sum())
            summary["method"] = "cumulative/dynamic IPCW AUC from scikit-survival; fold-pair weighted within seed then averaged across seeds"
            grid = np.linspace(0, 1, 1001)
            repeat_tpr = []
            for cv_seed in seeds:
                same_seed = [r for r in records if r["seed"] == cv_seed]
                weights = np.array([r["pair_weight"] for r in same_seed])
                curves = np.array([np.interp(grid, r["fpr"], r["tpr"]) for r in same_seed])
                repeat_tpr.append(np.average(curves, axis=0, weights=weights))
            plotting["roc"][label] = {
                "status": "estimable", "reason": "", "auc": point,
                "fpr": grid.tolist(), "tpr": np.mean(repeat_tpr, axis=0).tolist(),
            }
        metrics["auc"][label] = summary

    predictions = oof.groupby("patient_id")[["risk_percentile", *[f"s{k}" for k in horizons]]].mean()
    patients = outcomes.join(predictions).reset_index()
    plotting["patients"] = patients
    for label, horizon in horizons.items():
        plotting["calibration"][label] = _calibration(patients, horizon, f"s{label}")
    return metrics, plotting
