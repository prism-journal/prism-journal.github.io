#!/usr/bin/env python3
"""Four-source-RNA TCGA-COAD DFI analysis. See --help and audit.log.

Run: work/.venv/bin/python analysis.py
Input Xena STAR data are log2(count+1), not raw counts. Inverse transformation
retains fractional counts because Xena averages replicate aliquots.
"""
import os
for _key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[_key] = '1'
os.environ.setdefault('MPLCONFIGDIR', str(__import__('pathlib').Path('work/mplcache').resolve()))

import argparse
import hashlib
import importlib.metadata
import json
import logging
import math
import pickle
import re
import sys
import time
import warnings
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from lifelines import CoxPHFitter, KaplanMeierFitter
from lifelines.exceptions import ConvergenceError, ConvergenceWarning
from sklearn.model_selection import StratifiedKFold
from sksurv.metrics import concordance_index_censored
from fast_cox import enable_fast_efron
enable_fast_efron()

PANEL = {
    'ENSG00000153363': 'LINC00467',
    'ENSG00000236081': 'ELFN1-AS1',
    'ENSG00000263429': 'LINC00675 / TMEM238L',
    'ENSG00000233101': 'HOXB-AS3',
}
STAGES = {'Stage II', 'Stage IIA', 'Stage IIB', 'Stage IIC',
          'Stage III', 'Stage IIIA', 'Stage IIIB', 'Stage IIIC'}
SEEDS = [11, 23, 37, 53, 71]
# Deterministic tie-break: stronger penalty, then larger L1 fraction.
GRID = [(p, r) for p in [10., 1., .1, .01, .001] for r in [1., .9, .5, .1]]
HORIZONS = {'36': 365.25 * 3, '60': 365.25 * 5}
RETENTION_THRESHOLD = 1e-4
LOG = logging.getLogger('analysis')


def atomic_json(data, path):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.part')
    temporary.write_text(json.dumps(data, indent=2, allow_nan=False, default=json_default) + '\n')
    temporary.replace(path)


def json_default(value):
    if isinstance(value, np.ndarray): return value.tolist()
    if isinstance(value, np.integer): return int(value)
    if isinstance(value, np.floating): return float(value)
    if isinstance(value, np.bool_): return bool(value)
    if isinstance(value, Path): return str(value)
    raise TypeError(type(value).__name__)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''): digest.update(chunk)
    return digest.hexdigest()


def load_data(expression_path, clinical_path, scale, workdir):
    audit = {}
    def count(name, value):
        audit[name] = int(value)
        LOG.info('FILTER %-45s N=%d', name, value)
    LOG.info('Excluded a priori: RBRP-encoding LINC00266-1; no stable resolved Ensembl ID in this annotation. Not imputed as zero.')
    x = pd.read_csv(expression_path, sep='\t', index_col=0)
    count('input_expression_genes', len(x))
    count('input_expression_specimens', x.shape[1])
    if not x.columns.is_unique: raise ValueError('Duplicate column names in expression input.')
    primary = [s for s in x.columns if re.fullmatch(r'TCGA-[A-Z0-9]{2}-[A-Z0-9]{4}-01[A-Z](?:-.*)?', s)]
    count('primary_tumor_specimens', len(primary))
    primary = sorted(primary)
    selected = pd.DataFrame({'specimen_id': primary})
    selected['patient_id'] = selected.specimen_id.str[:12]
    selected['selected'] = ~selected.patient_id.duplicated()
    selected.to_csv(workdir / 'specimen_selection.tsv', sep='\t', index=False)
    chosen = selected.loc[selected.selected]
    count('primary_tumor_unique_patients', len(chosen))
    count('duplicate_primary_specimens_removed', len(primary) - len(chosen))
    x = x.loc[:, chosen.specimen_id]
    x.columns = chosen.patient_id.to_list()
    # Preserve the PAR_Y tag: ENSGxxx.5_PAR_Y and ENSGxxx.5 are distinct loci.
    x.index = x.index.astype(str).str.replace(r'\.\d+(?=_PAR_Y$|$)', '', regex=True)
    if not x.index.is_unique:
        raise ValueError('Ambiguous duplicate gene IDs after version removal; resolve before analysis (do not silently aggregate).')
    c = pd.read_excel(clinical_path, sheet_name='TCGA-CDR', engine='openpyxl')
    count('cdr_all_cancers', len(c))
    c = c.loc[c.type.eq('COAD')].copy()
    count('cdr_coad', len(c))
    if c.bcr_patient_barcode.duplicated().any(): raise ValueError('Duplicate CDR COAD patient IDs.')
    c = c.set_index('bcr_patient_barcode')
    count('expression_patients_without_coad_cdr', len(set(x.columns) - set(c.index)))
    c = c.loc[sorted(set(x.columns) & set(c.index))]
    count('expression_cdr_matched', len(c))
    LOG.info('Stage counts before stage restriction: %s', c.ajcc_pathologic_tumor_stage.value_counts(dropna=False).to_dict())
    c = c.loc[c.ajcc_pathologic_tumor_stage.isin(STAGES)].copy()
    count('stage_ii_iii', len(c))
    for col in ['DFI', 'DFI.time']: c[col] = pd.to_numeric(c[col], errors='raise')
    count('missing_dfi_event', c.DFI.isna().sum())
    c = c.loc[c.DFI.notna()]
    count('after_nonmissing_dfi', len(c))
    count('missing_dfi_time', c['DFI.time'].isna().sum())
    c = c.loc[c['DFI.time'].notna()]
    count('after_nonmissing_dfi_time', len(c))
    count('nonpositive_dfi_time', c['DFI.time'].le(0).sum())
    c = c.loc[c['DFI.time'].gt(0)]
    if not c.DFI.isin([0, 1]).all(): raise ValueError('DFI must be 0/1.')
    count('eligible_patients', len(c))
    count('dfi_events', c.DFI.sum())
    if min(c.DFI.value_counts()) < 5: raise ValueError('Insufficient event strata for five outer folds.')
    x = x.loc[:, c.index]
    values = x.to_numpy(dtype=np.float64)
    if np.isinf(values).any() or np.nanmin(values) < 0: raise ValueError('Invalid expression values.')
    audit['input_scale'] = scale
    audit['input_missing_expression_cells'] = int(np.isnan(values).sum())
    if scale == 'xena-log2-counts':
        LOG.info('Reverse Xena log2(count+1) with expm1(x*ln2); do not round averaged replicate counts.')
        values = np.expm1(values * np.log(2))
    elif not np.allclose(values[np.isfinite(values)], np.rint(values[np.isfinite(values)]), atol=1e-6):
        raise ValueError('Raw-count mode supplied fractional/log-transformed values. Use --input-scale xena-log2-counts for this dataset.')
    # Normalization is sample-local and uses ALL measured genes, not the four panel genes.
    # A missing library component makes that sample denominator unknown; never fill it with zero.
    library = values.sum(axis=0)
    if not np.isfinite(library).all() or (library <= 0).any():
        raise ValueError('Missing counts or invalid full-library denominator; cannot validly calculate CPM.')
    cpm = (values / library[None, :] * 1e6).T
    logx = np.log2(cpm + 1)
    c['library_size_recovered_counts'] = library
    c.to_csv(workdir / 'eligible_clinical.tsv', sep='\t', na_rep='NA')
    genes = x.index.to_numpy(dtype=str)
    missing = [g for g in PANEL if g not in set(genes)]
    audit['missing_panel_annotations'] = missing
    if missing: raise ValueError(f'Missing panel annotation: {missing}; not interpreted as zero expression.')
    audit['panel_ids_present'] = list(PANEL)
    LOG.info('All four requested Ensembl IDs found. CPM denominator includes %d genes; PAR_Y identifiers preserved.', len(genes))
    LOG.info('Library sizes recovered from Xena: min=%.0f, median=%.0f, max=%.0f', library.min(), np.median(library), library.max())
    y = pd.DataFrame({'patient_id': c.index, 'time': c['DFI.time'].to_numpy(float), 'event': c.DFI.to_numpy(bool)})
    np.save(workdir / 'cpm.npy', cpm)
    np.save(workdir / 'logx.npy', logx)
    np.save(workdir / 'genes.npy', genes)
    y.to_csv(workdir / 'outcomes.tsv', sep='\t', index=False)
    return cpm, logx, genes, y, audit


def make_splits(y):
    splits = []
    event = y.event.to_numpy()
    for seed in SEEDS:
        outer = StratifiedKFold(5, shuffle=True, random_state=seed)
        for fold, (train, test) in enumerate(outer.split(np.zeros(len(y)), event)):
            inner = StratifiedKFold(3, shuffle=True, random_state=seed * 100 + fold)
            inners = [(train[a], train[b]) for a, b in inner.split(np.zeros(len(train)), event[train])]
            splits.append({'seed': seed, 'fold': fold, 'train': train, 'test': test, 'inner': inners})
    return splits


def preprocessing(cpm, logx, indices, train, test):
    a = np.asarray(logx[np.ix_(train, indices)], dtype=float)
    b = np.asarray(logx[np.ix_(test, indices)], dtype=float)
    gate = np.mean(cpm[np.ix_(train, indices)] >= 1., axis=0) >= .2
    gate &= np.isfinite(a).any(axis=0)
    positions = np.flatnonzero(gate)
    a, b = a[:, gate], b[:, gate]
    if len(positions) == 0: return a, b, positions, {}
    median = np.nanmedian(a, axis=0)
    a = np.where(np.isfinite(a), a, median)
    b = np.where(np.isfinite(b), b, median)
    mean, sd = a.mean(axis=0), a.std(axis=0)
    varying = sd > 1e-12
    positions = positions[varying]
    state = {'median': median[varying], 'mean': mean[varying], 'sd': sd[varying]}
    return ((a[:, varying] - state['mean']) / state['sd'],
            (b[:, varying] - state['mean']) / state['sd'], positions, state)


def c_summary(event, duration, risk):
    try:
        out = concordance_index_censored(np.asarray(event, bool), duration, risk, tied_tol=1e-8)
        numerator = float(out[1] + .5 * out[3])
        denominator = int(out[1] + out[2] + out[3])
        return numerator, denominator
    except ValueError:
        return 0., 0


def fit_cox(a, y, hyper):
    df = pd.DataFrame(a, columns=[f'x{i}' for i in range(a.shape[1])])
    df['time'] = y.time.to_numpy()
    df['event'] = y.event.to_numpy()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always', ConvergenceWarning)
        model = CoxPHFitter(penalizer=hyper[0], l1_ratio=hyper[1])
        model.fit(df, duration_col='time', event_col='event', show_progress=False)
    if any(issubclass(w.category, ConvergenceWarning) for w in caught):
        raise ConvergenceError('; '.join(str(w.message) for w in caught))
    # lifelines uses a smooth L1 approximation. Numerical near-zero coefficients
    # must not generate artificial rankings for an otherwise empty model.
    model.params_.loc[model.params_.abs() < RETENTION_THRESHOLD] = 0.
    return model


def zero_solution_bound(a, y):
    """KKT score bound for an exactly zero elastic-net Cox optimum.

    lifelines penalizes coefficients on its sample-SD standardized scale, with
    penalty multiplied by n. Efron tied-event likelihood is used here too.
    This training-only bound permits exact zero solutions without redundant fits.
    """
    if a.shape[1] == 0: return 0.
    z = (a - a.mean(axis=0)) / a.std(axis=0, ddof=1)
    duration, event = y.time.to_numpy(), y.event.to_numpy(bool)
    gradient = z[event].sum(axis=0)
    for t in np.unique(duration[event]):
        death = (duration == t) & event
        at_risk = duration >= t
        d = int(death.sum())
        risk_sum, death_sum = z[at_risk].sum(axis=0), z[death].sum(axis=0)
        for k in range(d):
            fraction = k / d
            gradient -= (risk_sum - fraction * death_sum) / (at_risk.sum() - k)
    return float(np.max(np.abs(gradient)) / len(a))


def rebase(model, a, y):
    """Recompute Breslow baseline after the declared numerical-zero rule."""
    if model is None: return
    x = pd.DataFrame(a, columns=model.params_.index)
    ph = pd.DataFrame({'P': model.predict_partial_hazard(x).to_numpy(),
                       'T': y.time.to_numpy(), 'E': y.event.to_numpy(), 'W': 1.})
    fitted = model._model
    fitted.baseline_hazard_ = fitted._compute_baseline_hazards(ph)
    fitted.baseline_cumulative_hazard_ = fitted._compute_baseline_cumulative_hazard(fitted.baseline_hazard_)
    fitted.baseline_survival_ = fitted._compute_baseline_survival()


def predict(model, a):
    if model is None: return np.zeros(len(a))
    return model.predict_log_partial_hazard(pd.DataFrame(a, columns=model.params_.index)).to_numpy()


def tune(cpm, logx, indices, y, inner):
    prepared = []
    for train, valid in inner:
        a, b, pos, state = preprocessing(cpm, logx, indices, train, valid)
        prepared.append((a, b, y.iloc[train], y.iloc[valid], zero_solution_bound(a, y.iloc[train])))
    scores, failures = [], 0
    for hyper in GRID:
        nums, dens, invalid = [], [], False
        for a, b, yt, yv, bound in prepared:
            try:
                exact_zero = bound < hyper[0] * hyper[1] * (1 - 1e-6)
                model = fit_cox(a, yt, hyper) if a.shape[1] and not exact_zero else None
                num, den = c_summary(yv.event, yv.time.to_numpy(), predict(model, b))
                if den == 0: raise ValueError('No comparable validation pairs')
                nums.append(num); dens.append(den)
            except (ConvergenceError, ValueError, np.linalg.LinAlgError, FloatingPointError):
                failures += 1; invalid = True; break
        scores.append(-np.inf if invalid else sum(nums) / sum(dens))
    if not np.isfinite(scores).any(): raise RuntimeError('All hyperparameter candidates failed.')
    best = int(np.argmax(scores))
    return GRID[best], float(scores[best]), failures


def run_panel(indices, cpm, logx, genes, y, splits, detailed=False):
    records, fold_records, sums, gate_counts = [], [], {}, []
    total_failures = 0
    for split in splits:
        train, test = split['train'], split['test']
        hyper, inner_score, failures = tune(cpm, logx, indices, y, split['inner'])
        total_failures += failures
        a, b, pos, state = preprocessing(cpm, logx, indices, train, test)
        gate_counts.append(int(len(pos)))
        model = fit_cox(a, y.iloc[train], hyper) if a.shape[1] else None
        risk = predict(model, b)
        num, den = c_summary(y.iloc[test].event, y.iloc[test].time.to_numpy(), risk)
        aggregate = sums.setdefault(split['seed'], [0., 0])
        aggregate[0] += num; aggregate[1] += den
        if detailed:
            trainrisk = predict(model, a)
            riskpct = ((trainrisk[:, None] < risk).sum(axis=0) + .5 * (trainrisk[:, None] == risk).sum(axis=0)) / len(train)
            if model is None:
                km = KaplanMeierFitter().fit(y.iloc[train].time, y.iloc[train].event)
                surv = np.repeat(km.predict(list(HORIZONS.values())).to_numpy()[:, None], len(test), axis=1)
                coefs = []
            else:
                rebase(model, a, y.iloc[train])
                surv = model.predict_survival_function(pd.DataFrame(b, columns=model.params_.index), times=list(HORIZONS.values())).to_numpy()
                coefs = model.params_.to_numpy().tolist()
            for j, patient in enumerate(test):
                records.append({'seed': split['seed'], 'fold': split['fold'],
                    'patient_id': y.iloc[patient].patient_id, 'time': float(y.iloc[patient].time),
                    'event': bool(y.iloc[patient].event), 'risk': float(risk[j]),
                    'risk_percentile': float(riskpct[j]), 's36': float(surv[0, j]), 's60': float(surv[1, j])})
            fold_records.append({'seed': split['seed'], 'fold': split['fold'], 'n_train': len(train),
                'n_test': len(test), 'train_events': int(y.iloc[train].event.sum()), 'test_events': int(y.iloc[test].event.sum()),
                'penalizer': hyper[0], 'l1_ratio': hyper[1], 'inner_c_index': inner_score,
                'outer_c_index': num / den if den else None,
                'gate_passed': genes[indices[pos]].tolist(),
                'retained': genes[indices[pos]][np.abs(coefs) >= RETENTION_THRESHOLD].tolist(),
                'coefficients': coefs, 'inner_fit_failures': failures})
            LOG.info('Real panel seed=%d fold=%d: C=%.4f, gate=%d, penalizer=%g, L1=%g', split['seed'], split['fold'], num / den, len(pos), *hyper)
    scores = {str(k): v[0] / v[1] for k, v in sums.items()}
    return {'c_index': float(np.mean(list(scores.values()))), 'seed_c_indices': scores,
            'fit_failures': total_failures, 'outer_gate_counts': gate_counts, 'oof': records, 'folds': fold_records}


def null_worker(panel_number, indices, workdir, splits, fingerprint):
    enable_fast_efron()
    path = workdir / 'null_panels' / f'panel_{panel_number:04d}.json'
    if path.exists():
        saved = json.loads(path.read_text())
        if saved['fingerprint'] == fingerprint and saved['gene_indices'] == list(indices): return saved
    cpm = np.load(workdir / 'cpm.npy', mmap_mode='r')
    logx = np.load(workdir / 'logx.npy', mmap_mode='r')
    genes = np.load(workdir / 'genes.npy')
    y = pd.read_csv(workdir / 'outcomes.tsv', sep='\t')
    y['event'] = y.event.astype(bool)
    started = time.perf_counter()
    result = run_panel(np.asarray(indices), cpm, logx, genes, y, splits)
    result.update(panel_number=panel_number, gene_indices=list(indices), genes=genes[indices].tolist(),
                  fingerprint=fingerprint, seconds=time.perf_counter() - started)
    atomic_json(result, path)
    return result


def fit_final(cpm, logx, indices, genes, y):
    allrows = np.arange(len(y))
    inner = list(StratifiedKFold(3, shuffle=True, random_state=SEEDS[0]).split(np.zeros(len(y)), y.event))
    hyper, score, failures = tune(cpm, logx, indices, y, inner)
    a, _, pos, state = preprocessing(cpm, logx, indices, allrows, allrows)
    model = fit_cox(a, y, hyper) if a.shape[1] else None
    rebase(model, a, y)
    rows = []
    if model is not None:
        for j, (name, row) in enumerate(model.summary.iterrows()):
            gene = genes[indices[pos[j]]]
            rows.append({'ensembl': gene, 'marker': PANEL[gene], 'coef': row['coef'],
                         'hr': row['exp(coef)'], 'lower': row['exp(coef) lower 95%'],
                         'upper': row['exp(coef) upper 95%'], 'retained': abs(row['coef']) >= RETENTION_THRESHOLD})
    frame = pd.DataFrame(rows, columns=['ensembl', 'marker', 'coef', 'hr', 'lower', 'upper', 'retained'])
    metadata = {'penalizer': hyper[0], 'l1_ratio': hyper[1], 'inner_c_index': score,
                'gate_passed': genes[indices[pos]].tolist(), 'fit_failures': failures,
                'retention_threshold_abs_log_hr_per_training_sd': RETENTION_THRESHOLD,
                'note': 'Exploratory full-cohort refit. Penalized Wald intervals ignore selection; not validation intervals.'}
    return model, state, frame, metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir', type=Path, default=Path('data'))
    parser.add_argument('--output-dir', type=Path, default=Path('.'))
    parser.add_argument('--work-dir', type=Path, default=Path('work/analysis_cache'))
    parser.add_argument('--input-scale', choices=['xena-log2-counts', 'raw-counts'], default='xena-log2-counts')
    parser.add_argument('--n-random', type=int, default=1000)
    parser.add_argument('--bootstrap', type=int, default=1000)
    parser.add_argument('--jobs', type=int, default=8)
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    if args.n_random < 1 or args.bootstrap < 1 or args.jobs < 1: parser.error('Counts and jobs must be positive.')
    outdir, workdir = args.output_dir.resolve(), args.work_dir.resolve()
    outdir.mkdir(parents=True, exist_ok=True); workdir.mkdir(parents=True, exist_ok=True)
    (workdir / 'null_panels').mkdir(exist_ok=True)
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s',
                        handlers=[logging.FileHandler(outdir / 'audit.log', mode='w'), logging.StreamHandler(sys.stdout)])
    started = datetime.now(timezone.utc).isoformat()
    LOG.info('Endpoint is disease-free interval (DFI); not relabeled RFS. Seeds=%s; CV=5 outer x 3 inner x 5 repeats.', SEEDS)
    LOG.info('All measurement gating, imputation and scaling fit in each training fold. No batch correction. Full-library CPM is sample-local.')
    LOG.info('Numerical L1 zero rule: abs(log HR per training SD)<%g set to zero for all scoring and reporting; Breslow baseline recomputed for survival predictions.', RETENTION_THRESHOLD)
    LOG.info('Exact Efron gradient acceleration enabled; lifelines optimizer/penalty unchanged. Training-only KKT test skips redundant inner fits with provably zero coefficients.')
    LOG.info('AUC prespecified support per outer fold: >=3 cases by horizon, >=5 controls after horizon, >=10 training patients after horizon, censoring survival G(t)>=0.05.')
    expr = args.data_dir / 'TCGA-COAD.star_counts.tsv.gz'
    clinical = args.data_dir / 'TCGA-CDR-SupplementalTableS1.xlsx'
    provenance = {'expression_sha256': sha256(expr), 'clinical_sha256': sha256(clinical),
        'analysis_sha256': sha256(__file__), 'seeds': SEEDS, 'grid': GRID,
        'module_sha256': {name: sha256(Path(__file__).with_name(name)) for name in ['survival_metrics.py', 'analysis_figures.py', 'fast_cox.py']},
        'input_scale': args.input_scale, 'n_random': args.n_random, 'bootstrap': args.bootstrap,
        'xena_metadata_url': 'https://gdc.xenahubs.net/download/TCGA-COAD.star_counts.tsv.json',
        'xena_metadata_verified_unit': 'log2(count+1)',
        'package_versions': {p: importlib.metadata.version(p) for p in ['numpy','pandas','scipy','scikit-learn','lifelines','scikit-survival','matplotlib','matplot2tikz']}}
    fingerprint = hashlib.sha256(json.dumps(provenance, sort_keys=True).encode()).hexdigest()
    atomic_json(provenance, workdir / 'provenance.json')
    cpm, logx, genes, y, audit = load_data(expr, clinical, args.input_scale, workdir)
    splits = make_splits(y)
    atomic_json([{k: v for k, v in s.items()} for s in splits], workdir / 'cv_splits.json')
    for split in splits:
        LOG.info('FOLD seed=%d fold=%d trainN=%d trainEvents=%d testN=%d testEvents=%d', split['seed'], split['fold'],
                 len(split['train']), y.iloc[split['train']].event.sum(), len(split['test']), y.iloc[split['test']].event.sum())
    atomic_json(audit, workdir / 'filtering_audit.json')
    if args.prepare_only: return
    indices = np.asarray([np.flatnonzero(genes == gene)[0] for gene in PANEL])
    real_cache = workdir / 'real_panel.json'
    if real_cache.exists() and json.loads(real_cache.read_text()).get('fingerprint') == fingerprint:
        real = json.loads(real_cache.read_text()); LOG.info('Reusing fingerprint-verified real-panel result.')
    else:
        real = run_panel(indices, cpm, logx, genes, y, splits, detailed=True)
        real['fingerprint'] = fingerprint; atomic_json(real, real_cache)
    oof = pd.DataFrame(real['oof'])
    oof.to_csv(outdir / 'oof_predictions.tsv', sep='\t', index=False)
    atomic_json(real['folds'], outdir / 'outer_fold_audit.json')
    from survival_metrics import evaluate_oof
    fold_training = {(s['seed'], s['fold']): y.iloc[s['train']][['time', 'event']] for s in splits}
    metrics, plotting_data = evaluate_oof(oof, fold_training, n_bootstrap=args.bootstrap, seed=20261013, horizons=HORIZONS)
    if not np.isclose(metrics['c_index'], real['c_index'], atol=1e-12): raise ValueError('C-index aggregation mismatch.')
    atomic_json(metrics, workdir / 'real_metrics.json')
    # Uniform annotation-universe panels: do NOT prefilter using the whole cohort.
    # Exclude the four target genes; run the same training-only gate for every panel.
    universe = np.flatnonzero(~np.isin(genes, list(PANEL)))
    rng = np.random.default_rng(20261013)
    random_panels, seen = [], set()
    while len(random_panels) < args.n_random:
        draw = tuple(sorted(map(int, rng.choice(universe, 4, replace=False))))
        if draw not in seen: seen.add(draw); random_panels.append(list(draw))
    atomic_json({'seed': 20261013, 'universe_size': len(universe), 'panels': [genes[p].tolist() for p in random_panels]}, outdir / 'random_panel_definitions.json')
    LOG.info('Running %d random four-gene panels with identical nested CV using %d workers.', args.n_random, args.jobs)
    stream = Parallel(n_jobs=args.jobs, return_as='generator_unordered', pre_dispatch=args.jobs)(
        delayed(null_worker)(i, panel, workdir, splits, fingerprint) for i, panel in enumerate(random_panels))
    nulls = []
    for result in stream:
        nulls.append(result)
        LOG.info('NULL completed %d/%d: panel=%d C=%.4f elapsed_panel=%.1fs fit_failures=%d', len(nulls), args.n_random,
                 result['panel_number'], result['c_index'], result['seconds'], result['fit_failures'])
        atomic_json({'status': 'running', 'completed_random_panels': len(nulls), 'requested_random_panels': args.n_random,
                     'real_panel_c_index': real['c_index'], 'updated_utc': datetime.now(timezone.utc).isoformat()}, outdir / 'analysis_progress.json')
    nulls.sort(key=lambda v: v['panel_number'])
    null_scores = np.array([v['c_index'] for v in nulls])
    pd.DataFrame([{'panel_number': v['panel_number'], 'genes': ';'.join(v['genes']), 'c_index': v['c_index'],
                   'fit_failures': v['fit_failures']} for v in nulls]).to_csv(outdir / 'random_panel_scores.tsv', sep='\t', index=False)
    model, state, forest, final_meta = fit_final(cpm, logx, indices, genes, y)
    forest.to_csv(outdir / 'final_model_coefficients.tsv', sep='\t', index=False)
    with (outdir / 'final_model.pkl').open('wb') as handle: pickle.dump({'model': model, 'preprocessing': state, 'metadata': final_meta}, handle)
    from analysis_figures import export_figures
    figure_meta = export_figures(outdir / 'figures', plotting_data, forest.loc[forest.retained], null_scores, real['c_index'], preamble_path=outdir / 'preamble.tex')
    results = {'status': 'complete', 'endpoint': 'DFI', 'started_utc': started,
        'completed_utc': datetime.now(timezone.utc).isoformat(), 'ensembl_ids_used': list(PANEL),
        'markers': PANEL, 'excluded_marker': {'LINC00266-1 / RBRP': 'No stable Ensembl ID resolved; excluded, not zero-imputed.'},
        'retained_transcripts': forest.loc[forest.retained, ['ensembl', 'marker']].to_dict('records'),
        'eligible_patients': len(y), 'dfi_events': int(y.event.sum()),
        'metrics': metrics, 'c_index': real['c_index'],
        'c_index_ci95': metrics['c_index_ci95'],
        'median_followup_days': metrics['median_followup_days'],
        'median_followup_months': metrics['median_followup_months'],
        'auc_3yr': {k: v for k, v in metrics['auc']['36'].items() if k != 'outer_fold_diagnostics'},
        'auc_5yr': {k: v for k, v in metrics['auc']['60'].items() if k != 'outer_fold_diagnostics'},
        'percentile_vs_random': float(100 * ((null_scores < real['c_index'] - 1e-12).sum() + .5 * np.isclose(null_scores, real['c_index'], atol=1e-12, rtol=0).sum()) / len(null_scores)),
        'random_panels_completed': len(nulls), 'random_panel_mean_c_index': float(null_scores.mean()),
        'random_panel_median_c_index': float(np.median(null_scores)),
        'random_panel_one_sided_empirical_p': float((1 + (null_scores >= real['c_index']).sum()) / (1 + len(null_scores))),
        'final_model': final_meta, 'filtering_audit': audit, 'provenance': provenance, 'figures': figure_meta,
        'limitations': ['Internal validation only; no independent cohort.', f'Only {int(y.event.sum())} DFI events in the supplied eligible cohort.',
            'RNA measurements are micropeptide-source RNA proxies, not peptide abundance.',
            'Random panels are uniform annotation-universe controls, not expression-matched controls.',
            'Bootstrap intervals condition on fitted OOF predictions; they do not refit nested CV.',
            'Final-model penalized Wald intervals ignore model selection and are exploratory.']}
    atomic_json(results, outdir / 'results.json')
    atomic_json({'status': 'complete', 'completed_random_panels': len(nulls), 'requested_random_panels': args.n_random,
                 'real_panel_c_index': real['c_index'], 'updated_utc': datetime.now(timezone.utc).isoformat()}, outdir / 'analysis_progress.json')
    LOG.info('COMPLETE: real-panel C-index %.4f; percentile vs %d random panels %.2f.', real['c_index'], len(nulls), results['percentile_vs_random'])


if __name__ == '__main__':
    main()
