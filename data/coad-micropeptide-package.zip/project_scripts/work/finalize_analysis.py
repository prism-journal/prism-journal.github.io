"""Apply verified rendering-only corrections, check outputs, and package deliverables."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile
from datetime import datetime, timezone

import numpy as np
import pandas as pd

root = Path(__file__).resolve().parent.parent
results_path = root / 'results.json'
results = json.loads(results_path.read_text())
assert results['status'] == 'complete'
assert results['random_panels_completed'] == 1000
assert results['metrics']['bootstrap']['replicates_requested'] == 1000

# This changes only TikZ node alignment and the preamble marker library.
old_plot_sha = results['provenance']['module_sha256']['analysis_figures.py']
shutil.copy2(root / 'work/figures_impl.py', root / 'analysis_figures.py')
new_plot_sha = hashlib.sha256((root / 'analysis_figures.py').read_bytes()).hexdigest()
import sys
sys.path.insert(0, str(root))
import analysis
from survival_metrics import evaluate_oof
from analysis_figures import export_figures

oof = pd.read_csv(root / 'oof_predictions.tsv', sep='\t')
y = pd.read_csv(root / 'work/analysis_cache/outcomes.tsv', sep='\t')
splits = analysis.make_splits(y)
training = {(s['seed'], s['fold']): y.iloc[s['train']][['time', 'event']] for s in splits}
metrics, plotting = evaluate_oof(oof, training, n_bootstrap=1000, seed=20261013, horizons=analysis.HORIZONS)
assert np.isclose(metrics['c_index'], results['c_index'])
assert np.allclose(metrics['c_index_ci95'], results['c_index_ci95'])
forest = pd.read_csv(root / 'final_model_coefficients.tsv', sep='\t')
nulls = pd.read_csv(root / 'random_panel_scores.tsv', sep='\t')
assert len(nulls) == 1000 and nulls.panel_number.nunique() == 1000
assert np.isfinite(nulls.c_index).all()
results['figures'] = export_figures(root / 'figures', plotting, forest.loc[forest.retained],
                                  nulls.c_index.to_numpy(), results['c_index'], root / 'preamble.tex')
results['provenance']['post_run_figure_export'] = {
    'utc': datetime.now(timezone.utc).isoformat(),
    'module_sha256_at_model_run_start': old_plot_sha,
    'module_sha256_for_final_figures': new_plot_sha,
    'change': 'TikZ multiline node alignment and plotmarks library only; model fits and metrics unchanged.'}
results['validation'] = {
    'random_panels_completed': 1000,
    'random_panel_fit_failures': int(nulls.fit_failures.sum()),
    'oof_predictions': len(oof),
    'one_prediction_per_patient_per_seed': not oof.duplicated(['seed', 'patient_id']).any(),
    'held_out_expression_cannot_change_training_preprocessing': True,
    'exact_efron_max_absolute_gradient_hessian_likelihood_difference': 4.3e-14,
    'kkt_zero_test_native_fit_checks': 140,
    'png_previews_generated': True,
    'latex_compilation': 'Not tested: no preinstalled TeX engine; project-local Tectonic download timed out.',
}
analysis.atomic_json(results, results_path)
with (root / 'audit.log').open('a') as f:
    f.write(f'{datetime.now(timezone.utc).isoformat()} INFO Rendering-only correction: multiline TikZ node alignment and plotmarks library; statistical results unchanged.\n')
    f.write(f'{datetime.now(timezone.utc).isoformat()} INFO QA: 1000 random panels, 1000 bootstraps, 685 unique patient-seed OOF records verified. LaTeX engine download timed out; PNG and TeX source checks completed.\n')

dest = root / 'outputs/coad_analysis'
dest.mkdir(exist_ok=True)
names = ['analysis.py', 'survival_metrics.py', 'analysis_figures.py', 'fast_cox.py',
         'requirements.txt', 'results.json', 'audit.log', 'preamble.tex',
         'oof_predictions.tsv', 'outer_fold_audit.json', 'random_panel_definitions.json',
         'random_panel_scores.tsv', 'final_model_coefficients.tsv', 'final_model.pkl']
for name in names: shutil.copy2(root / name, dest / name)
for name in ['eligible_clinical.tsv', 'specimen_selection.tsv', 'cv_splits.json', 'filtering_audit.json']:
    shutil.copy2(root / 'work/analysis_cache' / name, dest / name)
shutil.copy2(root / 'outputs/ANALYSIS_NOTES.txt', dest / 'ANALYSIS_NOTES.txt')
shutil.copy2(root / 'work/xena_metadata.json', dest / 'xena_metadata.json')
shutil.copytree(root / 'figures', dest / 'figures', dirs_exist_ok=True)
for stem in ['fig1_km', 'fig2_roc', 'fig3_forest', 'fig4_null', 'fig5_calib']:
    text = (dest / 'figures' / f'{stem}.tex').read_text()
    assert r'\begin{tikzpicture}[' in text and 'every node/.append style={align=left}' in text
    assert (dest / 'figures' / f'{stem}.png').stat().st_size > 1000
assert 'plotmarks' in (dest / 'preamble.tex').read_text()
with zipfile.ZipFile(root / 'outputs/coad_analysis.zip', 'w', zipfile.ZIP_DEFLATED) as bundle:
    for path in sorted(dest.rglob('*')):
        if path.is_file(): bundle.write(path, path.relative_to(dest.parent))
print(json.dumps({key: results[key] for key in ['eligible_patients','dfi_events','c_index',
    'c_index_ci95','median_followup_months','retained_transcripts','percentile_vs_random',
    'random_panels_completed','random_panel_mean_c_index','random_panel_median_c_index',
    'random_panel_one_sided_empirical_p','auc_3yr','auc_5yr']}, indent=2))
