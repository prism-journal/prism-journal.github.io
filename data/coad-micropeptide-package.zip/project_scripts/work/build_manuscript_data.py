"""Generate manuscript statistics directly from the frozen analysis JSON."""
import json
from pathlib import Path

root = Path(__file__).resolve().parent / 'manuscript'
r = json.loads((root / 'results.json').read_text())
macros = []
def macro(name, value):
    macros.append('\\newcommand{\\' + name + '}{' + str(value) + '}')
def ci(value, bounds):
    return f'{value:.3f} ({bounds[0]:.3f}--{bounds[1]:.3f})'
for prefix, key in [('Primary', 'primary_cohort'), ('DfiAll', 'stage_sensitivity_dfi_all_stages'), ('OsAll', 'secondary_cohort')]:
    v = r[key]
    macro(prefix+'N', v['eligible_patients'])
    macro(prefix+'Events', v['events'])
    macro(prefix+'Followup', f"{v['median_followup_months']:.2f}")
    macro(prefix+'C', f"{v['c_index']:.3f}")
    macro(prefix+'CCI', ci(v['c_index'], v['c_index_ci95']))
    macro(prefix+'CCIText', f"{v['c_index']:.3f} (95\\% CI, {v['c_index_ci95'][0]:.3f}--{v['c_index_ci95'][1]:.3f})")
    macro(prefix+'Percentile', f"{v['percentile_vs_random']:.1f}")
    macro(prefix+'NullP', f"{v['random_panel_one_sided_empirical_p']:.3f}")
for prefix, key in [('LincPrimary','linc00675_single_bootstrap'),('LincAll','linc00675_single_bootstrap_all_stages'),('ElfnOs','elfn1as1_single_bootstrap')]:
    v=r[key]
    macro(prefix+'C', f"{v['cindex']:.3f}")
    macro(prefix+'CCI', ci(v['cindex'], [v['ci_lower'],v['ci_upper']]))
    macro(prefix+'CCIText', f"{v['cindex']:.3f} (95\\% CI, {v['ci_lower']:.3f}--{v['ci_upper']:.3f})")
macro('LogrankP', f"{r['logrank_p_linc00675']:.3f}")
macro('ExpressionMedian', f"{r['linc00675_km_details']['median_expression']:.5f}")
a=r['secondary_cohort']['auc_3yr']
macro('OsAucCI', ci(a['value'],a['ci95']))
macro('OsAucCIText', f"{a['value']:.3f} (95\\% CI, {a['ci95'][0]:.3f}--{a['ci95'][1]:.3f})")
(root/'numbers.tex').write_text('% Generated from results.json; do not edit values by hand.\n'+'\n'.join(macros)+'\n')

rows=[]
for gene,name in r['markers'].items():
    vals=[ci(r['single_marker_details'][co][gene]['c_index'],r['single_marker_details'][co][gene]['c_index_ci95']) for co in ['primary_dfi_stage_ii_iii','dfi_all_stages','secondary_os_all_stages']]
    if gene=='ENSG00000263429': name='LINC00675/TMEM238L'
    rows.append(name+' & '+' & '.join(vals)+r' \\')
(root/'single_marker_rows.tex').write_text('\\newcommand{\\SingleMarkerRows}{%\n'+'\n'.join(rows)+'\n}\n')
rows=[]
for label,key in [('Primary DFI','primary_cohort'),('All-stage DFI','stage_sensitivity_dfi_all_stages'),('All-stage OS','secondary_cohort')]:
    for h in ['3','5']:
        a=r[key]['auc_'+h+'yr']
        val=ci(a['value'],a['ci95']) if a['value'] is not None else 'Not estimable'
        rows.append(f"{label} & {h} & {a['events_by_horizon']} & {a['observed_beyond_horizon']} & {a['censored_by_horizon']} & {val}"+r' \\')
(root/'auc_rows.tex').write_text('\\newcommand{\\AucRows}{%\n'+'\n'.join(rows)+'\n}\n')

# Repair doubly escaped TeX introduced in source metadata, then use a concise
# first-three-authors bibliography while preserving the full retrieved BibTeX.
refs=json.loads((root/'provenance/reference_retrieval.json').read_text())['references']
bib=(root/'references.bib').read_text().replace('\\\\','\\')
(root/'references.bib').write_text(bib)
lines=[r'\begin{thebibliography}{99}']
for v in refs:
    author=v['authors'].replace('\\\\','\\').split(' and ')
    first=author[0].split(',')[0]
    short=[]
    for a in author[:3]:
        last, given=a.split(', ',1)
        short.append(last+', '+given)
    names='; '.join(short)+('; et~al.' if len(author)>3 else '.')
    journal=v['journal'].replace('\\\\','\\')
    title=v['title'].replace('m6A',r'$m^6$A')
    lines.append(r'\bibitem['+first+' et~al.('+str(v['year'])+')]{'+v['key']+'}\n'+names+' ('+str(v['year'])+'). '+title+'. '+r'\emph{'+journal+'} '+r'\textbf{'+v['volume']+'}'+('('+v['number']+')' if v.get('number') else '')+', '+v['pages']+'. '+r'\href{https://doi.org/'+v['doi']+'}{doi:'+v['doi']+'}.')
lines.append(r'\end{thebibliography}')
(root/'references.tex').write_text('\n\n'.join(lines)+'\n')
print('Generated',len(macros),'numeric macros, 4 single-marker rows, 6 AUC rows,',len(refs),'references.')
