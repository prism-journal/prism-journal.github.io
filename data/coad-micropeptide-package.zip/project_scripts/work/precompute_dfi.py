from pathlib import Path
import sys
sys.path.insert(0,str(Path.cwd()))
import analysis as a
import argparse,json,logging
args=argparse.Namespace(data_dir=Path('data'),input_scale='xena-log2-counts',n_random=200,bootstrap=1000,jobs=2,prepare_only=False)
out=Path('work/dfi_precompute').resolve();out.mkdir(exist_ok=True)
work=Path('work/dfi_precompute_cache').resolve();work.mkdir(exist_ok=True)
logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
prov=json.loads(Path('cohorts/primary_dfi_stage_ii_iii/results.json').read_text())['provenance']
prov['analysis_sha256']=a.sha256('analysis.py');prov['n_random']=200
prov['module_sha256']={name:a.sha256(name) for name in ['survival_metrics.py','analysis_figures.py','fast_cox.py']}
if __name__=='__main__':
 a.run_cohort('dfi_all_stages','DFI','all_known',args,out,work,prov)
