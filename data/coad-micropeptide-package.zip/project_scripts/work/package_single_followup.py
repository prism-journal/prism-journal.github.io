from pathlib import Path
import hashlib,json,shutil
import numpy as np
import pandas as pd
root=Path.cwd()
r=json.loads((root/'results.json').read_text())
old=json.loads((root/'work/single_followup_archive/results.json').read_text())
qa=json.loads((root/'work/single_marker_followup_validation.json').read_text())
assert r['status']=='complete' and qa['status']=='passed'
mapping={'primary_dfi_stage_ii_iii':('primary_cohort','linc00675_single_bootstrap'),
         'dfi_all_stages':('stage_sensitivity_dfi_all_stages','linc00675_single_bootstrap_all_stages'),
         'secondary_os_all_stages':('secondary_cohort','elfn1as1_single_bootstrap')}
verification={'status':'passed','requested_targets':{},'previous_cohort_results_preserved':True}
fold_rows=[]
for name,(cohort,key) in mapping.items():
 b=r[key]; target=qa['targets'][name]; detail=r['single_marker_foldwise_cindex'][name]
 assert b['n_boot']==b['n_boot_valid']==1000
 np.testing.assert_allclose([b['cindex'],b['ci_lower'],b['ci_upper']],
     [target['c_index'],*target['c_index_ci95_independent_1000']],rtol=0,atol=1e-12)
 assert len(detail['folds'])==25 and detail['leakage_audit']['status']=='passed'
 native={(d['seed'],d['fold']):d for d in target['folds']}
 for fold in detail['folds']:
  check=native[(fold['seed'],fold['fold'])]
  assert abs(fold['c_index']-check['c_index'])<1e-12
  fold_rows.append(dict(cohort=name,marker=target['marker'],endpoint=target['endpoint'],**fold))
 for metric in ['eligible_patients','events','c_index','c_index_ci95','percentile_vs_random','random_panels_completed','auc_3yr','auc_5yr']:
  assert r[cohort][metric]==old[cohort][metric],(cohort,metric)
 prov=r[cohort]['provenance']
 assert prov['analysis_sha256']==hashlib.sha256((root/'analysis.py').read_bytes()).hexdigest()
 for f,hash_value in prov['module_sha256'].items():
  assert hash_value==hashlib.sha256((root/f).read_bytes()).hexdigest()
 verification['requested_targets'][name]={'bootstrap':b,'folds_verified':25,
      'native_risk_max_abs_difference':target['native_heldout_risk_max_abs_difference'],
      'heldout_perturbation':target['heldout_perturbation']}
# Independent direct log-rank score calculation over distinct observed event times.
d=pd.read_csv(root/'cohorts/primary_dfi_stage_ii_iii/linc00675_expression_km_groups.tsv',sep='\t')
low=d.expression_group.eq('low').to_numpy(); high=~low
t=d.time.to_numpy(); e=d.event.to_numpy(bool)
score=variance=0.
for event_time in np.unique(t[e]):
 at_risk=t>=event_time; deaths=(t==event_time)&e
 n=int(at_risk.sum()); n_high=int((at_risk&high).sum()); deaths_n=int(deaths.sum()); d_high=int((deaths&high).sum())
 score += d_high - deaths_n*n_high/n
 if n>1: variance += n_high*(n-n_high)*deaths_n*(n-deaths_n)/(n*n*(n-1))
from scipy.stats import chi2
statistic=score*score/variance
p=float(chi2.sf(statistic,1))
assert abs(p-r['logrank_p_linc00675'])<1e-12
assert len(d)==137 and int(d.event.sum())==18
assert r['linc00675_km_details']['groups']=={'low':{'n':69,'events':12},'high':{'n':68,'events':6}}
assert 'log-rank p = 0.1146' in (root/'figures/fig7_single_km_caption.tex').read_text()
for stem in ['fig7_single_km','fig7_single_km_plot','fig7_single_km_caption']:
 assert (root/'figures'/f'{stem}.tex').stat().st_size>0
assert (root/'figures/fig7_single_km.png').stat().st_size>0
# Existing requested figure exports must remain unchanged.
for stem in ['fig1_km','fig2_roc','fig3_forest','fig4_null','fig5_calib','fig6_single']:
 assert (root/'figures'/f'{stem}.tex').read_bytes()==(root/'outputs/coad_analysis_extended/figures'/f'{stem}.tex').read_bytes()
verification['existing_figures_1_to_6_unchanged']=True
verification['km_logrank_independent_check']={'p_value':p,'chi_square':statistic,'method':'Manually accumulated observed-minus-expected score and hypergeometric variance at each event time.'}
verification['figure7']={'png_visually_inspected':True,'caption_p_value_verified':True,'latex_compiled':False}
out=root/'outputs/coad_single_marker_followup';out.mkdir(parents=True,exist_ok=True)
for f in ['analysis.py','analysis_figures.py','survival_metrics.py','fast_cox.py','requirements.txt','results.json','audit.log','preamble.tex','analysis_progress.json']:
 shutil.copy2(root/f,out/f)
for f in ['figures','cohorts']:shutil.copytree(root/f,out/f,dirs_exist_ok=True)
shutil.copy2(root/'work/single_marker_followup_validation.json',out/'single_marker_validation.json')
(out/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
pd.DataFrame(fold_rows).to_csv(out/'single_marker_fold_cindices.tsv',sep='\t',index=False)
lines=['SINGLE-MARKER FOLLOW-UP: TCGA-COAD DFI AND OS','',
'This package preserves the previous cohort, panel, random-panel and AUC results, and adds explicit single-marker bootstrap summaries, per-fold estimates and the expression-median KM analysis.','',
'REQUESTED RESULTS']
for name,(_,key) in mapping.items():
 b=r[key];v=r['single_marker_foldwise_cindex'][name]['distribution']
 lines.append(f"{name}: {b['marker']}, C={b['cindex']:.9f}, 1000-bootstrap 95% CI=[{b['ci_lower']:.9f}, {b['ci_upper']:.9f}].")
 lines.append(f"  Across 25 outer folds: mean={v['unweighted_mean']:.6f}, SD={v['sample_sd']:.6f}, median={v['median']:.6f}, IQR=[{v['q25']:.6f}, {v['q75']:.6f}], range=[{v['minimum']:.6f}, {v['maximum']:.6f}].")
lines += ['',
'JSON FIELDS',
'linc00675_single_bootstrap refers to primary DFI stages II/III; linc00675_single_bootstrap_all_stages reports all-stage DFI. The same linc00675_single_bootstrap key is also provided inside the corresponding cohort objects. elfn1as1_single_bootstrap refers to all-stage OS.',
'logrank_p_linc00675 is the primary-cohort expression-median log-rank p-value. Detailed group counts, cutpoint and test statistic are in linc00675_km_details. Full fold-level results are in single_marker_foldwise_cindex and single_marker_fold_cindices.tsv.','',
'VALIDATION AND INTERPRETATION',
'All reported C-indices are held out. Every unpenalized single-marker Cox model is fitted only on the corresponding outer training patients, using exactly the panel\'s five outer folds and five seeds. Measurement gating, imputation and scaling are fitted inside training. The same three inner partitions are checked for containment; the fixed unpenalized univariate model has no hyperparameters requiring inner tuning.',
'Independent native lifelines refits of all 75 requested models reproduce held-out predictions within 2.3e-15. Perturbing only held-out expression and outcomes leaves fitted training preprocessing and coefficients unchanged. No outer train/test patient overlap was found; all 225 inner partitions were contained in their outer training sets. See single_marker_validation.json.',
'The 1000 percentile bootstrap samples resample patients, keeping all repeated out-of-fold predictions for each sampled patient together. Confidence intervals condition on these fitted models; they do not rerun fitting or marker selection within each bootstrap. Marker selection following earlier results remains post hoc and is not externally validated.',
'Overall Harrell C weights comparable pairs within each outer fold, combines counts within seed, then averages five seeds. The descriptive unweighted mean of 25 fold C-indices therefore differs from the overall estimate; folds are not independent observations.','',
'FIGURE 7',
f"Median LINC00675 expression={r['linc00675_km_details']['median_expression']:.9f} log2(CPM+1). Low<=median: n69,12 DFI events; high>median: n68,6 events. Unadjusted log-rank p={p:.9f}.",
'The whole-cohort median is used only for this descriptive KM figure. It never enters Cox fitting, gating, scaling or C-index scoring. Groups indicate expression, not risk. The log-rank test is post hoc and unadjusted for marker selection/multiple testing. It is a separate comparison from continuous-expression Cox discrimination.',
'fig7_single_km.tex includes the caption below the plot, and fig7_single_km.png is its preview. For a publication figure environment, use the caption-free fig7_single_km_plot.tex followed by fig7_single_km_caption.tex. Include preamble.tex in the document preamble. PNG visually inspected and TeX structurally checked; LaTeX compilation was not available.','',
'RERUN',
'Keep the four Python modules together, install requirements.txt, and put the original TCGA expression/CDR files in data/. Run: python analysis.py --jobs 8',
'The default run uses 1000 bootstrap replicates and 1000 random panels per cohort. Existing fingerprint-verified panel checkpoints are reused; single-marker fits and bootstrap estimates are recomputed. Large inputs and caches are omitted from this bundle.','',
'PRIMARY REFERENCES',
'https://lifelines.readthedocs.io/en/latest/lifelines.statistics.html#lifelines.statistics.logrank_test',
'https://scikit-survival.readthedocs.io/en/stable/api/generated/sksurv.metrics.concordance_index_censored.html']
(out/'ANALYSIS_NOTES.txt').write_text('\n'.join(lines)+'\n')
manifest={str(f.relative_to(out)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(out.rglob('*')) if f.is_file() and f.name!='manifest_sha256.json'}
(out/'manifest_sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
shutil.make_archive(str(out),'zip',out)
print(json.dumps({'status':'passed','files':len(manifest),'output':str(out),'logrank_p':p,'native_fits_verified':75,'bootstrap_replicates_per_target':1000},indent=2))
