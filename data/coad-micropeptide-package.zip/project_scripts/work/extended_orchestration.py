# Code below is incorporated into analysis.py; this scratch file is not an entry point.
COHORTS = {
    'primary_dfi_stage_ii_iii': ('DFI', 'ii_iii'),
    'secondary_os_all_stages': ('OS', 'all_known'),
    'dfi_all_stages': ('DFI', 'all_known'),
}
MODEL_FUNCTIONS = ['make_splits', 'preprocessing', 'c_summary', 'fit_cox',
                   'zero_solution_bound', 'rebase', 'predict', 'tune', 'run_panel', 'fit_final']


def model_ast(path):
    tree = ast.parse(Path(path).read_text())
    return {node.name: ast.dump(node, include_attributes=False)
            for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in MODEL_FUNCTIONS}


def verify_legacy_primary(args, cache, provenance):
    """Reuse finished primary predictions only after checking model, data and splits.

    The original fingerprint is retained in each imported result. Figures and
    metric labels changed, so file-level hashes alone cannot establish identity.
    """
    old, archive = args.legacy_primary_cache.resolve(), args.primary_archive.resolve()
    if not (old / 'real_panel.json').exists() or not (archive / 'analysis.py').exists():
        return None
    old_prov = json.loads((old / 'provenance.json').read_text())
    for key in ['expression_sha256', 'clinical_sha256', 'input_scale', 'seeds', 'grid']:
        # JSON-normalize tuples in GRID before comparison.
        if json.dumps(old_prov[key], sort_keys=True) != json.dumps(provenance[key], sort_keys=True):
            raise ValueError(f'Legacy primary reuse rejected: {key} differs.')
    if model_ast(archive / 'analysis.py') != model_ast(__file__):
        raise ValueError('Legacy primary reuse rejected: model functions changed.')
    old_tree = ast.parse((archive / 'analysis.py').read_text())
    old_threshold = next(ast.literal_eval(n.value) for n in old_tree.body
                         if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'RETENTION_THRESHOLD' for t in n.targets))
    if old_threshold != RETENTION_THRESHOLD:
        raise ValueError('Legacy primary reuse rejected: retention threshold differs.')
    if old_prov['module_sha256']['fast_cox.py'] != sha256(Path(__file__).with_name('fast_cox.py')):
        raise ValueError('Legacy primary reuse rejected: Cox implementation changed.')
    for name in ['numpy', 'pandas', 'scipy', 'scikit-learn', 'lifelines', 'scikit-survival']:
        if old_prov['package_versions'][name] != provenance['package_versions'][name]:
            raise ValueError(f'Legacy primary reuse rejected: {name} changed.')
    for name in ['cpm.npy', 'logx.npy', 'genes.npy', 'outcomes.tsv', 'cv_splits.json']:
        if sha256(old / name) != sha256(cache / name):
            raise ValueError(f'Legacy primary reuse rejected: {name} differs.')
    legacy_fingerprint = hashlib.sha256(json.dumps(old_prov, sort_keys=True).encode()).hexdigest()
    real = json.loads((old / 'real_panel.json').read_text())
    if real['fingerprint'] != legacy_fingerprint:
        raise ValueError('Legacy primary cache does not match its provenance.')
    LOG.info('PRIMARY REUSE verified: exact model AST, threshold, libraries, inputs, CPM/log matrix, outcomes and CV splits match the completed primary run.')
    return old, legacy_fingerprint


def run_single_marker(index, cpm, logx, y, splits):
    """Unpenalized univariate Cox; same outer folds and training-only gate.

    No inner tuning is needed: this benchmark has no free hyperparameters.
    A training-gate failure produces a constant-risk model for that fold.
    """
    records, folds = [], []
    indices = np.asarray([index])
    for split in splits:
        train, test = split['train'], split['test']
        a, b, pos, _ = preprocessing(cpm, logx, indices, train, test)
        model = fit_cox(a, y.iloc[train], (0., 0.)) if len(pos) else None
        risk, trainrisk = predict(model, b), predict(model, a)
        pct = ((trainrisk[:, None] < risk).sum(0) + .5 * (trainrisk[:, None] == risk).sum(0)) / len(train)
        if model is None:
            km = KaplanMeierFitter().fit(y.iloc[train].time, y.iloc[train].event)
            surv = np.repeat(km.predict(list(HORIZONS.values())).to_numpy()[:, None], len(test), axis=1)
        else:
            rebase(model, a, y.iloc[train])
            surv = model.predict_survival_function(pd.DataFrame(b, columns=model.params_.index), times=list(HORIZONS.values())).to_numpy()
        for j, patient in enumerate(test):
            records.append({'seed': split['seed'], 'fold': split['fold'],
                'patient_id': y.iloc[patient].patient_id, 'time': float(y.iloc[patient].time),
                'event': bool(y.iloc[patient].event), 'risk': float(risk[j]),
                'risk_percentile': float(pct[j]), 's36': float(surv[0, j]), 's60': float(surv[1, j])})
        folds.append({'seed': split['seed'], 'fold': split['fold'], 'gate_passed': bool(len(pos)),
                      'coefficient': float(model.params_.iloc[0]) if model is not None else None})
    return pd.DataFrame(records), folds


def run_cohort(name, endpoint, stage_group, args, outdir, workroot, base_provenance):
    from survival_metrics import evaluate_oof, paired_c_index_differences
    cohort_dir, cache = outdir / 'cohorts' / name, workroot / name
    cohort_dir.mkdir(parents=True, exist_ok=True)
    (cache / 'null_panels').mkdir(parents=True, exist_ok=True)
    LOG.info('BEGIN COHORT %s; endpoint=%s; stages=%s', name, endpoint, stage_group)
    cpm, logx, genes, y, audit = load_data(
        args.data_dir / 'TCGA-COAD.star_counts.tsv.gz',
        args.data_dir / 'TCGA-CDR-SupplementalTableS1.xlsx', args.input_scale, cache,
        endpoint=endpoint, stage_group=stage_group)
    splits = make_splits(y)
    atomic_json(splits, cache / 'cv_splits.json')
    atomic_json(audit, cohort_dir / 'filtering_audit.json')
    for split in splits:
        LOG.info('FOLD %s seed=%d fold=%d trainN=%d trainEvents=%d testN=%d testEvents=%d', name,
                 split['seed'], split['fold'], len(split['train']), y.iloc[split['train']].event.sum(),
                 len(split['test']), y.iloc[split['test']].event.sum())
    provenance = dict(base_provenance, cohort=name, endpoint=endpoint, stage_group=stage_group)
    # Prediction caches depend on model semantics and input contents, not figure styling.
    prediction_spec = {k: provenance[k] for k in ['expression_sha256', 'clinical_sha256', 'input_scale', 'seeds', 'grid', 'package_versions', 'cohort', 'endpoint', 'stage_group']}
    prediction_spec.update(model_ast=model_ast(__file__), fast_cox_sha256=sha256(Path(__file__).with_name('fast_cox.py')),
        retention_threshold=RETENTION_THRESHOLD,
        data_sha256={p: sha256(cache / p) for p in ['cpm.npy', 'logx.npy', 'genes.npy', 'outcomes.tsv', 'cv_splits.json']})
    fingerprint = hashlib.sha256(json.dumps(prediction_spec, sort_keys=True).encode()).hexdigest()
    provenance['prediction_fingerprint'] = fingerprint
    atomic_json(provenance, cache / 'provenance.json')
    atomic_json(prediction_spec, cache / 'prediction_specification.json')
    if args.prepare_only:
        return None
    legacy = verify_legacy_primary(args, cache, base_provenance) if name == 'primary_dfi_stage_ii_iii' else None
    indices = np.asarray([np.flatnonzero(genes == gene)[0] for gene in PANEL])
    real_cache = cache / 'real_panel.json'
    real = json.loads(real_cache.read_text()) if real_cache.exists() else {}
    if real.get('fingerprint') == fingerprint:
        LOG.info('Reusing fingerprint-verified panel predictions: %s', name)
    elif legacy:
        real = json.loads((legacy[0] / 'real_panel.json').read_text())
        real['legacy_fingerprint'] = real['fingerprint']
        real['fingerprint'] = fingerprint
        atomic_json(real, real_cache)
    else:
        real = run_panel(indices, cpm, logx, genes, y, splits, detailed=True)
        real['fingerprint'] = fingerprint
        atomic_json(real, real_cache)
    oof = pd.DataFrame(real['oof'])
    oof.to_csv(cohort_dir / 'oof_predictions.tsv', sep='\t', index=False)
    atomic_json(real['folds'], cohort_dir / 'outer_fold_audit.json')
    fold_training = {(s['seed'], s['fold']): y.iloc[s['train']][['time', 'event']] for s in splits}
    metrics, plotting = evaluate_oof(oof, fold_training, n_bootstrap=args.bootstrap, seed=20261013, horizons=HORIZONS, endpoint=endpoint)
    if not np.isclose(metrics['c_index'], real['c_index'], atol=1e-12):
        raise ValueError('C-index aggregation mismatch.')
    atomic_json(metrics, cohort_dir / 'metrics.json')
    LOG.info('PANEL %s C=%.6f CI=%s; AUC36=%s AUC60=%s', name, metrics['c_index'], metrics['c_index_ci95'], metrics['auc']['36']['status'], metrics['auc']['60']['status'])
    single_results, single_oofs = {}, {}
    single_dir = cohort_dir / 'single_markers'
    single_dir.mkdir(exist_ok=True)
    for gene, index in zip(PANEL, indices):
        single, folds = run_single_marker(index, cpm, logx, y, splits)
        sm, _ = evaluate_oof(single, fold_training, n_bootstrap=args.bootstrap, seed=20261013, horizons=HORIZONS, endpoint=endpoint)
        single.to_csv(single_dir / f'{gene}_oof.tsv', sep='\t', index=False)
        atomic_json(folds, single_dir / f'{gene}_folds.json')
        single_results[gene] = {'marker': PANEL[gene], 'c_index': sm['c_index'], 'c_index_ci95': sm['c_index_ci95'],
            'c_index_by_seed': sm['c_index_by_seed'], 'measurement_gate_passed_folds': sum(f['gate_passed'] for f in folds),
            'total_outer_folds': len(folds), 'method': 'Unpenalized univariate Cox; same outer CV splits and training-only preprocessing; no hyperparameter tuning.'}
        single_oofs[gene] = single
        LOG.info('SINGLE %s %s C=%.6f CI=%s', name, PANEL[gene], sm['c_index'], sm['c_index_ci95'])
    paired = paired_c_index_differences(oof, single_oofs, n_bootstrap=args.bootstrap, seed=20261013, endpoint=endpoint)
    for gene in single_results:
        single_results[gene]['panel_minus_single'] = paired['comparisons'][gene]
    atomic_json(single_results, cohort_dir / 'single_marker_benchmarks.json')
    universe = np.flatnonzero(~np.isin(genes, list(PANEL)))
    rng, random_panels, seen = np.random.default_rng(20261013), [], set()
    while len(random_panels) < args.n_random:
        draw = tuple(sorted(map(int, rng.choice(universe, 4, replace=False))))
        if draw not in seen:
            seen.add(draw); random_panels.append(list(draw))
    atomic_json({'seed': 20261013, 'universe_size': len(universe), 'panels': [genes[p].tolist() for p in random_panels]}, cohort_dir / 'random_panel_definitions.json')
    if legacy:
        imported = 0
        for number, panel in enumerate(random_panels):
            path = legacy[0] / 'null_panels' / f'panel_{number:04d}.json'
            if not path.exists(): continue
            saved = json.loads(path.read_text())
            if saved['fingerprint'] != legacy[1] or saved['gene_indices'] != panel:
                raise ValueError(f'Legacy random panel {number} fails provenance/draw identity check.')
            saved['legacy_fingerprint'] = saved['fingerprint']
            saved['fingerprint'] = fingerprint
            atomic_json(saved, cache / 'null_panels' / path.name)
            imported += 1
        provenance['legacy_primary_reuse'] = {'random_panels_imported': imported, 'legacy_fingerprint': legacy[1],
            'verification': 'Exact model AST, coefficient threshold, Cox module, numerical package versions, input files, normalized expression, outcomes and CV splits matched.'}
        LOG.info('Imported %d verified completed primary random panels.', imported)
    LOG.info('NULL %s: %d random four-gene panels; same nested CV; %d workers.', name, args.n_random, args.jobs)
    stream = Parallel(n_jobs=args.jobs, return_as='generator_unordered', pre_dispatch=args.jobs)(
        delayed(null_worker)(i, panel, cache, splits, fingerprint) for i, panel in enumerate(random_panels))
    nulls = []
    for result in stream:
        nulls.append(result)
        LOG.info('NULL %s completed %d/%d: panel=%d C=%.4f seconds=%.1f failures=%d', name, len(nulls), args.n_random,
                 result['panel_number'], result['c_index'], result['seconds'], result['fit_failures'])
        atomic_json({'status': 'running', 'cohort': name, 'completed_random_panels': len(nulls), 'requested_random_panels': args.n_random,
            'real_panel_c_index': real['c_index'], 'updated_utc': datetime.now(timezone.utc).isoformat()}, outdir / 'analysis_progress.json')
    nulls.sort(key=lambda v: v['panel_number'])
    null_scores = np.array([v['c_index'] for v in nulls])
    pd.DataFrame([{'panel_number': v['panel_number'], 'genes': ';'.join(v['genes']), 'c_index': v['c_index'],
        'fit_failures': v['fit_failures']} for v in nulls]).to_csv(cohort_dir / 'random_panel_scores.tsv', sep='\t', index=False)
    model, state, forest, final_meta = fit_final(cpm, logx, indices, genes, y)
    forest.to_csv(cohort_dir / 'final_model_coefficients.tsv', sep='\t', index=False)
    with (cohort_dir / 'final_model.pkl').open('wb') as handle:
        pickle.dump({'model': model, 'preprocessing': state, 'metadata': final_meta}, handle)
    outer_retention = {gene: sum(gene in f['retained'] for f in real['folds']) for gene in PANEL}
    summary = {'endpoint': endpoint, 'stage_group': 'II/III' if stage_group == 'ii_iii' else 'I/II/III/IV (known stage)',
        'eligible_patients': len(y), 'events': int(y.event.sum()), f'{endpoint.lower()}_events': int(y.event.sum()),
        'ensembl_ids_used': list(PANEL), 'retained_transcripts': forest.loc[forest.retained, ['ensembl', 'marker']].to_dict('records'),
        'outer_fold_retention_counts': outer_retention, 'outer_folds': len(splits),
        'c_index': real['c_index'], 'c_index_ci95': metrics['c_index_ci95'], 'c_index_by_seed': metrics['c_index_by_seed'],
        'median_followup_days': metrics['median_followup_days'], 'median_followup_months': metrics['median_followup_months'],
        'auc_3yr': {k: v for k, v in metrics['auc']['36'].items() if k != 'outer_fold_diagnostics'},
        'auc_5yr': {k: v for k, v in metrics['auc']['60'].items() if k != 'outer_fold_diagnostics'},
        'percentile_vs_random': float(100 * ((null_scores < real['c_index'] - 1e-12).sum() + .5 * np.isclose(null_scores, real['c_index'], atol=1e-12, rtol=0).sum()) / len(null_scores)),
        'random_panels_completed': len(nulls), 'random_panel_mean_c_index': float(null_scores.mean()),
        'random_panel_median_c_index': float(np.median(null_scores)),
        'random_panel_one_sided_empirical_p': float((1 + (null_scores >= real['c_index']).sum()) / (1 + len(null_scores))),
        'fit_failures': {'real_inner_candidates': real['fit_failures'], 'random_inner_candidates': sum(v['fit_failures'] for v in nulls),
                         'random_panels_with_failed_candidates': sum(v['fit_failures'] > 0 for v in nulls)},
        'final_model': final_meta, 'filtering_audit': audit, 'provenance': provenance,
        'single_marker_benchmarks': single_results, 'metrics_path': f'cohorts/{name}/metrics.json'}
    atomic_json(summary, cohort_dir / 'results.json')
    LOG.info('COMPLETE COHORT %s: C=%.6f; percentile=%.3f; empirical p=%.6f', name, real['c_index'], summary['percentile_vs_random'], summary['random_panel_one_sided_empirical_p'])
    return summary, plotting, forest, null_scores


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir', type=Path, default=Path('data'))
    parser.add_argument('--output-dir', type=Path, default=Path('.'))
    parser.add_argument('--work-dir', type=Path, default=Path('work/extended_cache'))
    parser.add_argument('--legacy-primary-cache', type=Path, default=Path('work/analysis_cache'))
    parser.add_argument('--primary-archive', type=Path, default=Path('work/primary_archive'))
    parser.add_argument('--input-scale', choices=['xena-log2-counts', 'raw-counts'], default='xena-log2-counts')
    parser.add_argument('--n-random', type=int, default=1000)
    parser.add_argument('--bootstrap', type=int, default=1000)
    parser.add_argument('--jobs', type=int, default=8)
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    if min(args.n_random, args.bootstrap, args.jobs) < 1: parser.error('Counts and jobs must be positive.')
    outdir, workroot = args.output_dir.resolve(), args.work_dir.resolve()
    outdir.mkdir(parents=True, exist_ok=True); workroot.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s',
        handlers=[logging.FileHandler(outdir / 'audit.log', mode='w'), logging.StreamHandler(sys.stdout)])
    started = datetime.now(timezone.utc).isoformat()
    LOG.info('DFI stage II/III remains primary; OS known stages I-IV is secondary; DFI known stages I-IV is a stage sensitivity analysis.')
    LOG.info('DFI is disease-free interval; OS is overall survival. Neither is relabeled RFS. Unknown/discrepant stages excluded without imputation.')
    LOG.info('Five fixed seeds %s; 5 outer x 3 inner CV. Training-only gate/imputation/scaling; no batch correction. Full-library CPM is sample-local.', SEEDS)
    LOG.info('Xena inverse transform preserves fractional averaged counts. Numerical L1 zero rule abs(coef)<%g; exact Efron acceleration/KKT bound.', RETENTION_THRESHOLD)
    LOG.info('AUC support unchanged: every outer fold needs >=3 cases, >=5 controls, >=10 training beyond horizon, G(t)>=0.05. No threshold adjustment to force an estimate.')
    provenance = {'expression_sha256': sha256(args.data_dir / 'TCGA-COAD.star_counts.tsv.gz'),
        'clinical_sha256': sha256(args.data_dir / 'TCGA-CDR-SupplementalTableS1.xlsx'),
        'analysis_sha256': sha256(__file__), 'seeds': SEEDS, 'grid': GRID,
        'module_sha256': {name: sha256(Path(__file__).with_name(name)) for name in ['survival_metrics.py', 'analysis_figures.py', 'fast_cox.py']},
        'input_scale': args.input_scale, 'n_random': args.n_random, 'bootstrap': args.bootstrap,
        'xena_metadata_url': 'https://gdc.xenahubs.net/download/TCGA-COAD.star_counts.tsv.json',
        'xena_metadata_verified_unit': 'log2(count+1)',
        'package_versions': {p: importlib.metadata.version(p) for p in ['numpy','pandas','scipy','scikit-learn','lifelines','scikit-survival','matplotlib','matplot2tikz']}}
    completed = {name: run_cohort(name, *spec, args, outdir, workroot, provenance) for name, spec in COHORTS.items()}
    if args.prepare_only: return
    primary = completed['primary_dfi_stage_ii_iii']
    secondary = completed['secondary_os_all_stages']
    singles = {name: value[0]['single_marker_benchmarks'] for name, value in completed.items()}
    from analysis_figures import export_figures, export_extended_figures
    figure_meta = export_figures(outdir / 'figures', primary[1], primary[2].loc[primary[2].retained], primary[3], primary[0]['c_index'], preamble_path=outdir / 'preamble.tex')
    figure_meta.update(export_extended_figures(outdir / 'figures', primary[1], secondary[1], singles,
        primary[0]['c_index'], secondary[0]['c_index'], preamble_path=outdir / 'preamble.tex'))
    # Also provide endpoint-specific secondary forest/null/calibration figures.
    secondary_figures = export_figures(outdir / 'figures' / 'secondary_os', secondary[1], secondary[2].loc[secondary[2].retained], secondary[3], secondary[0]['c_index'], preamble_path=outdir / 'preamble.tex')
    results = {'status': 'complete', 'started_utc': started, 'completed_utc': datetime.now(timezone.utc).isoformat(),
        'ensembl_ids_used': list(PANEL), 'markers': PANEL,
        'excluded_marker': {'LINC00266-1 / RBRP': 'No stable Ensembl ID resolved; excluded, not zero-imputed.'},
        'primary_cohort': primary[0], 'secondary_cohort': secondary[0],
        'stage_sensitivity_dfi_all_stages': completed['dfi_all_stages'][0],
        'single_marker_benchmarks': {name: {PANEL[gene]: value['c_index'] for gene, value in records.items()} for name, records in singles.items()},
        'single_marker_details': singles,
        'auc_results': {name: {'endpoint': value[0]['endpoint'], '36_months': value[0]['auc_3yr'], '60_months': value[0]['auc_5yr']} for name, value in completed.items()},
        'validation': {'outer_folds': 5, 'inner_folds': 3, 'seeds': SEEDS, 'bootstrap_replicates': args.bootstrap,
            'c_index_method': 'Comparable pairs within each outer fold; counts combined within seed; mean across five seeds.',
            'ci_method': 'Patient-cluster percentile bootstrap conditional on fitted out-of-fold models; no nested CV refits inside bootstrap.',
            'single_marker_method': 'Unpenalized univariate Cox, same outer splits and training-only preprocessing; no inner hyperparameters.',
            'stage_policy': 'Include known AJCC stages I-IV and substages; exclude unknown/discrepant stage values.',
            'auc_support': 'All 25 outer folds: >=3 test cases, >=5 test controls, >=10 training observations beyond horizon, censoring G(t)>=0.05.',
            'random_panels': 'Same 1000 (or --n-random) annotation-universe four-gene draws across cohorts; targets excluded; same nested CV and measurement gate.'},
        'figures': figure_meta, 'secondary_figures': secondary_figures,
        'limitations': ['Internal validation only; no independent cohort.',
            'Secondary analyses were added after examining primary results and are exploratory.',
            'OS includes death from any cause and is not a recurrence endpoint; stage IV OS is not an adjuvant recurrence cohort.',
            'Only 18 primary DFI events and 21 all-stage DFI events; stage relaxation does not resolve sparse recurrence outcomes.',
            'Micropeptide-source bulk RNA is a proxy; no peptide abundance is measured.',
            'Uniform random panels are not expression-matched; the baseline is empirical, not fixed at 0.50.',
            'Final refit retention can differ from fold-specific retention; single-marker comparisons are paired, exploratory and not multiplicity-adjusted.',
            'Penalized forest Wald intervals ignore selection; KM and calibration figures are descriptive.',
            'Bootstrap intervals condition on fitted models and censoring distributions; they omit model-selection uncertainty.']}
    atomic_json(results, outdir / 'results.json')
    atomic_json({'status': 'complete', 'cohorts': {name: {'random_panels_completed': value[0]['random_panels_completed'], 'c_index': value[0]['c_index']} for name, value in completed.items()},
        'updated_utc': datetime.now(timezone.utc).isoformat()}, outdir / 'analysis_progress.json')
    LOG.info('COMPLETE: all three cohorts, single-marker comparisons and figures saved to %s', outdir)


if __name__ == '__main__':
    main()
