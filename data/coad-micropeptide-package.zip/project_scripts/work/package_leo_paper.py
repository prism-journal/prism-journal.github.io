"""Assemble a data-free manuscript/code/results archive from this workspace.

Run from the original workspace with its completed inventory and manuscript.
This is a provenance helper; the supported analysis entry point is analysis.py.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent.parent
STAGE = ROOT / 'work/leo_paper_bundle'
BLOCKED_PARTS = {'.git', '.venv', 'venv', 'site-packages', '__pycache__',
                 '.ipynb_checkpoints', 'expression_raw', 'texruntime',
                 'leo_paper_bundle', 'package_extraction_check'}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def excluded(path):
    return (bool(set(path.parts) & BLOCKED_PARTS)
            or path.name == '.DS_Store'
            or path.suffix.lower() in {'.xlsx', '.xls', '.zip', '.pyc'}
            or path.name in {'cpm.npy', 'logx.npy'}
            or path.name.startswith('TCGA-COAD.star_counts.tsv')
            or path.name in {'TCGA-CDR-SupplementalTableS1.tsv', 'clinical_matched.tsv'}
            or path.name.startswith('tcga_coad_unstranded.tsv'))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--publish', action='store_true',
                        help='Write requested archive at project root; otherwise prepare only.')
    args = parser.parse_args()
    inventory = json.loads((ROOT / 'work/package_inventory.json').read_text())
    if STAGE.exists():
        shutil.rmtree(STAGE)
    STAGE.mkdir(parents=True)
    mapping = []
    destinations = set()

    def copy(source, destination, role):
        source = Path(source)
        if not source.is_absolute():
            source = ROOT / source
        relative = source.relative_to(ROOT)
        if excluded(relative):
            raise ValueError(f'Attempted excluded source: {relative}')
        destination = Path(destination)
        if destination.as_posix() in destinations:
            raise ValueError(f'Duplicate archive member: {destination}')
        target = STAGE / destination
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        destinations.add(destination.as_posix())
        mapping.append({'source':relative.as_posix(), 'archive':destination.as_posix(),
                        'role':role, 'bytes':target.stat().st_size, 'sha256':digest(target)})

    # Authoritative, self-contained manuscript. Runtime files are not needed.
    manuscript = ROOT / 'outputs/coad_manuscript'
    for p in sorted(manuscript.rglob('*')):
        if p.is_file() and not excluded(p.relative_to(ROOT)):
            copy(p, Path('manuscript') / p.relative_to(manuscript), 'current manuscript')

    current_modules = ['analysis.py','analysis_figures.py','survival_metrics.py','fast_cox.py']
    for name in current_modules:
        copy(name, Path('analysis')/name, 'current analysis code')
    copy('outputs/download_tcga_coad.py','analysis/download_tcga_coad.py','GDC download utility')
    copy('requirements.txt','requirements.txt','exact pip freeze environment record')
    copy('requirements.txt','analysis/requirements.txt','exact pip freeze environment record')
    copy('outputs/coad_single_marker_followup/requirements.txt',
         'analysis/requirements-analysis.txt','portable direct analysis requirements')
    copy('work/package_docs/README.md','README.md','package documentation')
    copy('work/package_docs/analysis_README.md','analysis/README.md','analysis documentation')

    # Canonical saved outputs from the current pipeline. All original figure
    # TeX and PNG files are included; manuscript layout copies are separate.
    for p in sorted(ROOT.iterdir()):
        if p.is_file() and p.suffix in {'.json','.tsv','.log'} and not excluded(p.relative_to(ROOT)):
            copy(p, Path('analysis')/p.name, 'saved analysis result')
    for directory in ['cohorts','figures']:
        for p in sorted((ROOT/directory).rglob('*')):
            if p.is_file() and not excluded(p.relative_to(ROOT)):
                copy(p,Path('analysis')/p.relative_to(ROOT),'saved cohort or figure output')
    for name in ['single_marker_validation.json','single_marker_fold_cindices.tsv','verification.json',
                 'ANALYSIS_NOTES.txt']:
        p=ROOT/'outputs/coad_single_marker_followup'/name
        if p.exists() and f'analysis/{name}' not in destinations:
            copy(p,Path('analysis')/name,'follow-up validation or notes')

    # Preserve every authored Python file, including distinct historical
    # copies and scripts added after the independent inventory was generated.
    python_sources=[]
    for folder, dirs, files in os.walk(ROOT):
        dirs[:] = sorted(d for d in dirs if d not in BLOCKED_PARTS and d not in {'.codex','.agents'})
        for name in sorted(files):
            p=Path(folder)/name
            if p.suffix=='.py' and not excluded(p.relative_to(ROOT)):
                python_sources.append(p)
    for p in sorted(python_sources):
        copy(p,Path('project_scripts')/p.relative_to(ROOT),'authored Python provenance; original relative path')

    # Historical/QA intermediates retain their original paths, clearly
    # separated from the final results. Large expression matrices stay out.
    for entry in inventory['files']:
        rel=Path(entry['path']); p=ROOT/rel
        if entry['action']!='include' or excluded(rel) or p.suffix=='.py':
            continue
        if rel.parts[0] in {'figures','cohorts'} or len(rel.parts)==1:
            continue
        if rel.parts[:2] in {('outputs','coad_manuscript'),('work','manuscript'),
                              ('work','package_docs')}:
            continue
        if not p.is_file():
            raise FileNotFoundError(p)
        copy(p,Path('intermediate_results')/rel,entry['category'])

    copy('work/package_inventory.json','provenance/source_inventory.json','independent source inventory')
    for name in ['figure_layout_verification.json','removed_figure_notes.json']:
        copy(Path('outputs/coad_manuscript/provenance')/name,Path('provenance')/name,'manuscript figure checks')
    # Excluded source manifests are documented without including raw bytes.
    (STAGE/'provenance/excluded_inputs.json').write_text(json.dumps({
        'source_data_included':False,
        'exclusions':[x for x in inventory['files'] if x['action']=='omit'],
        'runtime_and_cache_directory_exclusions':inventory['excluded_directories']},indent=2)+'\n')
    (STAGE/'provenance/source_to_archive_manifest.json').write_text(json.dumps(mapping,indent=2)+'\n')
    files=sorted(p for p in STAGE.rglob('*') if p.is_file())
    assert all(not excluded(p.relative_to(STAGE)) for p in files)
    required=['README.md','requirements.txt','manuscript/main.tex','manuscript/main.pdf',
              'manuscript/preamble.tex','manuscript/references.tex','manuscript/references.bib',
              'manuscript/numbers.tex','analysis/analysis.py','analysis/download_tcga_coad.py',
              'analysis/requirements-analysis.txt','analysis/README.md','analysis/results.json','analysis/audit.log']
    assert all((STAGE/p).is_file() for p in required)
    assert r'\author{Leo Lee}' in (STAGE/'manuscript/main.tex').read_text()
    assert digest(STAGE/'analysis/requirements.txt')==digest(ROOT/'requirements.txt')
    assert len([p for p in files if p.relative_to(STAGE).parts[0]=='project_scripts'])==len(python_sources)
    checks={'status':'prepared','files_before_manifests':len(files),'authored_python_paths':len(python_sources),
            'all_authored_python_included':True,'raw_expression_and_cdr_excluded':True,
            'complete_project_file_mapping':'provenance/source_to_archive_manifest.json',
            'requirements_freeze_preserved':True,'archive_raw_bytes':sum(p.stat().st_size for p in files),
            'note':'Historical and test results are provenance, not additional scientific replication.'}
    (STAGE/'provenance/package_validation.json').write_text(json.dumps(checks,indent=2)+'\n')
    hashes={str(p.relative_to(STAGE)):digest(p) for p in sorted(STAGE.rglob('*')) if p.is_file()}
    (STAGE/'manifest.sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
    if args.publish:
        archive=ROOT/'leo_lee_coad_paper.zip'
        with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for p in sorted(STAGE.rglob('*')):
                if p.is_file():
                    z.write(p,p.relative_to(STAGE))
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
            names=z.namelist()
            assert len(names)==len(set(names))
            assert all(not excluded(Path(x)) for x in names)
        listing=subprocess.run(['unzip','-l',str(archive)],check=True,capture_output=True,text=True).stdout
        listing_path=ROOT/'outputs/leo_lee_coad_paper_file_listing.txt'
        listing_path.write_text(listing)
        # A hard link exposes the one archive in the output panel while
        # preserving the user-requested actual file at the project root.
        alias=ROOT/'outputs/leo_lee_coad_paper.zip'
        if alias.exists():alias.unlink()
        os.link(archive,alias)
        checks.update({'status':'complete','archive':str(archive),'archive_bytes':archive.stat().st_size,
                       'archive_sha256':digest(archive),'zip_members':len(names),
                       'complete_unzip_listing':str(listing_path),'zip_crc_check':'passed'})
        (ROOT/'outputs/leo_lee_coad_paper_validation.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(json.dumps(checks,indent=2))

if __name__=='__main__':
    main()
