"""Package completed, verified extended analysis; run only after final cached rerun."""
from pathlib import Path
import hashlib,json,shutil
import numpy as np
import pandas as pd
root=Path.cwd(); out=root/'outputs/coad_analysis_extended'
r=json.loads((root/'results.json').read_text())
assert r['status']=='complete'
assert r['validation']['bootstrap_replicates']==1000
cohorts={'primary_dfi_stage_ii_iii':r['primary_cohort'],'secondary_os_all_stages':r['secondary_cohort'],'dfi_all_stages':r['stage_sensitivity_dfi_all_stages']}
expected={'primary_dfi_stage_ii_iii':(137,18),'secondary_os_all_stages':(428,93),'dfi_all_stages':(181,21)}
verification={'status':'passed','checks':{},'limitations':['LaTeX compilation unavailable; PNG visual inspection and TeX/preamble source checks performed.']}
for name,s in cohorts.items():
 d=root/'cohorts'/name
 assert (s['eligible_patients'],s['events'])==expected[name]
 assert s['random_panels_completed']==1000
 null=pd.read_csv(d/'random_panel_scores.tsv',sep='\t')
 assert len(null)==1000 and null.panel_number.is_unique and null.c_index.between(0,1).all()
 oof=pd.read_csv(d/'oof_predictions.tsv',sep='\t')
 assert not oof.duplicated(['seed','patient_id']).any()
 assert len(oof)==5*s['eligible_patients']
 assert oof.groupby('patient_id').size().eq(5).all()
 assert oof.drop_duplicates('patient_id').event.sum()==s['events']
 for gene,single in s['single_marker_benchmarks'].items():
  frame=pd.read_csv(d/'single_markers'/f'{gene}_oof.tsv',sep='\t')
  cols=['seed','fold','patient_id','time','event']
  pd.testing.assert_frame_equal(oof[cols],frame[cols])
  assert single['measurement_gate_passed_folds']==25
  assert single['panel_minus_single']['valid_bootstrap_replicates']==1000
 metrics=json.loads((d/'metrics.json').read_text())
 assert metrics['bootstrap']['valid_c_index_replicates']==1000
 assert metrics['endpoint']==s['endpoint']
 assert metrics['events']==s['events']
 for k,a in metrics['auc'].items():
  assert len(a['outer_fold_diagnostics'])==25
  if a['status']=='estimable':
   assert all(f['status']=='estimable' for f in a['outer_fold_diagnostics'])
   assert a['valid_bootstrap_replicates']==1000
  else:
   assert a['value'] is None and a['ci95'] is None
 verification['checks'][name]={'eligible_patients':s['eligible_patients'],'events':s['events'],'random_panels':1000,'oof_rows':len(oof),'same_splits_for_all_single_markers':True,'bootstrap_replicates':1000}
old=json.loads((root/'work/primary_archive/results.json').read_text())
for k in ['eligible_patients','dfi_events','c_index','c_index_ci95','percentile_vs_random','random_panels_completed','random_panel_mean_c_index','random_panel_one_sided_empirical_p']:
 assert r['primary_cohort'][k]==old[k],k
verification['checks']['primary_metrics_exactly_preserved']=True
assert r['secondary_cohort']['auc_3yr']['status']=='estimable'
assert r['secondary_cohort']['auc_5yr']['status']=='not estimable'
for f in ['fig1_km','fig2_roc','fig3_forest','fig4_null','fig5_calib','fig6_single']:
 for ext in ['png','tex']: assert (root/'figures'/f'{f}.{ext}').stat().st_size>0
verification['checks']['six_requested_figures_png_and_tex']=True
# All panels use identical prespecified gene draws across the three cohorts.
defs=[json.loads((root/'cohorts'/name/'random_panel_definitions.json').read_text()) for name in cohorts]
assert defs[0]==defs[1]==defs[2]
verification['checks']['identical_random_gene_draws_across_cohorts']=True
out.mkdir(parents=True,exist_ok=True)
for f in ['analysis.py','analysis_figures.py','survival_metrics.py','fast_cox.py','requirements.txt','results.json','audit.log','preamble.tex','analysis_progress.json']:
 shutil.copy2(root/f,out/f)
for d in ['cohorts','figures']:shutil.copytree(root/d,out/d,dirs_exist_ok=True)
shutil.copy2(root/'work/extended_run.log',out/'computation_audit.log')
shutil.copy2(root/'work/extended_validation_metrics.json',out/'independent_numerical_validation.json')
shutil.copy2(root/'work/extended_figure_validation.json',out/'figure_validation.json')
qa=json.loads((out/'independent_numerical_validation.json').read_text())
qa['final_benchmark_regeneration']={'complete':True,'method':'CoxPHFitter(penalizer=0,l1_ratio=0) without L1 coefficient truncation; all three cohorts regenerated after full null runs.'}
(out/'independent_numerical_validation.json').write_text(json.dumps(qa,indent=2)+'\n')
(out/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
lines=['TCGA-COAD: EXTENDED MICROPEPTIDE-SOURCE RNA ANALYSIS','',
'Primary endpoint: DFI in known stage II/III. Secondary endpoint: OS in known stages I-IV.',
'All-stage DFI is reported separately to isolate the effect of changing the stage filter.',
'OS is all-cause survival, not recurrence. These are source-RNA measurements, not peptide abundance.','',
'RESULTS (1,000 random panels and 1,000 patient-cluster bootstrap replicates per cohort)']
for name,s in cohorts.items():
 lines += [f"{name}: N={s['eligible_patients']}, events={s['events']}, C={s['c_index']:.6f}, 95% CI={s['c_index_ci95']}, percentile={s['percentile_vs_random']:.2f}, empirical p={s['random_panel_one_sided_empirical_p']:.6f}."]
 for key in ['auc_3yr','auc_5yr']:
  a=s[key];lines += [f"  {key}: {a['status']}; estimate={a['value']}; 95% CI={a['ci95']}; events={a['events_by_horizon']}; beyond={a['observed_beyond_horizon']}. {a['reason']}"]
 lines += ['  Final refit retains: '+', '.join(x['marker'] for x in s['retained_transcripts'])+'.']
lines += ['',
'INTERPRETATION',
'The four-source-RNA panel does not reach C>=0.65 in any cohort. LINC00675/TMEM238L alone scores about 0.700 in primary DFI; ELFN1-AS1 alone scores about 0.588 in OS. Paired differences and confidence intervals are in single_marker_details. These post hoc comparisons are exploratory, conditional on fitted models, and not multiplicity-adjusted. Selecting the best marker from these results requires independent validation.',
'Final-model retention is not the same as retention in every outer fold. Fold-specific counts are reported.',
'The stage expansion adds 44 stage I DFI patients and only three events. No stage IV patient has usable DFI in this cohort. Unknown/discrepant stage values (11 of 456 matched COAD records) are excluded without imputation.',
'OS has 93 deaths but short follow-up (reverse-KM median about 27 months). Five-year AUC fails the unchanged support rule in seed 71, fold 3 because only four held-out controls remain beyond five years. This is an analysis support criterion, not a claim that every possible five-year AUC estimator is mathematically undefined. No thresholds or seeds were changed to force an estimate.','',
'PIPELINE',
'Xena input is log2(count+1), reversed with expm1(x*ln2). Fractional replicate-averaged counts are retained. Full-library CPM uses all 60,660 rows. Ensembl versions are removed while preserving distinct PAR_Y loci. RBRP/LINC00266-1 remains excluded due to unresolved stable annotation.',
'Primary tumor specimens only, one lexicographically selected specimen per 12-character patient barcode. CDR type COAD. Missing event/time and nonpositive endpoint times are removed independently for each cohort.',
'5 outer x 3 inner stratified folds, seeds 11,23,37,53,71; full 20-combination elastic-net grid. CPM>=1 in >=20% of training tumors, imputation, constant-feature removal and scaling are fitted only on each training split. No batch correction.',
'Single-marker benchmarks use unpenalized Cox with no coefficient truncation, identical outer splits and training-only preprocessing. There are no inner hyperparameters for these models.',
'Panel L1 coefficients with absolute standardized log-HR below 1e-4 are numerically zeroed, with baseline hazards recomputed. Exact Efron acceleration and KKT zero-fit skips preserve the lifelines objective. Native lifelines checks are provided in independent_numerical_validation.json.',
'Harrell C compares risks only within each outer fold, aggregates comparable-pair counts within seed, then averages seeds. Bootstrap clusters by patient across repeats and does not refit models. Paired panel-minus-single intervals use shared resamples.',
'IPCW uses outer-training censoring estimates. Every outer fold must have >=3 cases, >=5 controls, >=10 training observations beyond the horizon and G(t)>=0.05. Horizons are 1095.75 and 1826.25 days. Failed horizons have null values/CIs and explicit reasons.',
'Random panels are identical annotation-universe four-gene draws across cohorts, excluding the target genes. No whole-cohort expression prefilter is used. Comparators receive the same nested CV and training-only gate. These are not expression-matched null panels. Failed inner candidates are invalidated rather than silently counted; no random panel is omitted.',
'The completed original primary run is reused only after exact checks of model AST, coefficient rule, acceleration module, numerical versions, input files, CPM/log matrices, outcomes, and splits. New endpoint/cohort models are refitted. See audit.log and provenance fields.','',
'FIGURES',
'fig1_km: primary DFI and secondary OS, two panels; median split of repeat-averaged training-calibrated held-out risk percentiles.',
'fig2_roc: OS cumulative/dynamic ROC; 5-year curve explicitly unavailable under the support rule.',
'fig3_forest, fig4_null, fig5_calib: retained primary figures.',
'fig6_single: primary DFI and secondary OS single-marker C-indices, bootstrap intervals, and panel reference lines.',
'figures/secondary_os/: additional OS forest, null, calibration and single-cohort KM/ROC.',
'Forest Wald intervals ignore selection and are exploratory. KM and calibration are descriptive. Include preamble.tex in the document preamble and use \\input{figures/fig1_km.tex} in the body. PNGs were inspected; no LaTeX engine is installed, so compilation was not tested.','',
'RERUN',
'Tested with Python 3.12. Keep analysis.py, survival_metrics.py, analysis_figures.py and fast_cox.py together. Put the two original input files in data/, install requirements.txt, and run:',
'  python analysis.py --jobs 8',
'Defaults run all three cohorts, 1000 random panels and 1000 bootstrap replicates. Prediction checkpoints are under work/extended_cache/. Identical data/model/settings permit resuming. The bundle omits large input and cache arrays. Fresh runs without the original primary archive/cache refit the primary cohort too.','',
'SOURCES',
'https://gdc.cancer.gov/about-data/publications/PanCan-Clinical-2018',
'https://gdc.xenahubs.net/download/TCGA-COAD.star_counts.tsv.json',
'https://scikit-survival.readthedocs.io/en/stable/api/generated/sksurv.metrics.cumulative_dynamic_auc.html',
'https://lifelines.readthedocs.io/en/latest/fitters/regression/CoxPHFitter.html']
(out/'ANALYSIS_NOTES.txt').write_text('\n'.join(lines)+'\n')
manifest={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest_sha256.json'}
(out/'manifest_sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
shutil.make_archive(str(root/'outputs/coad_analysis_extended'),'zip',out)
print(json.dumps({'bundle':str(out),'files':len(manifest),'verification':verification},indent=2))
