"""Exact vectorized Efron gradient for small, unweighted lifelines Cox models.

Only the likelihood/gradient/Hessian calculator is accelerated. CoxPHFitter.fit,
lifelines' normalization, optimizer, convergence checks, elastic-net penalty,
baseline hazard, and prediction methods remain unchanged. Intended for the
four-feature, unweighted, unstratified, no-delayed-entry models in this analysis.
Other model specifications automatically use lifelines' native calculator.

This is a deliberately version-pinned optimization of a private API and must be
validated again before changing lifelines from version 0.30.3.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Callable

import lifelines
import numpy as np
from lifelines.fitters.coxph_fitter import SemiParametricPHFitter


_ORIGINAL_CHOOSE = SemiParametricPHFitter._choose_gradient_calculator


def make_efron_calculator(X, T, E) -> Callable:
    """Return exact unweighted Efron (Hessian, gradient, log likelihood).

    There is one precomputed risk-weight row per observed event. If d events
    occur at time t, the k-th row uses I(T>=t) - (k/d)*I(T=t,event), k=0,...,d-1.
    Thus its dot product with exp(X beta) is exactly the Efron denominator.
    """
    x = np.ascontiguousarray(np.asarray(X, dtype=float))
    time = np.asarray(T, dtype=float)
    event = np.asarray(E, dtype=bool)
    event_times, multiplicities = np.unique(time[event], return_counts=True)
    expanded_times = np.repeat(event_times, multiplicities)
    proportions = np.concatenate([np.arange(d, dtype=float) / d for d in multiplicities]) if len(multiplicities) else np.empty(0)
    risk_weights = (time[None, :] >= expanded_times[:, None]).astype(float)
    tied_events = (time[None, :] == expanded_times[:, None]) & event[None, :]
    risk_weights -= proportions[:, None] * tied_events
    event_x_sum = x[event].sum(axis=0)

    def calculate(beta):
        scores = np.exp(x @ beta)
        weighted_risks = risk_weights * scores[None, :]
        denominator = weighted_risks.sum(axis=1)
        normalized_weights = weighted_risks / denominator[:, None]
        mean_x = normalized_weights @ x
        gradient = event_x_sum - mean_x.sum(axis=0)
        hessian = mean_x.T @ mean_x - x.T @ (normalized_weights.sum(axis=0)[:, None] * x)
        log_likelihood = float(event_x_sum @ beta - np.log(denominator).sum())
        return hessian, gradient, log_likelihood

    return calculate


def _choose_fast_gradient(self, T, X, entries):
    native = _ORIGINAL_CHOOSE(self, T, X, entries)
    if entries is not None or self.strata is not None or not 1 <= X.shape[1] <= 4:
        return native
    state = {}

    def calculate(X, T, E, weights, entries, beta):
        key = (id(X), id(T), id(E), id(weights))
        if state.get("key") != key:
            state["key"] = key
            # Weighted fits are intentionally unsupported, including IPCW fits.
            state["calculator"] = (
                make_efron_calculator(X, T, E)
                if entries is None and np.all(np.asarray(weights) == 1)
                else None
            )
        calculator = state["calculator"]
        if calculator is None:
            return native(X, T, E, weights, entries, beta)
        return calculator(beta)

    return calculate


def enable_fast_efron() -> None:
    """Enable in this process only; retain all public lifelines fit behavior."""
    if lifelines.__version__ != "0.30.3":
        raise RuntimeError("Fast Efron calculator is validated only for lifelines==0.30.3")
    SemiParametricPHFitter._choose_gradient_calculator = _choose_fast_gradient


def disable_fast_efron() -> None:
    SemiParametricPHFitter._choose_gradient_calculator = _ORIGINAL_CHOOSE


@contextmanager
def fast_efron():
    """Temporarily enable optimization; use process isolation, not threads."""
    before = SemiParametricPHFitter._choose_gradient_calculator
    enable_fast_efron()
    try:
        yield
    finally:
        SemiParametricPHFitter._choose_gradient_calculator = before
