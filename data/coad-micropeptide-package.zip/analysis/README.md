# Analysis rerun guide

`analysis.py` is the current four-source-RNA TCGA-COAD pipeline. Keep it beside `survival_metrics.py`, `analysis_figures.py`, and `fast_cox.py`. These four current modules match the frozen single-marker-follow-up analysis. Commands below assume the working directory is the extracted archive root, which contains `analysis/` and `manuscript/`.

## Environment

The original Python environment used Python 3.12.14. Create a separate environment and install the pinned analysis dependencies:

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r analysis/requirements-analysis.txt
.venv/bin/python analysis/analysis.py --help
```

`requirements-analysis.txt` contains the 10 core pinned packages from the frozen analysis output. It includes pandas and openpyxl, which the download helper also requires; its HTTP requests use Python's standard-library urllib. `requirements.txt` preserves the exact broader original environment snapshot, also duplicated at the ZIP root. That snapshot contains an unrelated `artifact_tool_v2 @ file:///...` entry pointing to a local host path and is an environment record, not a portable installation target. The original environment inherited installed packages; exact cross-platform reproduction is not guaranteed by a package list. Recorded numerical versions include NumPy 2.3.5, pandas 2.2.3, SciPy 1.18.1, scikit-learn 1.9.1, lifelines 0.30.3, and scikit-survival 0.28.0. The Python and TeX environments themselves are not bundled.

## Required original inputs

The input directory must contain these **exact filenames**:

| File | Source and required format |
|---|---|
| `TCGA-COAD.star_counts.tsv.gz` | [UCSC Xena matrix](https://gdc.xenahubs.net/download/TCGA-COAD.star_counts.tsv.gz), tab-delimited genes × TCGA specimen barcodes, first column gene identifier. The analyzed snapshot contained 60,660 genes and 514 specimen columns. |
| `TCGA-CDR-SupplementalTableS1.xlsx` | [Official GDC download](https://api.gdc.cancer.gov/data/1b5f413e-a8d1-4d10-92eb-7c4ae739ed81), worksheet `TCGA-CDR`. See the [TCGA-CDR publication resource](https://gdc.cancer.gov/about-data/publications/PanCan-Clinical-2018). |

Download separately; these source data are excluded from the archive:

```sh
mkdir -p data
curl --fail --location --retry 3 https://gdc.xenahubs.net/download/TCGA-COAD.star_counts.tsv.gz --output data/TCGA-COAD.star_counts.tsv.gz
curl --fail --location --retry 3 https://gdc.xenahubs.net/download/TCGA-COAD.star_counts.tsv.json --output data/xena_metadata.json
curl --fail --location --retry 3 https://api.gdc.cancer.gov/data/1b5f413e-a8d1-4d10-92eb-7c4ae739ed81 --output data/TCGA-CDR-SupplementalTableS1.xlsx
```

The retrieved [Xena metadata](https://gdc.xenahubs.net/download/TCGA-COAD.star_counts.tsv.json) records version `05-09-2024`, unit `log2(count+1)`, and averaging across portions/aliquots of the same sample before log transformation. The pipeline reverses this transform, preserves fractional averaged counts, and calculates full-library CPM. Do not label this matrix raw counts, FPKM, or TPM.

The original input SHA-256 hashes recorded in `results.json` are:

```text
TCGA-COAD.star_counts.tsv.gz
f434486ee869efae683c77ebb6376bd7a11e63ec50e8a62479f73c398db35d42

TCGA-CDR-SupplementalTableS1.xlsx
ea594c0fbb6731477c7ac511fab449ca9c38b0d42d269591ed9f5c4090e75a5a
```

Verify downloads, for example with `shasum -a 256 data/TCGA-COAD.star_counts.tsv.gz data/TCGA-CDR-SupplementalTableS1.xlsx`. A changed hash means the downloaded bytes differ from the analyzed snapshot; inspect the source/version before claiming an exact replication. The CDR downloader additionally verifies its manifest MD5 (`a4591b2dcee39591f59e5e25a6ce75fa`) and size (2,945,129 bytes).

## Full rerun and preparation-only check

To check parsing, cohort filtering, normalization, and split construction without fitting models:

```sh
.venv/bin/python analysis/analysis.py --data-dir data --output-dir preparation_outputs --work-dir preparation_work --input-scale xena-log2-counts --prepare-only
```

This still reads the full input matrix, allocates transformed expression arrays, and writes cohort/cache files. It does not produce complete model results.

For the reported analysis settings:

```sh
.venv/bin/python analysis/analysis.py --data-dir data --output-dir rerun_outputs --work-dir rerun_work --input-scale xena-log2-counts --n-random 1000 --bootstrap 1000 --jobs 8
```

Reduce `--jobs` if memory or CPU is limited. Five fixed seeds (11, 23, 37, 53, 71), five outer folds, and three inner folds are set in code. `--n-random` and `--bootstrap` can be lowered for a trial, but those outputs do not reproduce the manuscript analysis. Always use a new output directory: the program overwrites its `audit.log`, results, and figures in the requested destination.

The program processes primary stage II/III DFI, secondary known-stage I–IV OS, and expanded known-stage I–IV DFI eligibility. The actual expanded DFI cohort contains stages I–III. Expected snapshot counts are respectively **137/18**, **428/93**, and **181/21** patients/events. The four gene IDs are `ENSG00000153363`, `ENSG00000236081`, `ENSG00000263429`, and `ENSG00000233101`; unresolved LINC00266-1/RBRP is excluded rather than zero-imputed.

Checkpoints under `--work-dir` are reused only when their model/input/dependency fingerprint matches. The optional `--legacy-primary-cache` and `--primary-archive` arguments support verified reuse of the original primary analysis; neither is required for a fresh run. Selected packaged checkpoints do not replace the missing source inputs or guarantee a cache hit after relocation or dependency changes.

The run writes cohort tables, held-out predictions, fold/retention audits, random-panel results, single-marker summaries, the expression-median KM analysis, JSON results, and analysis figures. Independently saved validation reports and manuscript presentation edits are separate artifacts; they are not all regenerated by this command.

## Included GDC downloader: separate utility

Inspect its actual command-line options with:

```sh
.venv/bin/python analysis/download_tcga_coad.py --help
.venv/bin/python analysis/download_tcga_coad.py --outdir gdc_trial --max-patients 2
```

Omit `--max-patients 2` to download the full currently available GDC primary-tumor cohort. `--value-column` accepts `unstranded` (default raw counts), `tpm_unstranded`, `fpkm_unstranded`, or `fpkm_uq_unstranded`. The utility downloads one selected STAR file per patient, the CDR workbook, sample/file manifests, annotations, and a combined `tcga_coad_<value-column>.tsv.gz` matrix. It queries the current GDC release rather than the frozen Xena snapshot.

**Its matrix is not directly accepted by the current analysis:** columns are 12-character patient IDs, whereas `analysis.py` selects primary-tumor **specimen** barcodes matching `TCGA-..-....-01A...`; the expected filename also differs. The GDC file-selection rule selects one file, while Xena averaged sample portions/aliquots. Merely renaming the file or adding `--input-scale raw-counts` does not fix this mismatch. A GDC-based analysis would require an explicit, audited specimen-column conversion from the sample manifest and separate source/cohort validation. FPKM/TPM must not be passed to the pipeline's raw-counts/CPM calculation. No GDC-to-Xena equivalence or GDC-based reproduction of the manuscript is claimed.

## Interpretation of saved results

- The primary **93.4th percentile** and empirical **p=0.066933** apply to the four-gene panel, not to LINC00675 alone.
- Final-refit retention is separate from selection across 25 dependent outer folds.
- Bootstrap intervals condition on fitted models; marker selection and fitting are not repeated inside bootstrap.
- Single-marker selection, expression-median KM, and secondary comparisons are exploratory. Only three-year OS AUC passes the retained all-fold support rules.
- DFI is the CDR disease-free interval, not a relabeled recurrence-free-survival endpoint. No peptide measurements or completed external validation are provided.

See the root `README.md` for manuscript compilation and AI-assistance/author-responsibility disclosure.
