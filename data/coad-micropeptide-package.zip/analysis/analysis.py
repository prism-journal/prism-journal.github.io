#!/usr/bin/env python3
"""Four-source-RNA TCGA-COAD DFI and OS analysis. See --help and audit.log.

Run: work/.venv/bin/python analysis.py
Input Xena STAR data are log2(count+1), not raw counts. Inverse transformation
retains fractional counts because Xena averages replicate aliquots.
"""
import os
for _key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[_key] = '1'
os.environ.setdefault('MPLCONFIGDIR', str(__import__('pathlib').Path('work/mplcache').resolve()))

import argparse
import ast
import hashlib
import importlib.metadata
import json
import logging
import math
import pickle
import re
import sys
import time
import warnings
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from lifelines import CoxPHFitter, KaplanMeierFitter
from lifelines.exceptions import ConvergenceError, ConvergenceWarning
from sklearn.model_selection import StratifiedKFold
from sksurv.metrics import concordance_index_censored
from fast_cox import enable_fast_efron
enable_fast_efron()

PANEL = {
    'ENSG00000153363': 'LINC00467',
    'ENSG00000236081': 'ELFN1-AS1',
    'ENSG00000263429': 'LINC00675 / TMEM238L',
    'ENSG00000233101': 'HOXB-AS3',
}
STAGES = {'Stage II', 'Stage IIA', 'Stage IIB', 'Stage IIC',
          'Stage III', 'Stage IIIA', 'Stage IIIB', 'Stage IIIC'}
SEEDS = [11, 23, 37, 53, 71]
# Deterministic tie-break: stronger penalty, then larger L1 fraction.
GRID = [(p, r) for p in [10., 1., .1, .01, .001] for r in [1., .9, .5, .1]]
HORIZONS = {'36': 365.25 * 3, '60': 365.25 * 5}
RETENTION_THRESHOLD = 1e-4
LOG = logging.getLogger('analysis')


def atomic_json(data, path):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.part')
    temporary.write_text(json.dumps(data, indent=2, allow_nan=False, default=json_default) + '\n')
    temporary.replace(path)


def json_default(value):
    if isinstance(value, np.ndarray): return value.tolist()
    if isinstance(value, np.integer): return int(value)
    if isinstance(value, np.floating): return float(value)
    if isinstance(value, np.bool_): return bool(value)
    if isinstance(value, Path): return str(value)
    raise TypeError(type(value).__name__)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''): digest.update(chunk)
    return digest.hexdigest()


def load_data(expression_path, clinical_path, scale, workdir, endpoint='DFI', stage_group='ii_iii'):
    audit = {}
    if endpoint not in {'DFI', 'OS'} or stage_group not in {'ii_iii', 'all_known'}:
        raise ValueError('Unsupported endpoint or stage group.')
    audit.update(endpoint=endpoint, stage_group=stage_group)
    def count(name, value):
        audit[name] = int(value)
        LOG.info('FILTER %-45s N=%d', name, value)
    LOG.info('Excluded a priori: RBRP-encoding LINC00266-1; no stable resolved Ensembl ID in this annotation. Not imputed as zero.')
    x = pd.read_csv(expression_path, sep='\t', index_col=0)
    count('input_expression_genes', len(x))
    count('input_expression_specimens', x.shape[1])
    if not x.columns.is_unique: raise ValueError('Duplicate column names in expression input.')
    primary = [s for s in x.columns if re.fullmatch(r'TCGA-[A-Z0-9]{2}-[A-Z0-9]{4}-01[A-Z](?:-.*)?', s)]
    count('primary_tumor_specimens', len(primary))
    primary = sorted(primary)
    selected = pd.DataFrame({'specimen_id': primary})
    selected['patient_id'] = selected.specimen_id.str[:12]
    selected['selected'] = ~selected.patient_id.duplicated()
    selected.to_csv(workdir / 'specimen_selection.tsv', sep='\t', index=False)
    chosen = selected.loc[selected.selected]
    count('primary_tumor_unique_patients', len(chosen))
    count('duplicate_primary_specimens_removed', len(primary) - len(chosen))
    x = x.loc[:, chosen.specimen_id]
    x.columns = chosen.patient_id.to_list()
    # Preserve the PAR_Y tag: ENSGxxx.5_PAR_Y and ENSGxxx.5 are distinct loci.
    x.index = x.index.astype(str).str.replace(r'\.\d+(?=_PAR_Y$|$)', '', regex=True)
    if not x.index.is_unique:
        raise ValueError('Ambiguous duplicate gene IDs after version removal; resolve before analysis (do not silently aggregate).')
    c = pd.read_excel(clinical_path, sheet_name='TCGA-CDR', engine='openpyxl')
    count('cdr_all_cancers', len(c))
    c = c.loc[c.type.eq('COAD')].copy()
    count('cdr_coad', len(c))
    if c.bcr_patient_barcode.duplicated().any(): raise ValueError('Duplicate CDR COAD patient IDs.')
    c = c.set_index('bcr_patient_barcode')
    count('expression_patients_without_coad_cdr', len(set(x.columns) - set(c.index)))
    c = c.loc[sorted(set(x.columns) & set(c.index))]
    count('expression_cdr_matched', len(c))
    LOG.info('Stage counts before stage restriction: %s', c.ajcc_pathologic_tumor_stage.value_counts(dropna=False).to_dict())
    if stage_group == 'ii_iii':
        c = c.loc[c.ajcc_pathologic_tumor_stage.isin(STAGES)].copy()
        count('stage_ii_iii', len(c))
    else:
        known = c.ajcc_pathologic_tumor_stage.astype(str).str.fullmatch(r'Stage (?:IV|III|II|I)(?:A|B|C)?')
        count('unknown_or_discrepant_stage_excluded', (~known).sum())
        c = c.loc[known].copy()
        count('stage_i_ii_iii_iv', len(c))
    time_col, label = f'{endpoint}.time', endpoint.lower()
    for col in [endpoint, time_col]: c[col] = pd.to_numeric(c[col], errors='raise')
    count(f'missing_{label}_event', c[endpoint].isna().sum())
    c = c.loc[c[endpoint].notna()]
    count(f'after_nonmissing_{label}', len(c))
    count(f'missing_{label}_time', c[time_col].isna().sum())
    c = c.loc[c[time_col].notna()]
    count(f'after_nonmissing_{label}_time', len(c))
    count(f'nonpositive_{label}_time', c[time_col].le(0).sum())
    c = c.loc[c[time_col].gt(0)]
    if not c[endpoint].isin([0, 1]).all(): raise ValueError(f'{endpoint} must be 0/1.')
    count('eligible_patients', len(c))
    count(f'{label}_events', c[endpoint].sum())
    if min(c[endpoint].value_counts()) < 5: raise ValueError('Insufficient event strata for five outer folds.')
    x = x.loc[:, c.index]
    values = x.to_numpy(dtype=np.float64)
    if np.isinf(values).any() or np.nanmin(values) < 0: raise ValueError('Invalid expression values.')
    audit['input_scale'] = scale
    audit['input_missing_expression_cells'] = int(np.isnan(values).sum())
    if scale == 'xena-log2-counts':
        LOG.info('Reverse Xena log2(count+1) with expm1(x*ln2); do not round averaged replicate counts.')
        values = np.expm1(values * np.log(2))
    elif not np.allclose(values[np.isfinite(values)], np.rint(values[np.isfinite(values)]), atol=1e-6):
        raise ValueError('Raw-count mode supplied fractional/log-transformed values. Use --input-scale xena-log2-counts for this dataset.')
    # Normalization is sample-local and uses ALL measured genes, not the four panel genes.
    # A missing library component makes that sample denominator unknown; never fill it with zero.
    library = values.sum(axis=0)
    if not np.isfinite(library).all() or (library <= 0).any():
        raise ValueError('Missing counts or invalid full-library denominator; cannot validly calculate CPM.')
    cpm = (values / library[None, :] * 1e6).T
    logx = np.log2(cpm + 1)
    c['library_size_recovered_counts'] = library
    c.to_csv(workdir / 'eligible_clinical.tsv', sep='\t', na_rep='NA')
    genes = x.index.to_numpy(dtype=str)
    missing = [g for g in PANEL if g not in set(genes)]
    audit['missing_panel_annotations'] = missing
    if missing: raise ValueError(f'Missing panel annotation: {missing}; not interpreted as zero expression.')
    audit['panel_ids_present'] = list(PANEL)
    LOG.info('All four requested Ensembl IDs found. CPM denominator includes %d genes; PAR_Y identifiers preserved.', len(genes))
    LOG.info('Library sizes recovered from Xena: min=%.0f, median=%.0f, max=%.0f', library.min(), np.median(library), library.max())
    y = pd.DataFrame({'patient_id': c.index, 'time': c[time_col].to_numpy(float), 'event': c[endpoint].to_numpy(bool)})
    np.save(workdir / 'cpm.npy', cpm)
    np.save(workdir / 'logx.npy', logx)
    np.save(workdir / 'genes.npy', genes)
    y.to_csv(workdir / 'outcomes.tsv', sep='\t', index=False)
    return cpm, logx, genes, y, audit


def make_splits(y):
    splits = []
    event = y.event.to_numpy()
    for seed in SEEDS:
        outer = StratifiedKFold(5, shuffle=True, random_state=seed)
        for fold, (train, test) in enumerate(outer.split(np.zeros(len(y)), event)):
            inner = StratifiedKFold(3, shuffle=True, random_state=seed * 100 + fold)
            inners = [(train[a], train[b]) for a, b in inner.split(np.zeros(len(train)), event[train])]
            splits.append({'seed': seed, 'fold': fold, 'train': train, 'test': test, 'inner': inners})
    return splits


def preprocessing(cpm, logx, indices, train, test):
    a = np.asarray(logx[np.ix_(train, indices)], dtype=float)
    b = np.asarray(logx[np.ix_(test, indices)], dtype=float)
    gate = np.mean(cpm[np.ix_(train, indices)] >= 1., axis=0) >= .2
    gate &= np.isfinite(a).any(axis=0)
    positions = np.flatnonzero(gate)
    a, b = a[:, gate], b[:, gate]
    if len(positions) == 0: return a, b, positions, {}
    median = np.nanmedian(a, axis=0)
    a = np.where(np.isfinite(a), a, median)
    b = np.where(np.isfinite(b), b, median)
    mean, sd = a.mean(axis=0), a.std(axis=0)
    varying = sd > 1e-12
    positions = positions[varying]
    state = {'median': median[varying], 'mean': mean[varying], 'sd': sd[varying]}
    return ((a[:, varying] - state['mean']) / state['sd'],
            (b[:, varying] - state['mean']) / state['sd'], positions, state)


def c_summary(event, duration, risk):
    try:
        out = concordance_index_censored(np.asarray(event, bool), duration, risk, tied_tol=1e-8)
        numerator = float(out[1] + .5 * out[3])
        denominator = int(out[1] + out[2] + out[3])
        return numerator, denominator
    except ValueError:
        return 0., 0


def fit_cox(a, y, hyper):
    df = pd.DataFrame(a, columns=[f'x{i}' for i in range(a.shape[1])])
    df['time'] = y.time.to_numpy()
    df['event'] = y.event.to_numpy()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always', ConvergenceWarning)
        model = CoxPHFitter(penalizer=hyper[0], l1_ratio=hyper[1])
        model.fit(df, duration_col='time', event_col='event', show_progress=False)
    if any(issubclass(w.category, ConvergenceWarning) for w in caught):
        raise ConvergenceError('; '.join(str(w.message) for w in caught))
    # lifelines uses a smooth L1 approximation. Numerical near-zero coefficients
    # must not generate artificial rankings for an otherwise empty model.
    model.params_.loc[model.params_.abs() < RETENTION_THRESHOLD] = 0.
    return model


def zero_solution_bound(a, y):
    """KKT score bound for an exactly zero elastic-net Cox optimum.

    lifelines penalizes coefficients on its sample-SD standardized scale, with
    penalty multiplied by n. Efron tied-event likelihood is used here too.
    This training-only bound permits exact zero solutions without redundant fits.
    """
    if a.shape[1] == 0: return 0.
    z = (a - a.mean(axis=0)) / a.std(axis=0, ddof=1)
    duration, event = y.time.to_numpy(), y.event.to_numpy(bool)
    gradient = z[event].sum(axis=0)
    for t in np.unique(duration[event]):
        death = (duration == t) & event
        at_risk = duration >= t
        d = int(death.sum())
        risk_sum, death_sum = z[at_risk].sum(axis=0), z[death].sum(axis=0)
        for k in range(d):
            fraction = k / d
            gradient -= (risk_sum - fraction * death_sum) / (at_risk.sum() - k)
    return float(np.max(np.abs(gradient)) / len(a))


def rebase(model, a, y):
    """Recompute Breslow baseline after the declared numerical-zero rule."""
    if model is None: return
    x = pd.DataFrame(a, columns=model.params_.index)
    ph = pd.DataFrame({'P': model.predict_partial_hazard(x).to_numpy(),
                       'T': y.time.to_numpy(), 'E': y.event.to_numpy(), 'W': 1.})
    fitted = model._model
    fitted.baseline_hazard_ = fitted._compute_baseline_hazards(ph)
    fitted.baseline_cumulative_hazard_ = fitted._compute_baseline_cumulative_hazard(fitted.baseline_hazard_)
    fitted.baseline_survival_ = fitted._compute_baseline_survival()


def predict(model, a):
    if model is None: return np.zeros(len(a))
    return model.predict_log_partial_hazard(pd.DataFrame(a, columns=model.params_.index)).to_numpy()


def tune(cpm, logx, indices, y, inner):
    prepared = []
    for train, valid in inner:
        a, b, pos, state = preprocessing(cpm, logx, indices, train, valid)
        prepared.append((a, b, y.iloc[train], y.iloc[valid], zero_solution_bound(a, y.iloc[train])))
    scores, failures = [], 0
    for hyper in GRID:
        nums, dens, invalid = [], [], False
        for a, b, yt, yv, bound in prepared:
            try:
                exact_zero = bound < hyper[0] * hyper[1] * (1 - 1e-6)
                model = fit_cox(a, yt, hyper) if a.shape[1] and not exact_zero else None
                num, den = c_summary(yv.event, yv.time.to_numpy(), predict(model, b))
                if den == 0: raise ValueError('No comparable validation pairs')
                nums.append(num); dens.append(den)
            except (ConvergenceError, ValueError, np.linalg.LinAlgError, FloatingPointError):
                failures += 1; invalid = True; break
        scores.append(-np.inf if invalid else sum(nums) / sum(dens))
    if not np.isfinite(scores).any(): raise RuntimeError('All hyperparameter candidates failed.')
    best = int(np.argmax(scores))
    return GRID[best], float(scores[best]), failures


def run_panel(indices, cpm, logx, genes, y, splits, detailed=False):
    records, fold_records, sums, gate_counts = [], [], {}, []
    total_failures = 0
    for split in splits:
        train, test = split['train'], split['test']
        hyper, inner_score, failures = tune(cpm, logx, indices, y, split['inner'])
        total_failures += failures
        a, b, pos, state = preprocessing(cpm, logx, indices, train, test)
        gate_counts.append(int(len(pos)))
        model = fit_cox(a, y.iloc[train], hyper) if a.shape[1] else None
        risk = predict(model, b)
        num, den = c_summary(y.iloc[test].event, y.iloc[test].time.to_numpy(), risk)
        aggregate = sums.setdefault(split['seed'], [0., 0])
        aggregate[0] += num; aggregate[1] += den
        if detailed:
            trainrisk = predict(model, a)
            riskpct = ((trainrisk[:, None] < risk).sum(axis=0) + .5 * (trainrisk[:, None] == risk).sum(axis=0)) / len(train)
            if model is None:
                km = KaplanMeierFitter().fit(y.iloc[train].time, y.iloc[train].event)
                surv = np.repeat(km.predict(list(HORIZONS.values())).to_numpy()[:, None], len(test), axis=1)
                coefs = []
            else:
                rebase(model, a, y.iloc[train])
                surv = model.predict_survival_function(pd.DataFrame(b, columns=model.params_.index), times=list(HORIZONS.values())).to_numpy()
                coefs = model.params_.to_numpy().tolist()
            for j, patient in enumerate(test):
                records.append({'seed': split['seed'], 'fold': split['fold'],
                    'patient_id': y.iloc[patient].patient_id, 'time': float(y.iloc[patient].time),
                    'event': bool(y.iloc[patient].event), 'risk': float(risk[j]),
                    'risk_percentile': float(riskpct[j]), 's36': float(surv[0, j]), 's60': float(surv[1, j])})
            fold_records.append({'seed': split['seed'], 'fold': split['fold'], 'n_train': len(train),
                'n_test': len(test), 'train_events': int(y.iloc[train].event.sum()), 'test_events': int(y.iloc[test].event.sum()),
                'penalizer': hyper[0], 'l1_ratio': hyper[1], 'inner_c_index': inner_score,
                'outer_c_index': num / den if den else None,
                'gate_passed': genes[indices[pos]].tolist(),
                'retained': genes[indices[pos]][np.abs(coefs) >= RETENTION_THRESHOLD].tolist(),
                'coefficients': coefs, 'inner_fit_failures': failures})
            LOG.info('Real panel seed=%d fold=%d: C=%.4f, gate=%d, penalizer=%g, L1=%g', split['seed'], split['fold'], num / den, len(pos), *hyper)
    scores = {str(k): v[0] / v[1] for k, v in sums.items()}
    return {'c_index': float(np.mean(list(scores.values()))), 'seed_c_indices': scores,
            'fit_failures': total_failures, 'outer_gate_counts': gate_counts, 'oof': records, 'folds': fold_records}


def null_worker(panel_number, indices, workdir, splits, fingerprint):
    enable_fast_efron()
    path = workdir / 'null_panels' / f'panel_{panel_number:04d}.json'
    if path.exists():
        saved = json.loads(path.read_text())
        if saved['fingerprint'] == fingerprint and saved['gene_indices'] == list(indices): return saved
    cpm = np.load(workdir / 'cpm.npy', mmap_mode='r')
    logx = np.load(workdir / 'logx.npy', mmap_mode='r')
    genes = np.load(workdir / 'genes.npy')
    y = pd.read_csv(workdir / 'outcomes.tsv', sep='\t')
    y['event'] = y.event.astype(bool)
    started = time.perf_counter()
    result = run_panel(np.asarray(indices), cpm, logx, genes, y, splits)
    result.update(panel_number=panel_number, gene_indices=list(indices), genes=genes[indices].tolist(),
                  fingerprint=fingerprint, seconds=time.perf_counter() - started)
    atomic_json(result, path)
    return result


def fit_final(cpm, logx, indices, genes, y):
    allrows = np.arange(len(y))
    inner = list(StratifiedKFold(3, shuffle=True, random_state=SEEDS[0]).split(np.zeros(len(y)), y.event))
    hyper, score, failures = tune(cpm, logx, indices, y, inner)
    a, _, pos, state = preprocessing(cpm, logx, indices, allrows, allrows)
    model = fit_cox(a, y, hyper) if a.shape[1] else None
    rebase(model, a, y)
    rows = []
    if model is not None:
        for j, (name, row) in enumerate(model.summary.iterrows()):
            gene = genes[indices[pos[j]]]
            rows.append({'ensembl': gene, 'marker': PANEL[gene], 'coef': row['coef'],
                         'hr': row['exp(coef)'], 'lower': row['exp(coef) lower 95%'],
                         'upper': row['exp(coef) upper 95%'], 'retained': abs(row['coef']) >= RETENTION_THRESHOLD})
    frame = pd.DataFrame(rows, columns=['ensembl', 'marker', 'coef', 'hr', 'lower', 'upper', 'retained'])
    metadata = {'penalizer': hyper[0], 'l1_ratio': hyper[1], 'inner_c_index': score,
                'gate_passed': genes[indices[pos]].tolist(), 'fit_failures': failures,
                'retention_threshold_abs_log_hr_per_training_sd': RETENTION_THRESHOLD,
                'note': 'Exploratory full-cohort refit. Penalized Wald intervals ignore selection; not validation intervals.'}
    return model, state, frame, metadata


# Endpoint-specific cohorts share the same modeling and validation procedures.
COHORTS = {
    'primary_dfi_stage_ii_iii': ('DFI', 'ii_iii'),
    'secondary_os_all_stages': ('OS', 'all_known'),
    'dfi_all_stages': ('DFI', 'all_known'),
}
MODEL_FUNCTIONS = ['make_splits', 'preprocessing', 'c_summary', 'fit_cox',
                   'zero_solution_bound', 'rebase', 'predict', 'tune', 'run_panel', 'fit_final']


def model_ast(path):
    tree = ast.parse(Path(path).read_text())
    return {node.name: ast.dump(node, include_attributes=False)
            for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in MODEL_FUNCTIONS}


def verify_legacy_primary(args, cache, provenance):
    """Reuse finished primary predictions only after checking model, data and splits.

    The original fingerprint is retained in each imported result. Figures and
    metric labels changed, so file-level hashes alone cannot establish identity.
    """
    old, archive = args.legacy_primary_cache.resolve(), args.primary_archive.resolve()
    if not (old / 'real_panel.json').exists() or not (archive / 'analysis.py').exists():
        return None
    old_prov = json.loads((old / 'provenance.json').read_text())
    for key in ['expression_sha256', 'clinical_sha256', 'input_scale', 'seeds', 'grid']:
        # JSON-normalize tuples in GRID before comparison.
        if json.dumps(old_prov[key], sort_keys=True) != json.dumps(provenance[key], sort_keys=True):
            raise ValueError(f'Legacy primary reuse rejected: {key} differs.')
    if model_ast(archive / 'analysis.py') != model_ast(__file__):
        raise ValueError('Legacy primary reuse rejected: model functions changed.')
    old_tree = ast.parse((archive / 'analysis.py').read_text())
    old_threshold = next(ast.literal_eval(n.value) for n in old_tree.body
                         if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'RETENTION_THRESHOLD' for t in n.targets))
    if old_threshold != RETENTION_THRESHOLD:
        raise ValueError('Legacy primary reuse rejected: retention threshold differs.')
    if old_prov['module_sha256']['fast_cox.py'] != sha256(Path(__file__).with_name('fast_cox.py')):
        raise ValueError('Legacy primary reuse rejected: Cox implementation changed.')
    for name in ['numpy', 'pandas', 'scipy', 'scikit-learn', 'lifelines', 'scikit-survival']:
        if old_prov['package_versions'][name] != provenance['package_versions'][name]:
            raise ValueError(f'Legacy primary reuse rejected: {name} changed.')
    for name in ['cpm.npy', 'logx.npy', 'genes.npy', 'outcomes.tsv', 'cv_splits.json']:
        if sha256(old / name) != sha256(cache / name):
            raise ValueError(f'Legacy primary reuse rejected: {name} differs.')
    legacy_fingerprint = hashlib.sha256(json.dumps(old_prov, sort_keys=True).encode()).hexdigest()
    real = json.loads((old / 'real_panel.json').read_text())
    if real['fingerprint'] != legacy_fingerprint:
        raise ValueError('Legacy primary cache does not match its provenance.')
    LOG.info('PRIMARY REUSE verified: exact model AST, threshold, libraries, inputs, CPM/log matrix, outcomes and CV splits match the completed primary run.')
    return old, legacy_fingerprint


def run_single_marker(index, cpm, logx, y, splits):
    """Unpenalized univariate Cox; same outer folds and training-only gate.

    No inner tuning is needed: this benchmark has no free hyperparameters.
    A training-gate failure produces a constant-risk model for that fold.
    """
    records, folds = [], []
    indices = np.asarray([index])
    for split in splits:
        train, test = split['train'], split['test']
        a, b, pos, state = preprocessing(cpm, logx, indices, train, test)
        model = None
        if len(pos):
            training = pd.DataFrame(a, columns=['x0'])
            training['time'] = y.iloc[train].time.to_numpy()
            training['event'] = y.iloc[train].event.to_numpy()
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter('always', ConvergenceWarning)
                model = CoxPHFitter(penalizer=0., l1_ratio=0.).fit(
                    training, duration_col='time', event_col='event', show_progress=False)
            if any(issubclass(w.category, ConvergenceWarning) for w in caught):
                raise ConvergenceError('; '.join(str(w.message) for w in caught))
            # No L1 approximation is involved: retain the exact unpenalized coefficient.
        risk, trainrisk = predict(model, b), predict(model, a)
        pct = ((trainrisk[:, None] < risk).sum(0) + .5 * (trainrisk[:, None] == risk).sum(0)) / len(train)
        if model is None:
            km = KaplanMeierFitter().fit(y.iloc[train].time, y.iloc[train].event)
            surv = np.repeat(km.predict(list(HORIZONS.values())).to_numpy()[:, None], len(test), axis=1)
        else:
            rebase(model, a, y.iloc[train])
            surv = model.predict_survival_function(pd.DataFrame(b, columns=model.params_.index), times=list(HORIZONS.values())).to_numpy()
        for j, patient in enumerate(test):
            records.append({'seed': split['seed'], 'fold': split['fold'],
                'patient_id': y.iloc[patient].patient_id, 'time': float(y.iloc[patient].time),
                'event': bool(y.iloc[patient].event), 'risk': float(risk[j]),
                'risk_percentile': float(pct[j]), 's36': float(surv[0, j]), 's60': float(surv[1, j])})
        num, den = c_summary(y.iloc[test].event, y.iloc[test].time.to_numpy(), risk)
        folds.append({'seed': split['seed'], 'fold': split['fold'], 'gate_passed': bool(len(pos)),
                      'n_train': len(train), 'train_events': int(y.iloc[train].event.sum()),
                      'n_test': len(test), 'test_events': int(y.iloc[test].event.sum()),
                      'c_index': num / den if den else None, 'comparable_pairs': den,
                      'training_preprocessing': state,
                      'coefficient': float(model.params_.iloc[0]) if model is not None else None})
    return pd.DataFrame(records), folds


def audit_single_marker_splits(y, splits, panel_oof, single_oof):
    """Fail closed on any patient overlap or departure from panel CV partitions."""
    if not y.patient_id.is_unique:
        raise ValueError('Leakage audit: outcomes contain duplicate patients.')
    all_rows = set(range(len(y)))
    test_counts = {seed: np.zeros(len(y), dtype=int) for seed in SEEDS}
    for split in splits:
        train, test = set(map(int, split['train'])), set(map(int, split['test']))
        if train & test or train | test != all_rows:
            raise ValueError('Leakage audit: invalid outer training/test partition.')
        if len(split['inner']) != 3:
            raise ValueError('Leakage audit: expected the panel\'s three inner folds.')
        inner_valid = []
        for inner_train, inner_test in split['inner']:
            a, b = set(map(int, inner_train)), set(map(int, inner_test))
            if a & b or a | b != train or (a | b) & test:
                raise ValueError('Leakage audit: invalid/overlapping inner partition.')
            inner_valid.extend(b)
        if sorted(inner_valid) != sorted(train):
            raise ValueError('Leakage audit: inner validation coverage is not once per outer-training patient.')
        test_counts[split['seed']][split['test']] += 1
        expected_ids = set(y.iloc[split['test']].patient_id)
        actual = single_oof.loc[single_oof.seed.eq(split['seed']) & single_oof.fold.eq(split['fold'])]
        if len(actual) != len(test) or set(actual.patient_id) != expected_ids:
            raise ValueError('Leakage audit: held-out single-marker patients differ from the panel splits.')
    if not all((counts == 1).all() for counts in test_counts.values()):
        raise ValueError('Leakage audit: patients do not occur exactly once per outer repeat.')
    columns = ['seed', 'fold', 'patient_id', 'time', 'event']
    left = panel_oof[columns].sort_values(['seed', 'patient_id']).reset_index(drop=True)
    right = single_oof[columns].sort_values(['seed', 'patient_id']).reset_index(drop=True)
    pd.testing.assert_frame_equal(left, right, check_dtype=False)
    return {'status': 'passed', 'outer_folds_checked': len(splits),
            'inner_partitions_checked': sum(len(s['inner']) for s in splits),
            'same_outer_patients_and_outcomes_as_panel': True, 'patient_overlap': 0,
            'preprocessing_and_fit': 'Measurement gate, imputation, scaling and unpenalized Cox fit use only each outer training partition.',
            'inner_cv': 'Same panel nested partitions verified; fixed unpenalized univariate Cox has no inner hyperparameters to select.',
            'scope': 'Checks within-CV separation. Marker choice following earlier results is post hoc and is not externally validated.'}


def fold_cindex_distribution(fold_metrics):
    values = np.asarray([v['c_index'] for v in fold_metrics if v['c_index'] is not None], float)
    if len(values) == 0:
        raise ValueError('No estimable fold-wise C-indices.')
    return {'n_folds': len(fold_metrics), 'n_estimable': len(values),
            'unweighted_mean': float(values.mean()), 'sample_sd': float(values.std(ddof=1)),
            'minimum': float(values.min()), 'q25': float(np.quantile(values, .25)),
            'median': float(np.median(values)), 'q75': float(np.quantile(values, .75)),
            'maximum': float(values.max()),
            'note': 'Descriptive distribution of dependent outer folds. Overall C instead weights comparable pairs within seed, then averages seeds.'}


def concise_single_bootstrap(single, cohort, endpoint, n_boot):
    interval = single['c_index_ci95']
    return {'cindex': single['c_index'], 'ci_lower': interval[0] if interval else None,
            'ci_upper': interval[1] if interval else None, 'n_boot': int(n_boot),
            'n_boot_valid': single['bootstrap']['valid_c_index_replicates'],
            'cohort': cohort, 'endpoint': endpoint, 'marker': single['marker'],
            'method': single['bootstrap']['method'],
            'limitation': single['bootstrap']['limitation']}


def single_expression_km(cache, cohort_dir):
    """Descriptive median expression split; never used in Cox training/scoring."""
    from lifelines.statistics import logrank_test
    genes = np.load(cache / 'genes.npy')
    gene_index = np.flatnonzero(genes == 'ENSG00000263429')
    if len(gene_index) != 1:
        raise ValueError('LINC00675 annotation must be uniquely available for KM.')
    logx = np.load(cache / 'logx.npy', mmap_mode='r')
    d = pd.read_csv(cache / 'outcomes.tsv', sep='\t')
    d['expression'] = np.asarray(logx[:, gene_index[0]])
    n_missing = int(d.expression.isna().sum())
    d = d.loc[np.isfinite(d.expression)].copy()
    threshold = float(d.expression.median())
    d['expression_group'] = np.where(d.expression.gt(threshold), 'high', 'low')
    if d.expression_group.nunique() != 2:
        raise ValueError('LINC00675 expression median does not separate two groups.')
    low, high = d.loc[d.expression_group.eq('low')], d.loc[d.expression_group.eq('high')]
    test = logrank_test(low.time, high.time, event_observed_A=low.event, event_observed_B=high.event)
    d.to_csv(cohort_dir / 'linc00675_expression_km_groups.tsv', sep='\t', index=False)
    meta = {'endpoint': 'DFI', 'cohort': 'primary_dfi_stage_ii_iii', 'marker': 'LINC00675 / TMEM238L',
            'ensembl': 'ENSG00000263429', 'expression_unit': 'log2(CPM+1)',
            'median_expression': threshold, 'median_cpm': float(np.exp2(threshold) - 1),
            'split_rule': 'Low expression <= cohort median; high expression > median. No outcome-optimized cutpoint.',
            'missing_expression_excluded': n_missing, 'eligible_patients': len(d),
            'groups': {'low': {'n': len(low), 'events': int(low.event.sum())},
                       'high': {'n': len(high), 'events': int(high.event.sum())}},
            'logrank_p': float(test.p_value), 'logrank_chi2': float(test.test_statistic),
            'method': 'Unweighted two-group log-rank test using all available right-censored DFI follow-up.',
            'interpretation': 'Post hoc descriptive association, unadjusted for marker selection/multiple comparisons; distinct from held-out Cox performance. Expression median is used only for this figure.',
            'reference': 'https://lifelines.readthedocs.io/en/latest/lifelines.statistics.html#lifelines.statistics.logrank_test'}
    LOG.info('LINC00675 expression KM: median log2(CPM+1)=%.6f; low N=%d events=%d; high N=%d events=%d; logrank p=%.8g',
             threshold, len(low), low.event.sum(), len(high), high.event.sum(), test.p_value)
    atomic_json(meta, cohort_dir / 'linc00675_expression_km.json')
    return d, meta


def run_cohort(name, endpoint, stage_group, args, outdir, workroot, base_provenance):
    from survival_metrics import evaluate_oof, paired_c_index_differences
    cohort_dir, cache = outdir / 'cohorts' / name, workroot / name
    cohort_dir.mkdir(parents=True, exist_ok=True)
    (cache / 'null_panels').mkdir(parents=True, exist_ok=True)
    LOG.info('BEGIN COHORT %s; endpoint=%s; stages=%s', name, endpoint, stage_group)
    cpm, logx, genes, y, audit = load_data(
        args.data_dir / 'TCGA-COAD.star_counts.tsv.gz',
        args.data_dir / 'TCGA-CDR-SupplementalTableS1.xlsx', args.input_scale, cache,
        endpoint=endpoint, stage_group=stage_group)
    splits = make_splits(y)
    atomic_json(splits, cache / 'cv_splits.json')
    atomic_json({'patient_order': y.patient_id.tolist(), 'splits': splits}, cohort_dir / 'cv_splits.json')
    atomic_json(audit, cohort_dir / 'filtering_audit.json')
    clinical_export = pd.read_csv(cache / 'eligible_clinical.tsv', sep='\t')
    clinical_export[['bcr_patient_barcode', 'ajcc_pathologic_tumor_stage', endpoint,
                     f'{endpoint}.time', 'library_size_recovered_counts']].to_csv(
        cohort_dir / 'eligible_patients.tsv', sep='\t', index=False)
    for split in splits:
        LOG.info('FOLD %s seed=%d fold=%d trainN=%d trainEvents=%d testN=%d testEvents=%d', name,
                 split['seed'], split['fold'], len(split['train']), y.iloc[split['train']].event.sum(),
                 len(split['test']), y.iloc[split['test']].event.sum())
    provenance = dict(base_provenance, cohort=name, endpoint=endpoint, stage_group=stage_group)
    # Prediction caches depend on model semantics and input contents, not figure styling.
    prediction_spec = {k: provenance[k] for k in ['expression_sha256', 'clinical_sha256', 'input_scale', 'seeds', 'grid', 'package_versions', 'cohort', 'endpoint', 'stage_group']}
    prediction_spec.update(model_ast=model_ast(__file__), fast_cox_sha256=sha256(Path(__file__).with_name('fast_cox.py')),
        retention_threshold=RETENTION_THRESHOLD,
        data_sha256={p: sha256(cache / p) for p in ['cpm.npy', 'logx.npy', 'genes.npy', 'outcomes.tsv', 'cv_splits.json']})
    fingerprint = hashlib.sha256(json.dumps(prediction_spec, sort_keys=True).encode()).hexdigest()
    provenance['prediction_fingerprint'] = fingerprint
    atomic_json(provenance, cache / 'provenance.json')
    atomic_json(prediction_spec, cache / 'prediction_specification.json')
    if args.prepare_only:
        return None
    legacy = verify_legacy_primary(args, cache, base_provenance) if name == 'primary_dfi_stage_ii_iii' else None
    indices = np.asarray([np.flatnonzero(genes == gene)[0] for gene in PANEL])
    real_cache = cache / 'real_panel.json'
    real = json.loads(real_cache.read_text()) if real_cache.exists() else {}
    if real.get('fingerprint') == fingerprint:
        LOG.info('Reusing fingerprint-verified panel predictions: %s', name)
    elif legacy:
        real = json.loads((legacy[0] / 'real_panel.json').read_text())
        real['legacy_fingerprint'] = real['fingerprint']
        real['fingerprint'] = fingerprint
        atomic_json(real, real_cache)
    else:
        real = run_panel(indices, cpm, logx, genes, y, splits, detailed=True)
        real['fingerprint'] = fingerprint
        atomic_json(real, real_cache)
    oof = pd.DataFrame(real['oof'])
    oof.to_csv(cohort_dir / 'oof_predictions.tsv', sep='\t', index=False)
    atomic_json(real['folds'], cohort_dir / 'outer_fold_audit.json')
    fold_training = {(s['seed'], s['fold']): y.iloc[s['train']][['time', 'event']] for s in splits}
    metrics, plotting = evaluate_oof(oof, fold_training, n_bootstrap=args.bootstrap, seed=20261013, horizons=HORIZONS, endpoint=endpoint)
    if not np.isclose(metrics['c_index'], real['c_index'], atol=1e-12):
        raise ValueError('C-index aggregation mismatch.')
    atomic_json(metrics, cohort_dir / 'metrics.json')
    LOG.info('PANEL %s C=%.6f CI=%s; AUC36=%s AUC60=%s', name, metrics['c_index'], metrics['c_index_ci95'], metrics['auc']['36']['status'], metrics['auc']['60']['status'])
    single_results, single_oofs = {}, {}
    single_dir = cohort_dir / 'single_markers'
    single_dir.mkdir(exist_ok=True)
    for gene, index in zip(PANEL, indices):
        single, folds = run_single_marker(index, cpm, logx, y, splits)
        leakage_audit = audit_single_marker_splits(y, splits, oof, single)
        sm, _ = evaluate_oof(single, fold_training, n_bootstrap=args.bootstrap, seed=20261013, horizons=HORIZONS, endpoint=endpoint)
        single.to_csv(single_dir / f'{gene}_oof.tsv', sep='\t', index=False)
        atomic_json(folds, single_dir / f'{gene}_folds.json')
        single_results[gene] = {'marker': PANEL[gene], 'c_index': sm['c_index'], 'c_index_ci95': sm['c_index_ci95'],
            'c_index_by_seed': sm['c_index_by_seed'], 'measurement_gate_passed_folds': sum(f['gate_passed'] for f in folds),
            'total_outer_folds': len(folds), 'bootstrap': sm['bootstrap'],
            'foldwise_c_indices': sm['c_index_outer_folds'],
            'foldwise_c_index_distribution': fold_cindex_distribution(sm['c_index_outer_folds']),
            'leakage_audit': leakage_audit,
            'method': 'Unpenalized univariate Cox; same outer CV splits and training-only preprocessing; no hyperparameter tuning.'}
        single_oofs[gene] = single
        LOG.info('SINGLE %s %s C=%.6f CI=%s', name, PANEL[gene], sm['c_index'], sm['c_index_ci95'])
        LOG.info('SINGLE LEAKAGE %s %s: passed 25 outer/75 inner partition checks; training-only preprocessing and fit. Fold C range %.4f-%.4f.',
                 name, PANEL[gene], single_results[gene]['foldwise_c_index_distribution']['minimum'],
                 single_results[gene]['foldwise_c_index_distribution']['maximum'])
    pd.DataFrame([dict(ensembl=gene, marker=PANEL[gene], **fold)
        for gene, single in single_results.items() for fold in single['foldwise_c_indices']]).to_csv(
            cohort_dir / 'single_marker_fold_cindices.tsv', sep='\t', index=False)
    paired = paired_c_index_differences(oof, single_oofs, n_bootstrap=args.bootstrap, seed=20261013, endpoint=endpoint)
    for gene in single_results:
        single_results[gene]['panel_minus_single'] = paired['comparisons'][gene]
    atomic_json(single_results, cohort_dir / 'single_marker_benchmarks.json')
    universe = np.flatnonzero(~np.isin(genes, list(PANEL)))
    rng, random_panels, seen = np.random.default_rng(20261013), [], set()
    while len(random_panels) < args.n_random:
        draw = tuple(sorted(map(int, rng.choice(universe, 4, replace=False))))
        if draw not in seen:
            seen.add(draw); random_panels.append(list(draw))
    atomic_json({'seed': 20261013, 'universe_size': len(universe), 'panels': [genes[p].tolist() for p in random_panels]}, cohort_dir / 'random_panel_definitions.json')
    if legacy:
        imported = 0
        for number, panel in enumerate(random_panels):
            path = legacy[0] / 'null_panels' / f'panel_{number:04d}.json'
            if not path.exists(): continue
            saved = json.loads(path.read_text())
            if saved['fingerprint'] != legacy[1] or saved['gene_indices'] != panel:
                raise ValueError(f'Legacy random panel {number} fails provenance/draw identity check.')
            saved['legacy_fingerprint'] = saved['fingerprint']
            saved['fingerprint'] = fingerprint
            atomic_json(saved, cache / 'null_panels' / path.name)
            imported += 1
        provenance['legacy_primary_reuse'] = {'random_panels_imported': imported, 'legacy_fingerprint': legacy[1],
            'verification': 'Exact model AST, coefficient threshold, Cox module, numerical package versions, input files, normalized expression, outcomes and CV splits matched.'}
        LOG.info('Imported %d verified completed primary random panels.', imported)
    LOG.info('NULL %s: %d random four-gene panels; same nested CV; %d workers.', name, args.n_random, args.jobs)
    stream = Parallel(n_jobs=args.jobs, return_as='generator_unordered', pre_dispatch=args.jobs)(
        delayed(null_worker)(i, panel, cache, splits, fingerprint) for i, panel in enumerate(random_panels))
    nulls = []
    for result in stream:
        nulls.append(result)
        LOG.info('NULL %s completed %d/%d: panel=%d C=%.4f seconds=%.1f failures=%d', name, len(nulls), args.n_random,
                 result['panel_number'], result['c_index'], result['seconds'], result['fit_failures'])
        atomic_json({'status': 'running', 'cohort': name, 'completed_random_panels': len(nulls), 'requested_random_panels': args.n_random,
            'real_panel_c_index': real['c_index'], 'updated_utc': datetime.now(timezone.utc).isoformat()}, outdir / 'analysis_progress.json')
    nulls.sort(key=lambda v: v['panel_number'])
    null_scores = np.array([v['c_index'] for v in nulls])
    pd.DataFrame([{'panel_number': v['panel_number'], 'genes': ';'.join(v['genes']), 'c_index': v['c_index'],
        'fit_failures': v['fit_failures']} for v in nulls]).to_csv(cohort_dir / 'random_panel_scores.tsv', sep='\t', index=False)
    atomic_json({'policy': 'One failed inner fit invalidates that entire hyperparameter candidate; remaining grid candidates are evaluated. No panel omitted.',
        'real_panel_failed_inner_candidates': real['fit_failures'],
        'random_panels_with_failed_inner_candidates': [
            {'panel_number': v['panel_number'], 'genes': v['genes'], 'failed_inner_candidates': v['fit_failures']}
            for v in nulls if v['fit_failures']]}, cohort_dir / 'candidate_fit_failures.json')
    model, state, forest, final_meta = fit_final(cpm, logx, indices, genes, y)
    forest.to_csv(cohort_dir / 'final_model_coefficients.tsv', sep='\t', index=False)
    with (cohort_dir / 'final_model.pkl').open('wb') as handle:
        pickle.dump({'model': model, 'preprocessing': state, 'metadata': final_meta}, handle)
    outer_retention = {gene: sum(gene in f['retained'] for f in real['folds']) for gene in PANEL}
    eligible_clinical = pd.read_csv(cache / 'eligible_clinical.tsv', sep='\t')
    stage_groups = eligible_clinical.groupby('ajcc_pathologic_tumor_stage')
    summary = {'endpoint': endpoint, 'stage_group': 'II/III' if stage_group == 'ii_iii' else 'I/II/III/IV (known stage)',
        'eligible_stage_counts': stage_groups.size().to_dict(),
        'events_by_stage': stage_groups[endpoint].sum().astype(int).to_dict(),
        'eligible_patients': len(y), 'events': int(y.event.sum()), f'{endpoint.lower()}_events': int(y.event.sum()),
        'ensembl_ids_used': list(PANEL), 'retained_transcripts': forest.loc[forest.retained, ['ensembl', 'marker']].to_dict('records'),
        'outer_fold_retention_counts': outer_retention, 'outer_folds': len(splits),
        'c_index': real['c_index'], 'c_index_ci95': metrics['c_index_ci95'], 'c_index_by_seed': metrics['c_index_by_seed'],
        'median_followup_days': metrics['median_followup_days'], 'median_followup_months': metrics['median_followup_months'],
        'auc_3yr': {k: v for k, v in metrics['auc']['36'].items() if k != 'outer_fold_diagnostics'},
        'auc_5yr': {k: v for k, v in metrics['auc']['60'].items() if k != 'outer_fold_diagnostics'},
        'percentile_vs_random': float(100 * ((null_scores < real['c_index'] - 1e-12).sum() + .5 * np.isclose(null_scores, real['c_index'], atol=1e-12, rtol=0).sum()) / len(null_scores)),
        'random_panels_completed': len(nulls), 'random_panel_mean_c_index': float(null_scores.mean()),
        'random_panel_median_c_index': float(np.median(null_scores)),
        'random_panel_one_sided_empirical_p': float((1 + (null_scores >= real['c_index']).sum()) / (1 + len(null_scores))),
        'fit_failures': {'real_inner_candidates': real['fit_failures'], 'random_inner_candidates': sum(v['fit_failures'] for v in nulls),
                         'random_panels_with_failed_candidates': sum(v['fit_failures'] > 0 for v in nulls)},
        'final_model': final_meta, 'filtering_audit': audit, 'provenance': provenance,
        'single_marker_benchmarks': single_results, 'metrics_path': f'cohorts/{name}/metrics.json'}
    bootstrap_key, target_gene = ('linc00675_single_bootstrap', 'ENSG00000263429') if endpoint == 'DFI' else ('elfn1as1_single_bootstrap', 'ENSG00000236081')
    summary[bootstrap_key] = concise_single_bootstrap(single_results[target_gene], name, endpoint, args.bootstrap)
    atomic_json(summary, cohort_dir / 'results.json')
    LOG.info('COMPLETE COHORT %s: C=%.6f; percentile=%.3f; empirical p=%.6f', name, real['c_index'], summary['percentile_vs_random'], summary['random_panel_one_sided_empirical_p'])
    return summary, plotting, forest, null_scores


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir', type=Path, default=Path('data'))
    parser.add_argument('--output-dir', type=Path, default=Path('.'))
    parser.add_argument('--work-dir', type=Path, default=Path('work/extended_cache'))
    parser.add_argument('--legacy-primary-cache', type=Path, default=Path('work/analysis_cache'))
    parser.add_argument('--primary-archive', type=Path, default=Path('work/primary_archive'))
    parser.add_argument('--input-scale', choices=['xena-log2-counts', 'raw-counts'], default='xena-log2-counts')
    parser.add_argument('--n-random', type=int, default=1000)
    parser.add_argument('--bootstrap', type=int, default=1000)
    parser.add_argument('--jobs', type=int, default=8)
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    if min(args.n_random, args.bootstrap, args.jobs) < 1: parser.error('Counts and jobs must be positive.')
    outdir, workroot = args.output_dir.resolve(), args.work_dir.resolve()
    outdir.mkdir(parents=True, exist_ok=True); workroot.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s',
        handlers=[logging.FileHandler(outdir / 'audit.log', mode='w'), logging.StreamHandler(sys.stdout)])
    started = datetime.now(timezone.utc).isoformat()
    LOG.info('DFI stage II/III remains primary; OS known stages I-IV is secondary; DFI known stages I-IV is a stage sensitivity analysis.')
    LOG.info('DFI is disease-free interval; OS is overall survival. Neither is relabeled RFS. Unknown/discrepant stages excluded without imputation.')
    LOG.info('Five fixed seeds %s; 5 outer x 3 inner CV. Training-only gate/imputation/scaling; no batch correction. Full-library CPM is sample-local.', SEEDS)
    LOG.info('Xena inverse transform preserves fractional averaged counts. Numerical L1 zero rule abs(coef)<%g; exact Efron acceleration/KKT bound.', RETENTION_THRESHOLD)
    LOG.info('AUC support unchanged: every outer fold needs >=3 cases, >=5 controls, >=10 training beyond horizon, G(t)>=0.05. No threshold adjustment to force an estimate.')
    provenance = {'expression_sha256': sha256(args.data_dir / 'TCGA-COAD.star_counts.tsv.gz'),
        'clinical_sha256': sha256(args.data_dir / 'TCGA-CDR-SupplementalTableS1.xlsx'),
        'analysis_sha256': sha256(__file__), 'seeds': SEEDS, 'grid': GRID,
        'module_sha256': {name: sha256(Path(__file__).with_name(name)) for name in ['survival_metrics.py', 'analysis_figures.py', 'fast_cox.py']},
        'input_scale': args.input_scale, 'n_random': args.n_random, 'bootstrap': args.bootstrap,
        'xena_metadata_url': 'https://gdc.xenahubs.net/download/TCGA-COAD.star_counts.tsv.json',
        'xena_metadata_verified_unit': 'log2(count+1)',
        'package_versions': {p: importlib.metadata.version(p) for p in ['numpy','pandas','scipy','scikit-learn','lifelines','scikit-survival','matplotlib','matplot2tikz']}}
    completed = {name: run_cohort(name, *spec, args, outdir, workroot, provenance) for name, spec in COHORTS.items()}
    if args.prepare_only: return
    primary = completed['primary_dfi_stage_ii_iii']
    secondary = completed['secondary_os_all_stages']
    singles = {name: value[0]['single_marker_benchmarks'] for name, value in completed.items()}
    from analysis_figures import export_figures, export_extended_figures, export_single_marker_km
    figure_meta = export_figures(outdir / 'figures', primary[1], primary[2].loc[primary[2].retained], primary[3], primary[0]['c_index'], preamble_path=outdir / 'preamble.tex')
    figure_meta.update(export_extended_figures(outdir / 'figures', primary[1], secondary[1], singles,
        primary[0]['c_index'], secondary[0]['c_index'], preamble_path=outdir / 'preamble.tex'))
    # Also provide endpoint-specific secondary forest/null/calibration figures.
    secondary_figures = export_figures(outdir / 'figures' / 'secondary_os', secondary[1], secondary[2].loc[secondary[2].retained], secondary[3], secondary[0]['c_index'], preamble_path=outdir / 'preamble.tex')
    km_patients, km_details = single_expression_km(workroot / 'primary_dfi_stage_ii_iii', outdir / 'cohorts' / 'primary_dfi_stage_ii_iii')
    figure_meta['single_marker_km'] = export_single_marker_km(outdir / 'figures', km_patients,
        marker='LINC00675 / TMEM238L', endpoint='DFI', cohort_label='stages II-III',
        logrank_p=km_details['logrank_p'], expression_threshold=km_details['median_expression'],
        preamble_path=outdir / 'preamble.tex')
    results = {'status': 'complete', 'started_utc': started, 'completed_utc': datetime.now(timezone.utc).isoformat(),
        'ensembl_ids_used': list(PANEL), 'markers': PANEL,
        'excluded_marker': {'LINC00266-1 / RBRP': 'No stable Ensembl ID resolved; excluded, not zero-imputed.'},
        'primary_cohort': primary[0], 'secondary_cohort': secondary[0],
        'stage_sensitivity_dfi_all_stages': completed['dfi_all_stages'][0],
        'single_marker_benchmarks': {name: {PANEL[gene]: value['c_index'] for gene, value in records.items()} for name, records in singles.items()},
        'single_marker_details': singles,
        'linc00675_single_bootstrap': primary[0]['linc00675_single_bootstrap'],
        'linc00675_single_bootstrap_all_stages': completed['dfi_all_stages'][0]['linc00675_single_bootstrap'],
        'elfn1as1_single_bootstrap': secondary[0]['elfn1as1_single_bootstrap'],
        'logrank_p_linc00675': km_details['logrank_p'],
        'linc00675_km_details': km_details,
        'single_marker_foldwise_cindex': {
            name: {'ensembl': gene, 'marker': PANEL[gene], 'endpoint': value[0]['endpoint'],
                   'folds': singles[name][gene]['foldwise_c_indices'],
                   'distribution': singles[name][gene]['foldwise_c_index_distribution'],
                   'c_index_by_seed': singles[name][gene]['c_index_by_seed'],
                   'leakage_audit': singles[name][gene]['leakage_audit']}
            for name, value in completed.items()
            for gene in [('ENSG00000236081' if name == 'secondary_os_all_stages' else 'ENSG00000263429')]},
        'auc_results': {name: {'endpoint': value[0]['endpoint'], '36_months': value[0]['auc_3yr'], '60_months': value[0]['auc_5yr']} for name, value in completed.items()},
        'validation': {'outer_folds': 5, 'inner_folds': 3, 'seeds': SEEDS, 'bootstrap_replicates': args.bootstrap,
            'c_index_method': 'Comparable pairs within each outer fold; counts combined within seed; mean across five seeds.',
            'ci_method': 'Patient-cluster percentile bootstrap conditional on fitted out-of-fold models; no nested CV refits inside bootstrap.',
            'single_marker_method': 'Unpenalized univariate Cox, same outer splits and training-only preprocessing; no inner hyperparameters.',
            'stage_policy': 'Include known AJCC stages I-IV and substages; exclude unknown/discrepant stage values.',
            'auc_support': 'All 25 outer folds: >=3 test cases, >=5 test controls, >=10 training observations beyond horizon, censoring G(t)>=0.05.',
            'random_panels': 'Same 1000 (or --n-random) annotation-universe four-gene draws across cohorts; targets excluded; same nested CV and measurement gate.'},
        'figures': figure_meta, 'secondary_figures': secondary_figures,
        'limitations': ['Internal validation only; no independent cohort.',
            'Secondary analyses were added after examining primary results and are exploratory.',
            'OS includes death from any cause and is not a recurrence endpoint; stage IV OS is not an adjuvant recurrence cohort.',
            'Only 18 primary DFI events and 21 all-stage DFI events; stage relaxation does not resolve sparse recurrence outcomes.',
            'Micropeptide-source bulk RNA is a proxy; no peptide abundance is measured.',
            'Uniform random panels are not expression-matched; the baseline is empirical, not fixed at 0.50.',
            'Final refit retention can differ from fold-specific retention; single-marker comparisons are paired, exploratory and not multiplicity-adjusted.',
            'Penalized forest Wald intervals ignore selection; KM and calibration figures are descriptive.',
            'LINC00675 expression-median KM/log-rank is post hoc and unadjusted; its full-cohort median never enters CV preprocessing, model fitting or C-index scoring.',
            'Single-marker models use the panel\'s outer training/test partitions; the fixed unpenalized model has no hyperparameters requiring inner CV selection.',
            'Bootstrap intervals condition on fitted models and censoring distributions; they omit model-selection uncertainty.']}
    atomic_json(results, outdir / 'results.json')
    atomic_json({'status': 'complete', 'cohorts': {name: {'random_panels_completed': value[0]['random_panels_completed'], 'c_index': value[0]['c_index']} for name, value in completed.items()},
        'updated_utc': datetime.now(timezone.utc).isoformat()}, outdir / 'analysis_progress.json')
    LOG.info('COMPLETE: all three cohorts, single-marker comparisons and figures saved to %s', outdir)


if __name__ == '__main__':
    main()
