#!/usr/bin/env python3
"""Download one primary-tumor STAR-Counts file per TCGA-COAD patient and TCGA-CDR.

Python >=3.9; install dependencies: python -m pip install pandas openpyxl
Run: python download_tcga_coad.py --outdir ./data
Small trial: python download_tcga_coad.py --outdir ./data_trial --max-patients 2
FPKM matrix: add --value-column fpkm_unstranded (same raw STAR files).

The default matrix contains unstranded raw counts, genes x patients. Raw STAR
files also retain TPM/FPKM. No gene-biotype filtering or normalization is applied.
Selection: sort by sample barcode, aliquot barcode(s), then file UUID and keep
the first file per patient. This is reproducible, not a quality ranking.
The official CDR workbook is retained; DFI and DFI.time (days) are not imputed.

Sources:
https://docs.gdc.cancer.gov/API/Users_Guide/Search_and_Retrieval/
https://docs.gdc.cancer.gov/Data/Bioinformatics_Pipelines/Expression_mRNA_Pipeline/
https://gdc.cancer.gov/about-data/publications/PanCan-Clinical-2018
"""

import argparse
import hashlib
import json
import logging
import re
import sys
import time
from datetime import datetime, timezone
from http.client import HTTPException
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import pandas as pd


API = "https://api.gdc.cancer.gov"
CDR_ID = "1b5f413e-a8d1-4d10-92eb-7c4ae739ed81"
CDR_NAME = "TCGA-CDR-SupplementalTableS1.xlsx"
# Verified from the official publication manifest; these identify the 2018 CDR.
CDR_MD5 = "a4591b2dcee39591f59e5e25a6ce75fa"
CDR_SIZE = 2945129
CDR_MANIFEST = (
    "https://gdc.cancer.gov/system/files/public/file/"
    "PanCan-Clinical_Open_GDC-Manifest_1.txt"
)
FILTERS = {
    "op": "and",
    "content": [
        {"op": "in", "content": {"field": field, "value": [value]}}
        for field, value in [
            ("cases.project.project_id", "TCGA-COAD"),
            ("data_category", "Transcriptome Profiling"),
            ("data_type", "Gene Expression Quantification"),
            ("experimental_strategy", "RNA-Seq"),
            ("analysis.workflow_type", "STAR - Counts"),
            ("cases.samples.sample_type", "Primary Tumor"),
            ("access", "open"),
        ]
    ],
}
FIELDS = ",".join([
    "file_id", "file_name", "file_size", "md5sum", "analysis.workflow_type",
    "cases.case_id", "cases.submitter_id", "cases.samples.sample_id",
    "cases.samples.submitter_id", "cases.samples.sample_type",
    "cases.samples.portions.analytes.aliquots.submitter_id",
])
VALUE_COLUMNS = ("unstranded", "tpm_unstranded", "fpkm_unstranded", "fpkm_uq_unstranded")
LOG = logging.getLogger("tcga_coad")


def request(url):
    return Request(url, headers={"User-Agent": "TCGA-COAD-CDR-downloader/1.0"})


def retryable(error):
    return not isinstance(error, HTTPError) or error.code in (408, 429, 500, 502, 503, 504)


def get_json(url, params=None):
    if params:
        url += "?" + urlencode(params)
    for attempt in range(4):
        try:
            with urlopen(request(url), timeout=90) as response:
                return json.load(response)
        except (URLError, TimeoutError, HTTPException) as error:
            if attempt == 3 or not retryable(error):
                raise
            LOG.warning("API request failed; retrying: %s", error)
            time.sleep(2 ** (attempt + 1))


def write_json(value, path):
    temporary = path.with_name(path.name + ".part")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def write_tsv(frame, path, index=False):
    temporary = path.with_name(path.name + ".part")
    frame.to_csv(temporary, sep="\t", index=index, na_rep="NA",
                 compression="gzip" if path.suffix == ".gz" else None)
    temporary.replace(path)


def query_files():
    """Paginate instead of relying on the API's small default page size."""
    hits = []
    total = None
    while total is None or len(hits) < total:
        result = get_json(f"{API}/files", {
            "filters": json.dumps(FILTERS), "fields": FIELDS, "format": "JSON",
            "size": 500, "from": len(hits), "sort": "file_id:asc",
        })
        if result.get("warnings"):
            raise ValueError(f"GDC query warning; check API schema: {result['warnings']}")
        page = result["data"]["hits"]
        total = result["data"]["pagination"]["total"]
        if not page:
            if len(hits) != total:
                raise ValueError("GDC returned an incomplete page of metadata.")
            break
        hits.extend(page)
    if not hits:
        raise ValueError("No open TCGA-COAD primary-tumor STAR-Counts files found.")
    if len(hits) != total or len({h["file_id"] for h in hits}) != total:
        raise ValueError("GDC metadata changed during pagination; rerun the query.")
    return hits


def select_patients(hits):
    """Validate file-linked biospecimens before deduplication; never use outcomes."""
    rows = []
    for hit in hits:
        cases = hit.get("cases", [])
        if len(cases) != 1 or len(cases[0].get("samples", [])) != 1:
            raise ValueError(f"Ambiguous file-to-sample mapping: {hit['file_id']}")
        case, sample = cases[0], cases[0]["samples"][0]
        patient = case["submitter_id"]
        barcode = sample["submitter_id"]
        if (sample.get("sample_type") != "Primary Tumor"
                or not re.fullmatch(r"TCGA-[A-Z0-9]{2}-[A-Z0-9]{4}-01[A-Z]", barcode)
                or barcode[:12] != patient):
            raise ValueError(f"Non-primary or mismatched biospecimen: {barcode}")
        aliquots = sorted({
            aliquot["submitter_id"]
            for portion in sample.get("portions", [])
            for analyte in portion.get("analytes", [])
            for aliquot in analyte.get("aliquots", [])
        })
        if any(not a.startswith(barcode + "-") for a in aliquots):
            raise ValueError(f"Aliquot does not belong to sample {barcode}")
        filename = hit["file_name"]
        if Path(filename).name != filename:
            raise ValueError(f"Unsafe filename in API response: {filename!r}")
        rows.append({
            "patient_id": patient, "sample_id": barcode,
            "sample_uuid": sample["sample_id"], "case_uuid": case["case_id"],
            "sample_type": sample["sample_type"], "aliquot_ids": ";".join(aliquots),
            "file_id": hit["file_id"], "file_name": filename,
            "md5sum": hit["md5sum"], "file_size": int(hit["file_size"]),
            "workflow": hit["analysis"]["workflow_type"],
        })
    candidates = pd.DataFrame(rows).sort_values(
        ["patient_id", "sample_id", "aliquot_ids", "file_id"], kind="stable"
    ).reset_index(drop=True)
    candidates["selected_per_patient"] = ~candidates["patient_id"].duplicated()
    selected = candidates.loc[candidates["selected_per_patient"]].copy()
    return candidates, selected.reset_index(drop=True)


def md5_file(path):
    digest = hashlib.md5()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def download(file_id, path, expected_md5, expected_size):
    """Stream to a temporary file; reuse only complete checksum-verified downloads."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if (path.exists() and path.stat().st_size == expected_size
            and md5_file(path) == expected_md5):
        return
    temporary = path.with_name(path.name + ".part")
    for attempt in range(4):
        try:
            digest = hashlib.md5()
            with urlopen(request(f"{API}/data/{file_id}"), timeout=90) as response:
                with temporary.open("wb") as handle:
                    for chunk in iter(lambda: response.read(1024 * 1024), b""):
                        handle.write(chunk)
                        digest.update(chunk)
            if temporary.stat().st_size != expected_size or digest.hexdigest() != expected_md5:
                raise ValueError(f"Size/checksum mismatch for {path.name}")
            temporary.replace(path)
            return
        except (URLError, TimeoutError, ConnectionError, HTTPException, ValueError) as error:
            temporary.unlink(missing_ok=True)
            if attempt == 3 or not retryable(error):
                raise
            LOG.warning("Download failed; retrying %s: %s", path.name, error)
            time.sleep(2 ** (attempt + 1))


def clinical_tables(workbook, patient_ids):
    cdr = pd.read_excel(workbook, sheet_name="TCGA-CDR", engine="openpyxl")
    required = {"bcr_patient_barcode", "type", "DFI", "DFI.time"}
    if not required.issubset(cdr.columns):
        raise ValueError(f"CDR columns missing: {sorted(required - set(cdr.columns))}")
    coad = cdr.loc[cdr["type"].eq("COAD")].copy()
    if coad.empty or coad["bcr_patient_barcode"].isna().any():
        raise ValueError("CDR contains no COAD records or has missing patient IDs.")
    if coad["bcr_patient_barcode"].duplicated().any():
        raise ValueError("CDR contains duplicate COAD patient IDs.")
    for column in ("DFI", "DFI.time"):
        coad[column] = pd.to_numeric(coad[column], errors="raise")
    if not coad["DFI"].dropna().isin([0, 1]).all():
        raise ValueError("Unexpected DFI event encoding; expected 0, 1, or missing.")
    matched = pd.DataFrame({"patient_id": list(patient_ids)}).merge(
        coad, how="left", left_on="patient_id", right_on="bcr_patient_barcode",
        validate="one_to_one", sort=False, indicator=True,
    )
    matched["has_cdr_record"] = matched.pop("_merge").eq("both")
    # Convenience flag only: this is not a complete survival-analysis eligibility rule.
    matched["dfi_fields_complete"] = (
        matched["DFI"].isin([0, 1]) & matched["DFI.time"].notna()
    )
    return coad, matched


def expression_matrix(selected, outdir, value_column):
    series = []
    annotations = None
    for row in selected.itertuples(index=False):
        table = pd.read_csv(outdir / row.relative_path, sep="\t", comment="#")
        required = {"gene_id", "gene_name", "gene_type", value_column}
        if not required.issubset(table.columns):
            raise ValueError(f"Unexpected STAR columns in {row.file_name}")
        # Remove STAR summary rows (N_unmapped, etc.); retain all gene biotypes.
        table = table.loc[~table["gene_id"].str.startswith("N_")].set_index("gene_id")
        if table.empty or not table.index.is_unique:
            raise ValueError(f"Empty/duplicate gene IDs in {row.file_name}")
        current = table[["gene_name", "gene_type"]]
        if annotations is None:
            annotations = current.copy()
        elif not current.equals(annotations):
            raise ValueError("Gene IDs/order/annotations differ between STAR files.")
        values = pd.to_numeric(table[value_column], errors="raise")
        if values.isna().any() or (values < 0).any():
            raise ValueError(f"Missing/negative expression in {row.file_name}")
        series.append(values.rename(row.patient_id))
    matrix = pd.concat(series, axis=1)
    write_tsv(annotations, outdir / "gene_annotations.tsv", index=True)
    write_tsv(matrix, outdir / f"tcga_coad_{value_column}.tsv.gz", index=True)
    return matrix.shape


def positive_int(value):
    number = int(value)
    if number < 1:
        raise argparse.ArgumentTypeError("Must be a positive integer")
    return number


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--outdir", type=Path, default=Path("data"), help="Default: ./data relative to the working directory")
    parser.add_argument("--max-patients", type=positive_int, help="Download only the first N sorted patients for a small trial")
    parser.add_argument("--value-column", choices=VALUE_COLUMNS, default="unstranded", help="Column for the combined matrix; raw files retain every metric")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
    outdir = args.outdir.resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    # A successful run writes this last. Remove a stale success marker before rerunning.
    (outdir / "download_summary.json").unlink(missing_ok=True)
    started = datetime.now(timezone.utc).isoformat()
    status = get_json(f"{API}/status")
    hits = query_files()
    write_json({"retrieved_utc": started, "gdc_status": status,
                "filters": FILTERS, "fields": FIELDS, "files": hits}, outdir / "gdc_metadata.json")
    candidates, selected = select_patients(hits)
    full_patient_count = len(selected)
    if args.max_patients:
        selected = selected.head(args.max_patients).copy()
    candidates["included_in_run"] = candidates["file_id"].isin(selected["file_id"])
    selected["relative_path"] = [
        (Path("expression_raw") / row.file_id / row.file_name).as_posix()
        for row in selected.itertuples(index=False)
    ]
    write_tsv(candidates, outdir / "candidate_files.tsv")
    write_tsv(selected, outdir / "sample_manifest.tsv")
    LOG.info("Found %s files, %s unique patients; downloading %s patients.", len(hits), full_patient_count, len(selected))

    download(CDR_ID, outdir / CDR_NAME, CDR_MD5, CDR_SIZE)
    coad, matched = clinical_tables(outdir / CDR_NAME, selected["patient_id"])
    write_tsv(coad, outdir / "tcga_coad_cdr.tsv")
    write_tsv(matched, outdir / "tcga_coad_clinical_matched.tsv")
    for index, row in enumerate(selected.itertuples(index=False), 1):
        LOG.info("[%s/%s] %s (%s)", index, len(selected), row.patient_id, row.sample_id)
        download(row.file_id, outdir / row.relative_path, row.md5sum, row.file_size)
    genes, patients = expression_matrix(selected, outdir, args.value_column)
    summary = {
        "started_utc": started, "completed_utc": datetime.now(timezone.utc).isoformat(),
        "gdc_status": status, "project": "TCGA-COAD", "workflow": "STAR - Counts",
        "matching_files": len(hits), "unique_primary_tumor_patients": full_patient_count,
        "downloaded_patients": patients, "genes": genes, "value_column": args.value_column,
        "trial_max_patients": args.max_patients,
        "selection_rule": "First by sample barcode, aliquot barcodes, then file UUID per patient",
        "matched_cdr_patients": int(matched["has_cdr_record"].sum()),
        "patients_with_complete_dfi_fields": int(matched["dfi_fields_complete"].sum()),
        "cdr_url": f"{API}/data/{CDR_ID}", "cdr_md5": CDR_MD5,
        "cdr_manifest_url": CDR_MANIFEST,
    }
    write_json(summary, outdir / "download_summary.json")
    LOG.info("Saved %s genes x %s patients to %s", genes, patients, outdir)
    LOG.info("CDR matches: %s; complete DFI fields: %s (missing outcomes retained).",
             summary["matched_cdr_patients"], summary["patients_with_complete_dfi_fields"])


if __name__ == "__main__":
    try:
        main()
    except (URLError, TimeoutError, OSError, HTTPException, ValueError, KeyError) as error:
        LOG.error("Download incomplete: %s", error)
        sys.exit(1)
