"""Publication-oriented plots for internally validated TCGA-COAD DFI/OS models.

The calling analysis supplies all predictions and metric estimates.  This module
does not refit a prediction model or silently replace unavailable estimates.
Exports use the maintained ``matplot2tikz`` package directly:
https://github.com/ErwindeGelder/matplot2tikz
"""

from __future__ import annotations

from pathlib import Path
import re
import textwrap
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplot2tikz
import numpy as np
import pandas as pd
from lifelines import KaplanMeierFitter


BLUE = "#2463a6"
ORANGE = "#cf6938"
GREY = "#697581"
DAYS_PER_MONTH = 365.25 / 12.0


def _axes(title: str, xlabel: str, ylabel: str):
    fig, ax = plt.subplots(figsize=(7.2, 5.5))
    ax.set(title=title, xlabel=xlabel, ylabel=ylabel)
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color="#e8e8e8", linewidth=0.6)
    ax.set_axisbelow(True)
    return fig, ax


def _note(ax, text: str) -> None:
    ax.text(
        0.0,
        -0.21,
        text,
        ha="left",
        va="top",
        transform=ax.transAxes,
        fontsize=8,
        color=GREY,
        clip_on=False,
    )


def _save(fig, directory: Path, stem: str, *, axis_width="12cm", axis_height="8cm",
          groupstyle=None, save_png=True) -> dict[str, str]:
    fig.tight_layout()
    png = directory / f"{stem}.png"
    tex = directory / f"{stem}.tex"
    if save_png:
        fig.savefig(png, dpi=180, bbox_inches="tight", facecolor="white")
    # matplot2tikz leaves prose verbatim. Escape ordinary text only after the
    # PNG has been saved; raw '%' would otherwise comment out the TeX line.
    # Explicit TeX line breaks also preserve the two-line explanatory notes.
    for artist in fig.findobj(matplotlib.text.Text):
        content = artist.get_text()
        if "$" not in content:
            content = re.sub(r"(?<!\\)([%&#_])", r"\\\1", content)
            content = content.replace("\n", r"\\")
            artist.set_text(content)
    # Data remain embedded in .tex, so the file can be moved without sidecars.
    matplot2tikz.save(
        tex,
        figure=fig,
        encoding="utf-8",
        axis_width=axis_width,
        axis_height=axis_height,
        externalize_tables=False,
        strict=True,
        extra_axis_parameters=["clip=false"],
        extra_tikzpicture_parameters=["every node/.append style={align=left}"],
        extra_groupstyle_parameters=groupstyle or [],
        float_format=".8g",
    )
    plt.close(fig)
    return {"png": str(png), "tex": str(tex)} if save_png else {"tex": str(tex)}


def _plot_km(directory: Path, patients: pd.DataFrame, *, endpoint="DFI") -> dict[str, Any]:
    needed = ["time", "event", "risk_percentile"]
    d = patients.dropna(subset=needed).copy()
    fig, ax = _axes(
        f"{endpoint} by internally validated risk group",
        "OS time (months)" if endpoint == "OS" else "Time from DFI origin (months)",
        "Overall survival probability" if endpoint == "OS" else "Probability of remaining DFI event-free",
    )
    threshold = float(d["risk_percentile"].median()) if len(d) else np.nan
    high = d["risk_percentile"].gt(threshold)
    group_info = {}
    if d.empty or high.nunique() < 2:
        ax.text(0.5, 0.5, "Risk groups not separable", transform=ax.transAxes,
                ha="center", va="center")
        status = "not_estimable"
    else:
        status = "ok"
        for flag, label, color in [(False, "Low risk", BLUE), (True, "High risk", ORANGE)]:
            group = d.loc[high.eq(flag)]
            event_word = "deaths" if endpoint == "OS" else "events"
            label_text = f"{label} (n={len(group)}, {event_word}={int(group['event'].sum())})"
            km = KaplanMeierFitter(alpha=0.05)
            km.fit(group["time"].to_numpy() / DAYS_PER_MONTH,
                   event_observed=group["event"].astype(bool).to_numpy())
            sf = km.survival_function_.iloc[:, 0]
            ci = km.confidence_interval_survival_function_
            ax.step(sf.index, sf.to_numpy(), where="post", label=label_text,
                    color=color, linewidth=1.8)
            ax.fill_between(ci.index, ci.iloc[:, 0], ci.iloc[:, 1], step="post",
                            color=color, alpha=0.12, linewidth=0)
            # Mark actual censoring times rather than arbitrary regular ticks.
            censored = km.event_table.loc[km.event_table["censored"].gt(0)].index
            if len(censored):
                ax.plot(censored, km.predict(censored), "+", color=color,
                        markersize=4, markeredgewidth=0.6)
            group_info[label] = {"n": len(group), "events": int(group["event"].sum())}
        ax.legend(loc="lower left", frameon=False, fontsize=9)
    ax.set_ylim(0, 1.02)
    ax.set_xlim(left=0)
    _note(ax, "Repeated out-of-fold predictions; median split is descriptive.\n"
              "Shading: pointwise KM 95% CI; + marks censoring. No external validation.")
    return {**_save(fig, directory, "fig1_km"), "status": status,
            "median_risk_percentile": threshold, "groups": group_info}


def _plot_roc(directory: Path, roc: dict, *, endpoint="DFI", cohort_label=None) -> dict[str, Any]:
    title = f"Cumulative/dynamic {endpoint} ROC"
    if cohort_label:
        title += f" ({cohort_label})"
    fig, ax = _axes(title, "False-positive rate", "True-positive rate")
    ax.plot([0, 1], [0, 1], linestyle="--", color=GREY, linewidth=0.9, label="Chance")
    unsupported = []
    for horizon, color in [("36", BLUE), ("60", ORANGE)]:
        curve = roc.get(horizon, roc.get(int(horizon), {}))
        fpr = np.asarray(curve.get("fpr", []), dtype=float)
        tpr = np.asarray(curve.get("tpr", []), dtype=float)
        auc = curve.get("auc")
        if (len(fpr) and len(fpr) == len(tpr) and auc is not None
                and np.isfinite(float(auc)) and np.isfinite(fpr).all() and np.isfinite(tpr).all()):
            ax.plot(fpr, tpr, color=color, linewidth=1.8,
                    label=f"{horizon} months (AUC={float(auc):.3f})")
        else:
            unsupported.append(f"{horizon} months: not estimable")
    ax.set(xlim=(0, 1), ylim=(0, 1.02))
    ax.legend(loc="lower right", frameon=False)
    if unsupported:
        ax.text(0.04, 0.95, "\n".join(unsupported), transform=ax.transAxes,
                va="top", fontsize=9, color=GREY)
    _note(ax, "IPCW estimated from outer training folds; ROC summarizes held-out folds.\n"
              "Repeated nested cross-validation is internal validation.")
    return {**_save(fig, directory, "fig2_roc"), "unsupported": unsupported}


def _plot_forest(directory: Path, forest: pd.DataFrame, *, endpoint="DFI") -> dict[str, Any]:
    title = "Exploratory OS final-model coefficients" if endpoint == "OS" else "Exploratory final-model coefficients"
    xlabel = "OS hazard ratio per training SD" if endpoint == "OS" else "Hazard ratio per training SD"
    fig, ax = _axes(title, xlabel, "")
    ax.axvline(1.0, color=GREY, linestyle="--", linewidth=0.9)
    if forest.empty:
        ax.text(0.5, 0.5, "No transcript retained", transform=ax.transAxes,
                ha="center", va="center")
        ax.set(xlim=(0.5, 2), yticks=[])
    else:
        d = forest.copy().reset_index(drop=True)
        valid = np.isfinite(d[["hr", "lower", "upper"]]).all(axis=1)
        valid &= d[["hr", "lower", "upper"]].gt(0).all(axis=1)
        d = d.loc[valid].reset_index(drop=True)
        y = np.arange(len(d))
        labels = d["marker"].astype(str).tolist()
        for i, row in d.iterrows():
            ax.plot([row["lower"], row["upper"]], [i, i], color=BLUE, linewidth=1.5)
            ax.plot([row["hr"]], [i], "s", color=BLUE, markersize=6)
            ax.plot([row["lower"], row["lower"]], [i-0.07, i+0.07], color=BLUE)
            ax.plot([row["upper"], row["upper"]], [i-0.07, i+0.07], color=BLUE)
        ax.set_yticks(y, labels=labels)
        ax.set_ylim(-0.7, max(len(d)-0.3, 0.7))
        ax.invert_yaxis()
        ax.set_xscale("log")
        if d.empty:
            ax.text(0.5, 0.5, "Finite coefficient intervals unavailable",
                    transform=ax.transAxes, ha="center")
    _note(ax, "Full eligible-cohort refit after tuning; elastic-net estimates are shrunken.\n"
              "Wald intervals are descriptive and do not account for model selection.")
    return _save(fig, directory, "fig3_forest")


def _plot_null(directory: Path, null_cindices, real_cindex: float, *, endpoint="DFI") -> dict[str, Any]:
    values = np.asarray(null_cindices, dtype=float)
    values = values[np.isfinite(values)]
    title = "Random four-gene panel comparison (OS)" if endpoint == "OS" else "Random four-gene panel comparison"
    xlabel = "Held-out Harrell C-index (OS)" if endpoint == "OS" else "Held-out Harrell C-index"
    fig, ax = _axes(title, xlabel, "Number of random panels")
    if len(values):
        ax.hist(values, bins=min(35, max(5, int(np.sqrt(len(values))))),
                color=BLUE, alpha=0.78, edgecolor="white", linewidth=0.5,
                label=f"Random panels (n={len(values)})")
    if real_cindex is not None and np.isfinite(real_cindex):
        ax.axvline(real_cindex, color=ORANGE, linewidth=2.2,
                   label=f"Micropeptide-source panel ({real_cindex:.3f})")
    ax.axvline(0.5, color=GREY, linewidth=1, linestyle="--", label="Chance (0.50)")
    ax.legend(loc="upper right", frameon=True, framealpha=0.95,
              facecolor="white", edgecolor="none", fontsize=9)
    _note(ax, "Same nested cross-validation and fold-specific preprocessing for all panels.\n"
              "Random panels are an empirical comparator, not assumed to score 0.50.")
    return {**_save(fig, directory, "fig4_null"), "finite_random_panels": len(values)}


def _plot_calibration(directory: Path, calibration: dict, *, endpoint="DFI") -> dict[str, Any]:
    if endpoint == "OS":
        fig, ax = _axes("Descriptive calibration of all-cause death risk",
                       "Mean held-out predicted probability of death", "KM-estimated probability of death")
    else:
        fig, ax = _axes("Descriptive calibration of DFI event risk",
                       "Mean held-out predicted DFI event probability", "KM-estimated DFI event probability")
    ax.plot([0, 1], [0, 1], linestyle="--", color=GREY, linewidth=0.9,
            label="Ideal calibration")
    unsupported = []
    for horizon, color in [("36", BLUE), ("60", ORANGE)]:
        data = calibration.get(horizon, calibration.get(int(horizon), {}))
        points = data.get("points", [])
        valid = [p for p in points if all(p.get(k) is not None and np.isfinite(p[k])
                                        for k in ["predicted", "observed", "lower", "upper"])]
        if not valid:
            unsupported.append(f"{horizon} months: not estimable")
            continue
        valid.sort(key=lambda p: p["predicted"])
        pred = np.array([p["predicted"] for p in valid])
        obs = np.array([p["observed"] for p in valid])
        low = np.array([p["lower"] for p in valid])
        high = np.array([p["upper"] for p in valid])
        ax.plot(pred, obs, "o-", color=color, linewidth=1.5,
                markersize=5, label=f"{horizon} months")
        # Draw intervals as ordinary line artists for reliable PGFPlots export.
        for p, o, lo, hi in zip(pred, obs, low, high):
            ax.plot([p, p], [lo, hi], color=color, linewidth=1)
            ax.plot([p-0.006, p+0.006], [lo, lo], color=color, linewidth=1)
            ax.plot([p-0.006, p+0.006], [hi, hi], color=color, linewidth=1)
    if unsupported:
        ax.text(0.04, 0.96, "\n".join(unsupported), transform=ax.transAxes,
                va="top", fontsize=9, color=GREY)
    ax.set(xlim=(0, 1), ylim=(0, 1.02))
    ax.legend(loc="lower right", frameon=False, fontsize=9)
    _note(ax, "Patient-level predictions averaged across held-out repeats; descriptive risk bins.\n"
              "Bars: pointwise KM 95% CI. Unsupported bins are omitted.")
    return {**_save(fig, directory, "fig5_calib"), "unsupported": unsupported}


def write_preamble(path: str | Path) -> str:
    """Write packages needed by the generated PGFPlots figures."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        "% Include this file in the LaTeX document preamble.\n"
        "% Include figures in the body with \\input{figures/fig1_km.tex}.\n"
        "\\usepackage[T1]{fontenc}\n"
        "\\usepackage[utf8]{inputenc}\n"
        "\\usepackage{amsmath}\n"
        "\\usepackage{xcolor}\n"
        "\\usepackage{tikz}\n"
        "\\usepackage{pgfplots}\n"
        "\\usepgfplotslibrary{groupplots,dateplot,fillbetween}\n"
        "\\usetikzlibrary{patterns,shapes.arrows,plotmarks}\n"
        "\\pgfplotsset{compat=1.18}\n"
        "\\DeclareUnicodeCharacter{2212}{\\ensuremath{-}}\n",
        encoding="utf-8",
    )
    return str(path)


def export_figures(
    figures_dir: str | Path,
    plotting_data: dict[str, Any],
    forest_df: pd.DataFrame,
    null_cindices,
    real_cindex: float,
    preamble_path: str | Path | None = None,
) -> dict[str, Any]:
    """Save the five requested PNG/TikZ figures and their PGFPlots preamble.

    ``plotting_data`` is the second result of ``evaluate_oof`` and contains
    ``patients``, ``roc``, and ``calibration``.  Patients have columns ``time``
    (days for the specified endpoint), ``event``, ``risk_percentile``, ``s36``
    and ``s60``. ``plotting_data['endpoint']`` selects DFI (default) or OS labels.
    The source of
    those predictions must be outer test folds. ``forest_df`` contains columns
    ``marker``, ``ensembl``, ``coef``, ``hr``, ``lower``, ``upper`` for retained
    coefficients in the standardized full-cohort refit.
    """
    directory = Path(figures_dir)
    directory.mkdir(parents=True, exist_ok=True)
    endpoint = plotting_data.get("endpoint", "DFI")
    if endpoint not in {"DFI", "OS"}:
        raise ValueError(f"Unsupported endpoint {endpoint!r}; expected DFI or OS")
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 10,
        "axes.titlesize": 12, "axes.labelsize": 10,
        "legend.fontsize": 9, "axes.unicode_minus": False,
    })
    paths = {
        "km": _plot_km(directory, plotting_data["patients"], endpoint=endpoint),
        "roc": _plot_roc(directory, plotting_data.get("roc", {}), endpoint=endpoint),
        "forest": _plot_forest(directory, forest_df, endpoint=endpoint),
        "null": _plot_null(directory, null_cindices, real_cindex, endpoint=endpoint),
        "calibration": _plot_calibration(directory, plotting_data.get("calibration", {}), endpoint=endpoint),
    }
    for metadata in paths.values():
        metadata["endpoint"] = endpoint
    preamble = Path(preamble_path) if preamble_path is not None else directory.parent / "preamble.tex"
    paths["preamble"] = write_preamble(preamble)
    return paths


def _draw_endpoint_km(ax, patients: pd.DataFrame, *, endpoint: str, title: str) -> dict[str, Any]:
    """Draw one prespecified cohort using its held-out risk-percentile median."""
    d = patients.dropna(subset=["time", "event", "risk_percentile"]).copy()
    threshold = float(d.risk_percentile.median()) if len(d) else None
    high = d.risk_percentile.gt(threshold) if threshold is not None else pd.Series(False, index=d.index)
    groups = {}
    status = "ok"
    if d.empty or high.nunique() < 2:
        status = "not estimable"
        ax.text(0.5, 0.5, "Risk groups not separable", transform=ax.transAxes,
                ha="center", va="center")
    else:
        for flag, label, color in [(False, "Low risk", BLUE), (True, "High risk", ORANGE)]:
            group = d.loc[high.eq(flag)]
            events = int(group.event.sum())
            outcome_word = "deaths" if endpoint == "OS" else "DFI events"
            km = KaplanMeierFitter(alpha=0.05).fit(
                group.time.to_numpy(float) / DAYS_PER_MONTH,
                event_observed=group.event.to_numpy(bool),
            )
            sf = km.survival_function_.iloc[:, 0]
            ci = km.confidence_interval_survival_function_
            ax.step(sf.index, sf.to_numpy(), where="post", color=color, linewidth=1.7,
                    label=f"{label} (n={len(group)}, {outcome_word}={events})")
            ax.fill_between(ci.index, ci.iloc[:, 0], ci.iloc[:, 1], step="post",
                            color=color, alpha=0.12, linewidth=0)
            censored = km.event_table.loc[km.event_table.censored.gt(0)].index
            if len(censored):
                ax.plot(censored, km.predict(censored), "+", color=color,
                        markersize=3.5, markeredgewidth=0.6)
            groups[label] = {"n": len(group), "events": events}
        ax.legend(loc="lower left", frameon=False, fontsize=8)
    ax.set(title=title, xlabel=f"{endpoint} time (months)",
           ylabel="Overall survival probability" if endpoint == "OS" else "DFI event-free probability",
           ylim=(0, 1.02))
    ax.set_xlim(left=0)
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color="#e8e8e8", linewidth=0.6)
    ax.set_axisbelow(True)
    _note(ax, "Held-out risk percentiles averaged across repeats; descriptive median split.\n"
              "Pointwise KM 95% CI; + indicates censoring. Internal validation.")
    return {"endpoint": endpoint, "status": status, "n": len(d),
            "median_risk_percentile": threshold, "groups": groups}


def _plot_km_comparison(directory: Path, primary: dict, secondary: dict) -> dict[str, Any]:
    fig, axes = plt.subplots(1, 2, figsize=(12.8, 5.4))
    dfi = _draw_endpoint_km(axes[0], primary["patients"], endpoint="DFI",
                           title="A. Primary DFI: stage II-III")
    os = _draw_endpoint_km(axes[1], secondary["patients"], endpoint="OS",
                          title="B. Secondary OS: all stages")
    paths = _save(fig, directory, "fig1_km", axis_width="7.4cm", axis_height="7.2cm",
                  groupstyle=["horizontal sep=1.8cm"])
    return {**paths, "primary_dfi_stage_ii_iii": dfi, "secondary_os_all_stages": os}


def _plot_single_marker_comparison(directory: Path, single_results: dict,
                                  primary_panel_c, secondary_panel_c) -> dict[str, Any]:
    """Compare measured single-transcript models without treating missing as zero."""
    panel_order = [
        ("ENSG00000153363", "LINC00467"),
        ("ENSG00000236081", "ELFN1-AS1"),
        ("ENSG00000263429", "LINC00675 / TMEM238L"),
        ("ENSG00000233101", "HOXB-AS3"),
    ]
    settings = [
        ("primary_dfi_stage_ii_iii", "DFI stage II-III", BLUE, -0.18, primary_panel_c),
        ("secondary_os_all_stages", "OS all stages", ORANGE, 0.18, secondary_panel_c),
    ]
    fig, ax = plt.subplots(figsize=(9.4, 6.4))
    ax.set(title="Single-transcript models and the four-transcript panel",
           xlabel="Micropeptide-source RNA", ylabel="Held-out Harrell C-index",
           ylim=(0, 1))
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color="#e8e8e8", linewidth=0.6)
    ax.set_axisbelow(True)
    missing = []
    shown = {}
    x = np.arange(len(panel_order), dtype=float)
    for cohort_key, label, color, offset, panel_c in settings:
        rows = single_results.get(cohort_key, {})
        finite_x, finite_y = [], []
        shown[cohort_key] = {}
        for i, (ensembl, default_marker) in enumerate(panel_order):
            entry = rows.get(ensembl, {})
            value = entry.get("c_index")
            xpos = x[i] + offset
            if value is None or not np.isfinite(value):
                missing.append({"cohort": cohort_key, "ensembl": ensembl})
                ax.text(xpos, 0.03, "NA", ha="center", va="bottom", fontsize=8, color=color)
                continue
            value = float(value)
            finite_x.append(xpos)
            finite_y.append(value)
            ci = entry.get("c_index_ci95")
            valid_ci = (isinstance(ci, (list, tuple, np.ndarray)) and len(ci) == 2
                        and all(v is not None and np.isfinite(v) for v in ci))
            if valid_ci:
                low, high = (float(v) for v in ci)
                valid_ci = 0 <= low <= high <= 1
            if valid_ci:
                ax.plot([xpos, xpos], [low, high], color="#253445", linewidth=1, zorder=4)
                for bound in (low, high):
                    ax.plot([xpos-0.045, xpos+0.045], [bound, bound],
                            color="#253445", linewidth=1, zorder=4)
            shown[cohort_key][ensembl] = {"marker": entry.get("marker", default_marker),
                                        "c_index": value, "ci95_shown": bool(valid_ci)}
        if finite_x:
            ax.bar(finite_x, finite_y, width=0.31, color=color, alpha=0.82,
                   edgecolor="white", linewidth=0.6, label=f"Single transcript: {label}")
        if panel_c is not None and np.isfinite(panel_c):
            ax.axhline(float(panel_c), color=color, linewidth=1.5, linestyle="--",
                       label=f"Four-transcript panel: {label} ({float(panel_c):.3f})")
    ax.axhline(0.5, color=GREY, linewidth=0.8, linestyle=":", label="Chance (0.50)")
    ax.set_xticks(x, ["LINC00467", "ELFN1-AS1", "LINC00675 / TMEM238L", "HOXB-AS3"])
    ax.tick_params(axis="x", labelsize=9)
    ax.set_xlim(-0.65, len(panel_order)-0.35)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, 1.0), ncol=2,
              frameon=True, framealpha=0.94, facecolor="white", edgecolor="none", fontsize=8)
    _note(ax, "Each endpoint uses its own eligible cohort; bars show single-transcript models.\n"
              "95% CI bootstraps held-out predictions without model refitting. NA indicates unavailable estimates.")
    paths = _save(fig, directory, "fig6_single", axis_width="15cm", axis_height="9cm")
    return {**paths, "cohorts": shown, "missing": missing,
            "displayed_comparison": "Primary DFI stage II-III and secondary OS all stages"}


def export_extended_figures(
    figures_dir: str | Path,
    primary_plotting: dict[str, Any],
    secondary_plotting: dict[str, Any],
    single_results: dict[str, Any],
    primary_panel_c: float,
    secondary_panel_c: float,
    preamble_path: str | Path | None = None,
) -> dict[str, Any]:
    """Add the endpoint comparison after ``export_figures`` has run.

    Replaces fig1 with paired primary DFI(stage II-III)/secondary OS(all stages)
    KM plots and fig2 with OS ROC curves. Adds fig6 for four single-transcript
    models versus their cohort-specific four-transcript panel. Existing fig3,
    fig4, and fig5 remain the primary DFI forest, random-panel comparison and
    calibration. An optional DFI-all-stages sensitivity in ``single_results``
    is deliberately not mixed into this two-cohort display.
    """
    for expected, plotting in [("DFI", primary_plotting), ("OS", secondary_plotting)]:
        if plotting.get("endpoint", expected) != expected:
            raise ValueError(f"Expected {expected} plotting data; received {plotting.get('endpoint')}")
    directory = Path(figures_dir)
    directory.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 10,
        "axes.titlesize": 12, "axes.labelsize": 10,
        "legend.fontsize": 9, "axes.unicode_minus": False,
    })
    paths = {
        "km": _plot_km_comparison(directory, primary_plotting, secondary_plotting),
        "roc": {**_plot_roc(directory, secondary_plotting.get("roc", {}),
                            endpoint="OS", cohort_label="all stages"),
                "endpoint": "OS", "cohort": "secondary_os_all_stages"},
        "single": _plot_single_marker_comparison(directory, single_results,
                                                  primary_panel_c, secondary_panel_c),
    }
    preamble = Path(preamble_path) if preamble_path is not None else directory.parent / "preamble.tex"
    paths["preamble"] = write_preamble(preamble)
    return paths


def export_single_marker_km(
    figures_dir: str | Path,
    patients: pd.DataFrame,
    *,
    marker: str = "LINC00675 / TMEM238L",
    endpoint: str = "DFI",
    cohort_label: str = "stages II-III",
    logrank_p: float,
    expression_threshold: float,
    preamble_path: str | Path | None = None,
) -> dict[str, Any]:
    """Export descriptive single-RNA KM curves using a supplied expression split.

    Required columns are patient_id, time (days), event, expression
    (log2(CPM+1)), and expression_group (low/high). Low expression includes
    observations equal to the supplied full-cohort expression median. This
    function does not compute a prognostic score or reinterpret expression as
    risk. The supplied unadjusted log-rank p-value is reported verbatim.

    ``fig7_single_km.tex`` contains a visible explanatory caption. Publication
    users can instead include the caption-free ``fig7_single_km_plot.tex`` and
    ``fig7_single_km_caption.tex`` inside one LaTeX figure environment.
    """
    required = {"patient_id", "time", "event", "expression", "expression_group"}
    missing = required - set(patients.columns)
    if missing:
        raise ValueError(f"Missing single-marker KM columns: {sorted(missing)}")
    if endpoint not in {"DFI", "OS"}:
        raise ValueError("Single-marker KM endpoint must be DFI or OS")
    if not np.isfinite(expression_threshold):
        raise ValueError("Expression median must be finite")
    if not np.isfinite(logrank_p) or not 0 <= logrank_p <= 1:
        raise ValueError("Unadjusted log-rank p-value must be finite and between 0 and 1")
    d = patients.copy()
    if d.empty or d.patient_id.isna().any() or d.patient_id.duplicated().any():
        raise ValueError("Single-marker KM needs nonmissing unique patient IDs")
    if not np.isfinite(d[["time", "event", "expression"]].to_numpy(float)).all():
        raise ValueError("Single-marker KM outcomes and expression must be finite")
    if d.time.le(0).any() or not set(d.event.unique()) <= {0, 1, False, True}:
        raise ValueError("Single-marker KM requires positive times and binary events")
    expected_groups = np.where(d.expression.to_numpy(float) > expression_threshold, "high", "low")
    if not np.array_equal(d.expression_group.to_numpy(), expected_groups):
        raise ValueError("Expression groups must use low <= median and high > median")
    if set(d.expression_group.unique()) != {"low", "high"}:
        raise ValueError("Single-marker KM requires nonempty low and high expression groups")
    if not np.isclose(float(d.expression.median()), expression_threshold, rtol=1e-12, atol=1e-12):
        raise ValueError("Supplied expression threshold must equal the cohort expression median")

    directory = Path(figures_dir)
    directory.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 10,
        "axes.titlesize": 12, "axes.labelsize": 10,
        "legend.fontsize": 9, "axes.unicode_minus": False,
    })
    fig, ax = _axes(f"{marker} expression and {endpoint}", f"{endpoint} time (months)",
                    "Overall survival probability" if endpoint == "OS" else "DFI event-free probability")
    groups = {}
    outcome_word = "deaths" if endpoint == "OS" else "DFI events"
    for group_name, label, color in [("low", "Low expression", ORANGE),
                                     ("high", "High expression", BLUE)]:
        group = d.loc[d.expression_group.eq(group_name)]
        events = int(group.event.sum())
        km = KaplanMeierFitter(alpha=0.05).fit(
            group.time.to_numpy(float) / DAYS_PER_MONTH,
            event_observed=group.event.to_numpy(bool),
        )
        sf = km.survival_function_.iloc[:, 0]
        ci = km.confidence_interval_survival_function_
        ax.step(sf.index, sf.to_numpy(), where="post", color=color, linewidth=1.8,
                label=f"{label} (n={len(group)}, {outcome_word}={events})")
        ax.fill_between(ci.index, ci.iloc[:, 0], ci.iloc[:, 1], step="post",
                        color=color, alpha=0.12, linewidth=0)
        censored = km.event_table.loc[km.event_table.censored.gt(0)].index
        if len(censored):
            ax.plot(censored, km.predict(censored), "+", color=color,
                    markersize=4, markeredgewidth=0.6)
        groups[group_name] = {"n": len(group), "events": events}
    ax.set(ylim=(0, 1.02))
    ax.set_xlim(left=0)
    ax.legend(loc="lower left", frameon=False, fontsize=9)

    p_text = "< 1e-300" if logrank_p == 0 else f"= {logrank_p:.4g}"
    primary_word = "primary " if endpoint == "DFI" else ""
    caption = (
        f"Post hoc descriptive analysis of {primary_word}{endpoint} in COAD {cohort_label} "
        f"(n={len(d)}). Groups use the cohort median {marker} log2(CPM+1) expression "
        f"({expression_threshold:.6g}): low is at or below the median; high is above it. "
        f"Shading shows pointwise KM 95% CI; + marks censoring. Unadjusted log-rank p {p_text}. "
        "This expression-based comparison is not external validation."
    )
    # Save a clean publication plot before adding the visible caption. _save
    # escapes text for TeX; restore it before rendering the annotated PNG.
    fig.canvas.draw()
    original_text = [(a, a.get_text()) for a in fig.findobj(matplotlib.text.Text)]
    clean_plot = _save(fig, directory, "fig7_single_km_plot", save_png=False)
    for artist, content in original_text:
        artist.set_text(content)
    _note(ax, textwrap.fill(caption, width=99))
    annotated = _save(fig, directory, "fig7_single_km")

    escaped_caption = re.sub(r"(?<!\\)([%&#_])", r"\\\1", caption)
    caption_path = directory / "fig7_single_km_caption.tex"
    caption_path.write_text(
        "% Use with the caption-free fig7_single_km_plot.tex inside a figure environment.\n"
        f"\\caption{{{escaped_caption}}}\n"
        "\\label{fig:single-marker-expression-km}\n",
        encoding="utf-8",
    )
    preamble = Path(preamble_path) if preamble_path is not None else directory.parent / "preamble.tex"
    return {
        **annotated,
        "publication_plot_tex": clean_plot["tex"],
        "caption_tex": str(caption_path),
        "preamble": write_preamble(preamble),
        "marker": marker,
        "endpoint": endpoint,
        "cohort_label": cohort_label,
        "eligible_patients": len(d),
        "groups": groups,
        "expression_threshold_log2_cpm_plus_1": float(expression_threshold),
        "split_rule": "cohort expression median; low <= median; high > median",
        "logrank_p": float(logrank_p),
        "analysis_type": "post hoc descriptive expression split; unadjusted log-rank test",
        "caption": caption,
        "latex_usage": (
            "For the annotated standalone TikZ picture, input fig7_single_km.tex. "
            "For a publication figure, input fig7_single_km_plot.tex followed by "
            "fig7_single_km_caption.tex inside a figure environment; do not combine "
            "the embedded-caption picture with the separate caption."
        ),
    }
