# FinPanel proposed data/code deposit

Local candidate, 10 October 2026. **Not uploaded; no archival DOI; redistribution decisions remain pending.** Intended venue: PRISM. Read `../rights-and-access.md` before any public deposit. The software is preserved under its existing MIT licence; that does not relicense issuer filings or automatically assign an article/data licence.

## Contents and limits

- `repository/`: exact current-commit source, tests, small frozen fixtures, documentation, relevant example/analysis/plot scripts, figure CSVs, the original research manuscript and evidence matrix, and prior execution records. Original source and evidence are unchanged.
- `archived/`: lossless gzip copies of both complete checkpoints (24,000 decision rows plus diagnostics), both reports/job receipts, 200 panel receipts, 100 source-verification files containing 200 queries, and the 406-object snapshot manifest. Gzip timestamps are fixed; `source-manifest.json` records original and transport hashes.
- `historical-source/`: package source/assets from matching candidate commit `ce97d41378f2a11db711023db1aa8caf9978d054`. It matches the historical covered Python fingerprint; it is not asserted to be the unique original whole checkout. No dependency wheels or native runtime are bundled.
- `case-arithmetic.json`: four Mattel operand comparisons and literal frozen-source pointers. The FY2018 revised subtraction is a withheld hypothetical residual, not an admitted output.
- `verify_deposit.py`: offline recount and integrity checks using Python's standard library. `claim-data-crosswalk.md` maps statistics to included material.

**Supported without the large local corpus:** recalculate all four figure datasets; recount policy pairs, result states, verification-query outcomes, temporal-audit records, ledgers and report totals; inspect featured frozen cases; regenerate plots; inspect implementation; run the bundled current example after installing its dependencies. Archived instrumented totals, test results, timings and the one-panel replay remain historical records, not experiments rerun by these recounts.

**Not supported by this compact candidate:** rerunning financial resolution for the complete historical grid, rehashing the missing 406 raw objects, regenerating the 900 original output files, rerunning the full mutation/source-verification experiments against that snapshot, or independently adjudicating every accounting decision. The manifest lists 530,856,505 raw bytes but does not contain those bytes. Live SEC downloads would be a new vintage, not replacements. Some case fixtures overlap this corpus but do not constitute a complete replay store. No automatic acquisition is attempted.

## Recompute the supplied processed results

Run from this directory using Python 3.12 (the executed project environment was 3.12.14). Do not use `-O`, which disables assertion checks. Use fresh destinations:

```sh
python3 verify_deposit.py --output ../new-deposit-check.json
python3 materialize.py ../recompute-workspace
```

The first command needs no third-party libraries and reads the supplied artifacts only. The second copies them into the repository-relative layout expected by existing scripts. It does not fill absent raw objects.

For figure-data extraction, provision a separate environment, install the observed current dependencies and package, then extract in that new workspace:

```sh
cd ../recompute-workspace
python3.12 -m venv .venv
.venv/bin/python -m pip install -r paper/scripts/current-runtime-requirements.txt
.venv/bin/python -m pip install --no-deps .
.venv/bin/python paper/scripts/extract_figure_data.py
.venv/bin/python paper/scripts/render_tables.py
python3.12 -m venv plot-env
plot-env/bin/python -m pip install -r paper/scripts/plot-requirements.txt
plot-env/bin/python paper/scripts/plot_figures.py
```

Installation may require network access; analysis/plotting is offline. Python 3.12.14, Matplotlib 3.11.2 and NumPy 2.5.3 produced the supplied figures. Other rendering environments may differ in bytes; compare numerical data and labels. This preparation checked fresh extraction and figure regeneration in the observed environments. Build backends/installers are setup dependencies, not fully frozen original OS identity.

For the small offline example, after current-environment installation:

```sh
.venv/bin/python -m finpanel.example output/new-public-example
```

Expected previously observed semantics: six cells, three reported and three ambiguous, replay true. Existing results are at `paper/reviewer-runs/public-example/`. Source-installation/figure commands act only on the new workspace. Do not run the full archive audit or historical replay there expecting success without the missing Tier B evidence; see `paper/reproducibility.md` for their actual input requirements.

Historical source can be installed separately with the receipt's Python 3.12.14/httpx 0.28.1/simplejson 4.2.0 identity and compatible export dependencies. Verify `software_identity()` against `paper/reviewer-runs/historical-recovery.json` before attempting replay with an authorised copy of the absent store. This package does not demonstrate a fresh historical-source installation or cross-platform execution.

## Deposit plan for the author

Confirm rights, contributor declarations, deposit creators and licences. Choose an open archive, freeze a reviewed version, deposit processed data and licensed analysis code, obtain actual persistent identifiers, and insert them into manuscript availability/metadata. An archive can contain related software and data components with clearly scoped licences. Do not apply a blanket licence to third-party issuer material. Resolve whether omitted raw material is acceptable for the editor's intended review scope; full historical replay needs a separately authorised immutable store. Nothing here asserts that PRISM has accepted that limitation. Upload/publication requires the responsible human's action and is outside this preparation.
