"""Expand the candidate into a NEW working directory for existing paper scripts."""
from pathlib import Path
import argparse,gzip,json,shutil
p=argparse.ArgumentParser();p.add_argument('destination',type=Path);a=p.parse_args();d=Path(__file__).resolve().parent
if a.destination.exists():raise SystemExit('Destination exists: choose a new directory.')
shutil.copytree(d/'repository',a.destination)
for r in json.loads((d/'source-manifest.json').read_text())['copies']:
 if r['encoding']=='gzip':
  target=a.destination/r['source'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.decompress((d/r['destination']).read_bytes()))
print('Materialized processed evidence and software; no Tier B raw objects are present.')
