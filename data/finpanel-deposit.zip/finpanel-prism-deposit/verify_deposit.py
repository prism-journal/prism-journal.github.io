"""Offline processed-data checks; stdlib only. No SEC access or financial rerun."""
from pathlib import Path
from collections import Counter
from decimal import Decimal
from hashlib import sha256
import argparse,csv,gzip,json,re
D=Path(__file__).resolve().parent;R=D/'repository'
def load(p):
 raw=p.read_bytes();return json.loads(gzip.decompress(raw) if p.suffix=='.gz' else raw)
def digest(x):return sha256((json.dumps(x,sort_keys=True,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()).hexdigest()
def csvrows(n):return list(csv.DictReader((R/'paper/figure-data'/n).open()))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();assert not args.output.exists(),'Choose a fresh result path'
 manifest=load(D/'source-manifest.json')
 for x in manifest['copies']:
  b=(D/x['destination']).read_bytes();assert sha256(b).hexdigest()==x['packaged_sha256'],x['destination']
  raw=gzip.decompress(b) if x['encoding']=='gzip' else b
  assert sha256(raw).hexdigest()==x['source_sha256'] and len(raw)==x['source_bytes']
 report=load(R/'docs/release-scale-validation.json');rows=[];checkpoints=[]
 for n in range(2):
  base=D/f'archived/output/wp7/broad-shard-{n}';cp=load(base/'checkpoint.json.gz');receipt=load(base/'receipt.json.gz');rr=load(base/'report.json.gz')
  assert digest(cp['state']['cells'])==receipt['semantic_dataset_hash']
  assert digest(rr)==receipt['report_hash']==report['shards'][n]['report_hash']
  checkpoints.append(cp);rows+=cp['state']['cells']
 rows.sort(key=lambda r:tuple(r[k] for k in ('cik','revision_policy','as_of','fiscal_year','period','metric')))
 assert len(rows)==24000 and digest(rows)==report['semantic_dataset_hash']
 counts=Counter(r['state'] for r in rows)
 for x in csvrows('figure-1-states.csv'):assert int(x['cells'])==counts[x['state']] and int(x['denominator'])==24000
 for fn in ['figure-2-metrics.csv','figure-4-metric-period.csv']:
  for x in csvrows(fn):
   group=[r for r in rows if r['metric']==x['metric'] and ('period' not in x or r['period']==x['period'])];c=Counter(r['state'] for r in group);res=c['resolved_reported']+c['resolved_derived']
   assert len(group)==int(x['denominator']);assert c['resolved_reported']==int(x['reported']);assert c['resolved_derived']==int(x['derived']);assert res==int(x['resolved']);assert len(group)-res==int(x['unresolved']);assert format(Decimal(res)*100/len(group),'.10f')==x['coverage_percent']
 key=lambda r:tuple(r[k] for k in ['cik','metric','fiscal_year','period','as_of'])
 first={key(r):r for r in rows if r['revision_policy']=='first_reported'};latest={key(r):r for r in rows if r['revision_policy']=='latest_available'};assert set(first)==set(latest) and len(first)==12000
 transitions=Counter();both=changed=0;changed_pairs=[]
 for k,a in first.items():
  b=latest[k];transitions[a['state'],b['state']]+=1;ar=a['state'].startswith('resolved');br=b['state'].startswith('resolved');vc=False
  if ar and br:
   both+=1;assert a['unit']==b['unit'];vc=Decimal(a['value'])!=Decimal(b['value']);changed+=vc
  if a['state']!=b['state'] or vc:changed_pairs.append(k)
 for x in csvrows('figure-3-transitions.csv'):assert transitions[x['first_state'],x['latest_state']]==int(x['pairs'])
 assert both==8339 and changed==146 and sum(n for (a,b),n in transitions.items() if a!=b)==28 and transitions['resolved_derived','conflicted']==28
 assert len(changed_pairs)==len(csvrows('figure-3-changed-pairs.csv'))==174
 assert sum(cp['state']['invariant_count'] for cp in checkpoints)==report['invariant_checks']==2435238
 assert sum(cp['state']['replays'] for cp in checkpoints)==report['successful_replays']==200
 assert not any(cp['state']['failures'] for cp in checkpoints)
 findings=[f for cp in checkpoints for f in cp['state']['findings']];assert sum('incompatible_revision_operands' in f['categories'] for f in findings)==23
 queries=[]
 for p in (D/'archived/output/wp7').glob('broad-shard-*/*/source-verification.json.gz'):queries+=load(p)['rows']
 qcounts=Counter(r['verification_state'] for r in queries);assert len(queries)==200 and qcounts==Counter(report['source_verification_states']);assert qcounts=={'verified_unique':6,'verified_multiple_equivalent':7,'instance_unavailable':187}
 temporal=load(R/'docs/release-temporal-audit.json');tr=temporal['results'];assert len(tr)==100 and sum(x['checks'] for x in tr)==500 and all(x['passed'] and x['exercised'] and x['mutated_future_observations']>0 and all(x['outcomes'].values()) for x in tr)
 assert Counter(x['concept'] for x in tr)=={'NetIncomeLoss':98,'NetCashProvidedByUsedInOperatingActivities':2}
 inv=load(R/'docs/release-golden-inventory.json');assert sum(len(load(R/x['file'])[x['key']]) for x in inv['ledgers'])==255
 snap=load(next((D/'archived/output/wp7/broad-corpus/evidence/snapshots').glob('*.gz')));assert len(snap['artifacts'])==406 and sum(a['size'] for a in snap['artifacts'])==530856505
 cpfiles=sum(len(files) for cp in checkpoints for files in cp['completed'].values());assert cpfiles==900
 universe=load(R/'src/finpanel/validation/release-universe.json');included=[x for x in universe['issuers'] if x['status']=='included' and x['tier_b']];assert len(included)==100 and len({x['category'] for x in included})==14
 fixtures=0
 for p in (R/'tests/fixtures').glob('*/manifest.json'):
  m=load(p)
  for a in m.get('artifacts',[]):
   if not isinstance(a,dict) or 'filename' not in a or 'compressed_sha256' not in a:continue
   b=(p.parent/a['filename']).read_bytes();raw=gzip.decompress(b);assert sha256(b).hexdigest()==a['compressed_sha256'] and sha256(raw).hexdigest()==a['artifact']['sha256'];fixtures+=1
 assert fixtures==96
 for c in load(D/'case-arithmetic.json'):assert c['annual']-c['nine_month']==c['residual_USD']
 assert '814 passed in 284.79s' in (R/'paper/audit/current-tests.log').read_text()
 recovery=load(R/'paper/reviewer-runs/historical-recovery.json');assert len(recovery['matching_commits'])==4 and len(recovery['matching_wheels'])==6
 smoke=load(R/'paper/reviewer-runs/historical-smoke-replay.json');assert smoke['replayed_panels']==1 and smoke['rows']==120 and smoke['results'][0]['matched']
 resume=load(R/'docs/release-resume-verification.json');assert sum(x['completed_issuers'] for x in resume['shards'])==100 and all(x['semantic_files_byte_identical'] for x in resume['shards'])
 summary={'scope':'Offline recomputation from supplied processed artifacts; not full financial replay, fresh experimental instrumentation, or human accounting review.','copied_artifacts_verified':len(manifest['copies']),'cells':len(rows),'states':dict(counts),'matched_pairs':len(first),'jointly_resolved_pairs':both,'changed_values':changed,'state_changes':28,'source_query_states':dict(qcounts),'temporal_comparisons':500,'golden_expectations':255,'fixture_pairs_rehashed':fixtures,'snapshot_manifest_objects':406,'snapshot_manifest_bytes':530856505,'checkpoint_output_manifest_entries':cpfiles,'all_four_figure_counts_recomputed':True,'large_raw_corpus_included':False,'archived_814_test_log_and_one_replay_record_checked':True}
 args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
