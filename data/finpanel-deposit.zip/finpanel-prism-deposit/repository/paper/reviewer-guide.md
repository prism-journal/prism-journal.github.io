# Guide for human and external editorial review

Prepared 10 October 2026. **Review materials are ready; human validation has not occurred.** This guide, the selection proposal and the assistant’s editorial check are not independent accounting adjudication, peer review or author endorsement. No reviewer has been contacted. Use this guide for a scoped editorial assessment now; full historical evidence inspection requires authorized access to local artifacts.

## Contribution and boundaries

FinPanel makes the reproducible object a financial-data decision with its evidence, policies and unresolved state—not only a scalar. The paper documents one bounded implementation of filing-linked eligibility, conservative fiscal interpretation, revision selection, guarded quarter derivation and semantic replay. The principal contribution is the inspectable artifact and its audit, not invention of point-in-time data engineering or proof of superiority.

The current inspected software is 0.1.0a2 at commit `28dcecce208a578b4a7b507bbf6d93018b4ab1d6`. The 24,000-cell, 100-issuer purposive archive is 0.1.0a1. Its covered Python-source fingerprint and a compatible runtime were recovered; only **one 120-row historical panel** was newly replayed during paper preparation. The archived 200-success replay count remains historical. The six-cell bundled example separately exercises current software.

The manuscript reports 16,706/24,000 scalar resolutions (69.61% coverage). It does not estimate accuracy. The 13/200 original-source verification result is a different, capture-vintage query set. Repeated policies, periods and cutoffs are dependent; familiar large issuers do not make the sample representative of the US market.

## What reviewers should challenge

| Question | Evidence to examine | What would require correction or qualification |
|---|---|---|
| Does the contribution survive known temporal/provenance work? | Manuscript §2, related-work-comparison.md, E03–E09 | Priority, uniqueness or superiority language unsupported by an examined comparison |
| Is “point-in-time” appropriately bounded? | §§3–4; C01–C05; snapshot retrieval window and acceptance/date-only rules | Conflating a 2026 capture with historical API delivery, first public knowledge or tradability |
| Can excluded evidence influence period interpretation? | `asof.py`, period/calendar tests, K03; saved mutation records | A counterexample to the stated boundary; distinguish a reproducible bug from a hypothetical concern |
| Are concepts, units and intervals economically comparable? | Exact original contexts and C07–C12, K01–K06 | An accepted scalar with mismatched scope, or a refusal avoidable with evidence the contract should admit |
| Does a shared filing justify revised subtraction? | Both Mattel cases and the original explanatory narrative | Treating the guard as sufficient proof of comparability, or treating a blocked residual as economically false |
| Are the figure denominators appropriate? | Four CSVs, §6, N02–N18 | Inferring policy transitions from marginals, interpreting 146 changes as events, or using 12,000 instead of 8,339 for numerical differences |
| What does replay actually reproduce? | C15–C17, recovered runtime, one-panel replay record | Confusing a matching Python fingerprint with a unique whole checkout/OS, or repeatability with truth |
| Is abstention useful and proportionate? | Reported, derived and unresolved sample cases below | Unsupported resolution or unnecessary refusal; document the reference judgment instead of treating the software as truth |
| Can a reviewer obtain the required inputs? | Reproducibility instructions and manifests | Local-only files unavailable to the reviewer; hashes cannot replace bytes |

The Wang full text remains unavailable after the recorded access attempts. The narrow artifact contribution is defensible for assessment without claiming knowledge of unexamined methods. The editor may require further comparison for the chosen venue. Do not report a feature as absent from Wang solely because it is unmentioned in the accessible abstract.

## Inspection routes

### A. Editorial reading and public example

Read the abstract, §§3, 6–9, evidence-matrix.md and disclosure-options.md. Confirm whether the narrow contribution fits the venue before requesting larger experiments. The byline is **Finley Dou — Shanghai High School International Division**, supplied by the author; contribution statements, funding/interests and editorial relationships are not inferred from it.

Obtain the repository at the stated commit plus this paper supplement. The supplement is not claimed to be part of that Git commit. The repository’s bundled example uses frozen source bytes and needs no SEC credentials. After preparing the current environment as described in `reproducibility.md`, run from the repository root into a **new** destination:

```sh
.venv/bin/python -m finpanel.example output/human-review-public-example
```

Expect six HRB FY2022 requests: three reported resolutions and three ambiguous outcomes, with semantic replay verified. Inspect `summary.json`, `receipt.json`, `panel.csv` and `panel.csv.provenance.json` in that destination. Trace at least one resolution and one refusal; a successful example is not a full-corpus reproduction. The preparation run’s identities and logs are in reproducibility.md and `reviewer-runs/public-example.log`. A fresh reviewer execution should have its own dated log and actual environment record.

### B. Full archive access and read-only audit

The historical corpus, shard output trees and native wheelhouse are local/ignored. Ask the author for an authorized access arrangement if needed; this package itself has not distributed them. If they are unavailable, explicitly limit the review to supplied summaries, fixtures and public-example behavior. Do not silently fetch new SEC bytes and call them the historical snapshot.

With access, check the supplied inventory **before rebuilding it**:

```sh
.venv/bin/python paper/scripts/check_reviewer_manifest.py
.venv/bin/python paper/audit/verify_evidence.py --output paper/reviewer-runs/human-review-verification.json
```

Use fresh output names. The audit reads the preserved rows and checks hashes; it is not financial recomputation. `reviewer-manifest.json` identifies bytes available during preparation, not a guarantee that a recipient has received every listed file. Its checker intentionally reports missing inputs.

### C. Historical replay and individual row provenance

Follow `reproducibility.md` to reconstruct the a1 environment from saved wheels. Its native wheelhouse is specific to macOS ARM64/Python 3.12; the demonstrated runtime is Python 3.12.14. Confirm the complete recorded software object, not merely the version label. For a new bounded replay:

```sh
output/reviewer-historical-env/bin/python paper/scripts/replay_historical.py --output paper/reviewer-runs/human-review-one-panel.json
```

That interpreter path is created by the reproduction recipe; it is not presumed present in a fresh clone. The default covers one preserved panel; `--all` is optional and expensive, not an obligation for every reviewer. Success says nothing by itself about accounting correctness. Full validation instrumentation and mutations are separate archived experiments.

`review-sample.csv` gives each proposed case’s complete request key, both row IDs, receipt IDs, checkpoint JSON pointers and provenance-sidecar paths/pointers. A provenance sidecar is keyed by row ID within its policy-specific path. Row IDs are shared across the two policies in this archive; use the full request key plus policy and file path, never row ID alone, to identify an archived result. Follow its considered/selected/rejected evidence to source URL, raw-response hash, JSON pointer and accession. Locate raw bytes through the pinned snapshot’s `artifacts` entries in `output/wp7/broad-corpus/evidence/snapshots/7ee0bbe49b267ce50d63bf1f45bc4f62b017a195db7e2fcefe99c3dc68669ef0.json`; its `locator` is relative to that evidence store. Do not treat the aggregate pointer as a substitute for an original XBRL context when adjudicating dimensions or narrative.

### D. Featured frozen-source cases

Use `tests/golden/release-calendar.json` and `release-revisions.json` as **claims to challenge**, not answer keys. Match their raw hashes to `tests/fixtures/release/manifest.json`. Each manifest entry gives a compressed filename/hash and an `artifact` object with the decompressed hash, source URL, retrieval time and byte size. Decompress to a fresh scratch path or inspect in memory; never overwrite the fixture. Inspect the literal pointer in the decompressed JSON and, where preserved, the original filing narrative. The test names below locate implemented expectations; passing them is not independent confirmation.

If an original context or necessary note is missing, record **uncertain / evidence unavailable**. The reviewer may specify an additional document needed; any later acquisition must be separately dated and must not replace this snapshot. No such acquisition is performed by this package.

## Focused accounting checklist

Record separate judgments about **contract execution** and **accounting adequacy**. A reviewer can agree that a rule was executed correctly and disagree that the rule is economically adequate.

| Case | Exact starting locators | Questions for human source review |
|---|---|---|
| H&R Block transition | Calendar IDs `calendar-02`, `06`, `10`, controls `04`, `08`, `12`; `test_transition_diagnostics_do_not_assign_year`; filing `0001838862-21-000036`; K01/K03 | Does the filing establish May 1–June 30, 2021 as a transition? Confirm 61 inclusive days, prior April year end and subsequent June year end. Is withholding ordinary FY/Q labels justified? Can current metadata be excluded while preserving actual historical boundaries? Do surrounding ambiguous candidates justify refusal for a fiscal-label query? |
| Week and leap calendars | Calendar IDs `15`–`22`; `test_calendar_golden`; K02 | Read actual boundaries: Costco/Target 371-day years, Target 364-day year and 98-day Q4, Nike 366-day year. Check inclusivity and admitted fiscal anchors. Do not infer fiscal identity solely from duration. An extended transition year is not demonstrated by these cases. |
| Mattel 2017 revised evidence | Revision ledger literal sources; `test_original_narratives_support_only_the_declared_claims`, `test_authentic_amended_annual_residual`; amendment `0001628280-19-013975`; K04/K05 | Distinguish the narrative’s formal restatement scope from other revisions. Verify original annual/nine-month USD −1,053,836,000 / −772,553,000 and amended −1,054,579,000 / −879,286,000. Check same concept, consolidated scope, start date, unit, amendment and filing eligibility. Recalculate derived Q4 −281,283,000 / −175,293,000. Explain the November 11 versus November 13, 2019 noon-UTC policy outcomes. |
| Mattel 2018 incompatible operands | `test_authentic_separately_revised_operands_do_not_mix`; raw CompanyFacts hash `b5b67c2c769d57e73c0289c7fa5e8b30ca9a9429dbc289556ff3670622c84161`, `/facts/us-gaap/NetIncomeLoss/units/USD/{214,215,221,222}`; K06 | Verify original residual +14,913,000. Annual revised accession ends `013975`, cumulative revised accession ends `013987`; the mathematical +9,639,000 residual is withheld. Does additional narrative establish compatibility despite separate accessions? If yes, distinguish a defensible contract limitation from an arithmetic error. If no, record what is missing, not that the number is proven false. |
| Kraft Heinz causal restraint | Revision IDs `15`–`20`; `test_revision_vocabulary_does_not_claim_accounting_causality`; K07 | Do changed comparative observations establish only a version difference, or does inspected narrative justify a particular accounting cause? Do not infer restatement, fraud or error solely from changed values. |

For every case: verify issuer/accession; represented period; acceptance timestamp or date-only precision; financial cutoff versus retrieval date; exact concept, unit and original context; selected/rejected revisions; arithmetic and calendar support; output state and reasons. Record whether the evidence supports a unique scalar, several alternatives or no conclusion. For unavailable results, inspect the eligible candidate search rather than claiming an issuer never disclosed the fact anywhere.

## Proposed small stratified source review

**Proposal only: 20 matched request pairs (40 archived rows), with 20 distinct issuers, additional to the featured-case checklist. No source adjudication has been performed.** The unit is a fixed CIK/metric/fiscal-year/period/cutoff request under both policies, not an independent economic event. The paired view avoids treating two policy versions as separate confirmations.

| Stratum | Pairs | Reason for allocation |
|---|---:|---|
| Same reported state and numerical value, one per metric | 6 | Inspect ordinary successful selections across all supported metrics, including three instant concepts |
| Same derived state and numerical value: OCF Q2/Q3/Q4, net income Q4, revenue Q4 | 5 | Cover all three subtraction forms and all three derivable metrics, where provenance compatibility matters most |
| Both resolve but numerical value changes: one reported, one derived | 2 | Test policy-sensitive values even when the state remains stable |
| Derived under first, conflicted under latest: one OCF, one other metric | 2 | Examine observed scalar losses without assuming the guard’s causal contribution or economic correctness |
| Same unresolved state: one each unavailable, ambiguous, insufficient, conflicted, unsupported | 5 | Challenge both necessary refusal and potentially excessive abstention |
| Total | 20 | Broad diagnostic coverage within a small review workload; no statistical power or error-rate claim |

The selected proposal has five pairs in each of the four fiscal-year/cutoff combinations. The target of 20 is a workload/design choice, not a sample-size calculation. Rare and difficult states are intentionally over-sampled; results cannot estimate market accuracy or even a design-unbiased benchmark error rate. There is no nonempty verification-failed stratum in this panel. The separate 200 source-verification queries are not silently included in this sample.

`review-sample.csv` contains a concrete proposal, selected from verified archived rows. `review-sample-manifest.json` records candidate counts, input hashes, row evidence files, the frozen selection rule and fiscal-year/cutoff mix. `scripts/select_review_sample.py` reproduces the **selection only**. It allocates scarce strata first, excludes the featured HRB/MAT/COST/TGT/NKE/KHC issuers, requires a distinct issuer per pair, prefers the least-used year/cutoff combination, and breaks ties with a fixed salted hash of the request key. These deterministic choices reduce discretionary picking after seeing source conclusions; they do not make the sample random or representative.

A reviewer may reject or amend this proposal. Record any substitution, reason and original case before examining replacement outcomes. If evidence is inaccessible, retain that case as uncertain rather than quietly substituting an easier success. Inspect original source evidence before consulting project expectations where feasible; the supplied state-stratified selection is not blinded, and no blinded-review claim should be made. Different review workloads can use the same strata with an explicitly revised allocation.

## Per-case recording form

Copy once per featured case or sample pair; leave unused fields blank rather than inventing a verdict.

| Field | Reviewer entry |
|---|---|
| Review ID / sample ID / date / reviewer and relevant expertise or interests | |
| Manuscript version/hash, section and claim IDs | |
| Full request key, policies, software identity and snapshot | |
| Evidence actually examined: file/hash/pointer/accession/context/page | |
| Evidence unavailable or not examined | |
| Source-based expected period, value/unit or justified refusal, before comparison where feasible | |
| Contract-execution judgment: agree / disagree / uncertain / not assessed | |
| Accounting-adequacy judgment: agree / disagree / uncertain / not assessed | |
| Reason and alternative interpretation; arithmetic/timing/scope checks | |
| Severity: factual correction / evidentiary limitation / wording / optional extension | |
| Requested correction or additional evidence; scope and feasibility | |
| Author response, supporting evidence and exact manuscript change | |
| Reviewer follow-up: resolved / partly resolved / unresolved; rationale | |

Use review-response-template.md for the consolidated exchange. An author’s explanation alone does not convert a reviewer’s unresolved disagreement into agreement. If no human review has occurred, keep every verdict unfilled and the review status “not reviewed.” The editor decides the necessary review depth and disposition; this guide makes no publication certification.
