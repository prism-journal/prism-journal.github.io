"""Read-only paper audit; writes a new --output result, refusing an existing file.

Run from the repository root with the current FinPanel interpreter and --output PATH.
This recounts archived outputs; it does not rerun the historical benchmark.
"""
from collections import Counter
from hashlib import sha256
import gzip
import json
from pathlib import Path
import subprocess
import argparse

from finpanel.serialization import loads
from finpanel.snapshots.store import digest
from finpanel.snapshots.pipeline import software_identity

ROOT = Path(__file__).resolve().parents[2]


def read(path):
    return loads((ROOT / path).read_bytes())


def filehash(path):
    h = sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT/'paper/audit/verification.json')
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit('Refusing to overwrite an existing audit; choose a fresh --output path.')
    summary = read('docs/release-scale-validation.json')
    universe = read('src/finpanel/validation/release-universe.json')
    issuers = [i for i in universe['issuers'] if i['status'] == 'included' and i['tier_b']]
    assert len(issuers) == len({i['cik'] for i in issuers}) == 100
    assert dict(Counter(i['category'] for i in issuers)) == summary['category_distribution']
    cells, shard_checks, reports, jobs = [], [], [], []
    checked_outputs = 0
    for number in range(2):
        base = Path(f'output/wp7/broad-shard-{number}')
        checkpoint, receipt, report = [read(base / name) for name in ('checkpoint.json', 'receipt.json', 'report.json')]
        assert digest(report) == receipt['report_hash'] == summary['shards'][number]['report_hash']
        assert digest(checkpoint['state']['cells']) == receipt['semantic_dataset_hash']
        for cik, paths in checkpoint['completed'].items():
            for name, expected in paths.items():
                assert filehash(ROOT / base / cik / name) == expected, (cik, name)
                checked_outputs += 1
        assert len(checkpoint['completed']) == 50
        assert not checkpoint['state']['failures']
        cells.extend(checkpoint['state']['cells'])
        reports.append(report)
        jobs.append(checkpoint['job'])
        shard_checks.append({'job_id': checkpoint['job_id'], 'cells': len(checkpoint['state']['cells']), 'report_hash': receipt['report_hash']})
    cells.sort(key=lambda r: tuple(r[k] for k in ('cik', 'revision_policy', 'as_of', 'fiscal_year', 'period', 'metric')))
    assert len(cells) == 100 * 6 * 2 * 5 * 2 * 2 == 24000
    assert {r['cik'] for r in cells} == {i['cik'] for i in issuers}
    assert not set(jobs[0]['issuers']) & set(jobs[1]['issuers'])
    assert all(j['universe_hash'] == digest(universe) == summary['universe_hash'] for j in jobs)
    assert digest(cells) == summary['semantic_dataset_hash']
    assert len({tuple(r[k] for k in ('cik','revision_policy','as_of','fiscal_year','period','metric')) for r in cells}) == 24000
    states = Counter(r['state'] for r in cells)
    assert dict(states) == {k:v for k,v in summary['states'].items() if v}
    for dimension in ('metric','period','revision_policy','cik'):
        for group, expected in summary['coverage_by'][dimension].items():
            rows = [r for r in cells if r[dimension] == group]
            assert len(rows) == expected['total']
            assert sum(r['state'].startswith('resolved_') for r in rows) == expected['resolved']
            assert dict(Counter(r['state'] for r in rows)) == expected['states']
    for key in ('invariant_checks','successful_replays','source_verification_queries','unexpected_mismatches'):
        assert sum(r[key] for r in reports) == summary[key]
    for key in ('failure_categories','source_verification_states'):
        counts = Counter()
        for r in reports:
            counts.update(r[key])
        assert dict(counts) == summary[key]
    snapshot_path = Path('output/wp7/broad-corpus/evidence/snapshots') / (summary['snapshot_id']+'.json')
    snapshot = read(snapshot_path)
    assert snapshot.pop('snapshot_id') == summary['snapshot_id']
    assert all(digest(snapshot) == j['source_manifest_hash'] for j in jobs)
    for artifact in snapshot['artifacts']:
        path = ROOT / 'output/wp7/broad-corpus/evidence' / artifact['locator']
        assert path.stat().st_size == artifact['size']
        assert filehash(path) == artifact['sha256']
    inventory = read('docs/release-golden-inventory.json')
    for ledger in inventory['ledgers']:
        raw = (ROOT / ledger['file']).read_bytes()
        assert digest(loads(raw)) == ledger['ledger_hash']
        assert len(loads(raw)[ledger['key']]) == ledger['expectations']
    assert sum(x['expectations'] for x in inventory['ledgers']) == 255
    fixture_checks = 0
    for fixture in ('release','broad'):
        base = Path('tests/fixtures') / fixture
        manifest = read(base/'manifest.json')
        for item in manifest['artifacts']:
            compressed = (ROOT/base/item['filename']).read_bytes()
            assert sha256(compressed).hexdigest() == item['compressed_sha256']
            raw = gzip.decompress(compressed)
            assert sha256(raw).hexdigest() == item['artifact']['sha256']
            fixture_checks += 1
    temporal = read('docs/release-temporal-audit.json')
    assert len(temporal['results']) == 100
    assert sum(r['checks'] for r in temporal['results']) == temporal['checks'] == 500
    assert all(r['exercised'] and r['passed'] and r['mutated_future_observations'] > 0 and all(r['outcomes'].values()) for r in temporal['results'])
    tracked = subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
    tracked_hashes = {p: filehash(ROOT/p) for p in tracked if p and (ROOT/p).is_file()}
    out = {
        'audit_date': '2026-10-10',
        'method': 'Read-only recount and hash verification of archived outputs, not historical benchmark re-execution or external accounting adjudication.',
        'commit': subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        'current_software': software_identity(), 'historical_software': summary['software'],
        'historical_shards': shard_checks, 'verified_archived_output_files': checked_outputs,
        'requested_and_observed_cells': len(cells), 'states': dict(sorted(states.items())),
        'resolved': states['resolved_reported']+states['resolved_derived'],
        'scalar_coverage_percent': 100*(states['resolved_reported']+states['resolved_derived'])/len(cells),
        'snapshot_id': summary['snapshot_id'],
        'snapshot_artifacts_verified': len(snapshot['artifacts']),
        'snapshot_raw_bytes_verified': sum(a['size'] for a in snapshot['artifacts']),
        'snapshot_retrieval_range': [min(a['retrieved_at'] for a in snapshot['artifacts']),max(a['retrieved_at'] for a in snapshot['artifacts'])],
        'golden_expectations_recounted': 255, 'fixture_artifacts_hash_verified': fixture_checks,
        'archived_mutation_checks_recounted': 500,
        'mutation_concepts': dict(Counter(r['concept'] for r in temporal['results'])),
        'metric_coverage': summary['coverage_by']['metric'],
        'policy_coverage': summary['coverage_by']['revision_policy'],
        'source_verification_states': summary['source_verification_states'],
        'tracked_file_hashes': tracked_hashes,
    }
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ('tracked_file_hashes','metric_coverage','policy_coverage')},indent=2))


if __name__ == '__main__':
    main()
