"""Select a proposed diagnostic human-review sample; no adjudication or new experiment.

Reads existing checkpoint rows and verifies their semantic hashes. Writes only
paper/review-sample.csv and paper/review-sample-manifest.json (derived proposal).
"""
from collections import Counter
import csv
from decimal import Decimal
from hashlib import sha256
import json
from pathlib import Path
from finpanel.serialization import loads
from finpanel.snapshots.store import digest
ROOT=Path(__file__).resolve().parents[2]
KEY=('cik','metric','fiscal_year','period','as_of')
EXCLUDE={'0000012659','0000063276','0000909832','0000027419','0000320187','0001637459'}
SEED='finpanel-human-review-proposal-v1'


def main():
    sources=[];rows=[];locations={}
    def record(p):return {'path':str(p.relative_to(ROOT)),'sha256':sha256(p.read_bytes()).hexdigest()}
    report=loads((ROOT/'docs/release-scale-validation.json').read_bytes())
    sources.append(record(ROOT/'docs/release-scale-validation.json'))
    for n in range(2):
        cp=ROOT/f'output/wp7/broad-shard-{n}/checkpoint.json';d=loads(cp.read_bytes());sources.append(record(cp))
        receipt=ROOT/f'output/wp7/broad-shard-{n}/receipt.json';r=loads(receipt.read_bytes());sources.append(record(receipt))
        assert digest(d['state']['cells'])==r['semantic_dataset_hash']
        for index,row in enumerate(d['state']['cells']):
            rows.append(row);locations[row['row_id'],row['revision_policy']]=(str(cp.relative_to(ROOT)),f'/state/cells/{index}',n)
    rows.sort(key=lambda r:tuple(r[k] for k in ('cik','revision_policy','as_of','fiscal_year','period','metric')))
    assert len(rows)==24000 and digest(rows)==report['semantic_dataset_hash']
    key=lambda r:tuple(r[k] for k in KEY)
    f={key(r):r for r in rows if r['revision_policy']=='first_reported'}
    l={key(r):r for r in rows if r['revision_policy']=='latest_available'}
    assert len(f)==len(l)==12000 and f.keys()==l.keys()
    def same(a,b,state):return a['state']==b['state']==state
    def same_value(a,b):return a['value'] is not None and b['value'] is not None and Decimal(a['value'])==Decimal(b['value'])
    def changed(a,b,state):return same(a,b,state) and not same_value(a,b)
    strata=[('unsupported',lambda a,b:same(a,b,'unsupported')),
            ('changed_derived',lambda a,b:changed(a,b,'resolved_derived')),
            ('changed_reported',lambda a,b:changed(a,b,'resolved_reported')),
            ('lost_ocf',lambda a,b:a['state']=='resolved_derived' and b['state']=='conflicted' and a['metric']=='operating_cash_flow'),
            ('lost_other',lambda a,b:a['state']=='resolved_derived' and b['state']=='conflicted' and a['metric']!='operating_cash_flow')]
    for state in ['ambiguous_period','insufficient_evidence','unavailable','conflicted']:
        strata.append((state,lambda a,b,state=state:same(a,b,state)))
    for metric in ['assets','cash_and_cash_equivalents','liabilities','net_income','operating_cash_flow','revenue']:
        strata.append(('reported_'+metric,lambda a,b,m=metric:a['metric']==m and same(a,b,'resolved_reported') and same_value(a,b)))
    for metric,period in [('operating_cash_flow','Q2'),('operating_cash_flow','Q3'),('operating_cash_flow','Q4'),('net_income','Q4'),('revenue','Q4')]:
        strata.append(('derived_'+metric+'_'+period,lambda a,b,m=metric,p=period:a['metric']==m and a['period']==p and same(a,b,'resolved_derived') and same_value(a,b)))
    chosen=[];used=set();combos=Counter();allocation=[];prov_cache={}
    for slot,(label,predicate) in enumerate(strata,1):
        candidates=[k for k in f if f[k]['cik'] not in EXCLUDE and predicate(f[k],l[k])]
        available=[k for k in candidates if k[0] not in used]
        assert available,('No distinct issuer for proposed slot',label)
        rank=lambda k:(combos[k[2],k[4]],sha256((SEED+'|'+label+'|'+json.dumps(k,separators=(',',':'))).encode()).hexdigest())
        k=min(available,key=rank);a,b=f[k],l[k];used.add(k[0]);combos[k[2],k[4]]+=1
        item={'sample_id':f'R{slot:02}','stratum':label,**dict(zip(KEY,k)),
              'ticker_current_annotation':a['ticker'],'first_state':a['state'],'latest_state':b['state'],
              'first_value':a['value'],'latest_value':b['value'],'unit':a['unit'],'review_status':'not reviewed'}
        for policy,r in [('first',a),('latest',b)]:
            cp,pointer,n=locations[r['row_id'],r['revision_policy']];base=Path(f'output/wp7/broad-shard-{n}')/r['cik']/r['revision_policy']
            provenance=base/'panel.parquet.provenance.json'
            if provenance not in prov_cache:prov_cache[provenance]=loads((ROOT/provenance).read_bytes())
            assert r['row_id'] in prov_cache[provenance],r['row_id']
            item.update({policy+'_row_id':r['row_id'],policy+'_receipt_id':r['receipt_id'],policy+'_checkpoint':cp,
                         policy+'_checkpoint_pointer':pointer,policy+'_receipt_path':str(base/'receipt.json'),
                         policy+'_provenance_path':str(provenance),policy+'_provenance_pointer':'/'+r['row_id']})
        chosen.append(item);allocation.append({'sample_id':item['sample_id'],'stratum':label,'eligible_pairs_excluding_featured':len(candidates),'eligible_after_distinct_issuer_rule':len(available)})
    assert len(chosen)==len(used)==20
    dest=ROOT/'paper/review-sample.csv'
    with dest.open('w',newline='') as stream:
        w=csv.DictWriter(stream,fieldnames=list(chosen[0]));w.writeheader();w.writerows(chosen)
    out={'status':'Proposed human review sample. Selection executed; source adjudication NOT performed.',
         'seed':SEED,'snapshot_id':report['snapshot_id'],'historical_software':report['software'],
         'excluded_featured_ciks':sorted(EXCLUDE),'match_key':list(KEY),'sampling_unit':'matched first/latest request pair, two archived rows',
         'selection':'Fixed rare-first stratum order, exclude featured issuers, require distinct issuer, prefer least-used fiscal-year/cutoff combination then minimum salted SHA-256 of canonical key; no probability-sampling claim.',
         'pairs':20,'rows':40,'issuers':20,'allocation':allocation,
         'fiscal_year_cutoff_counts':[{'fiscal_year':k[0],'as_of':k[1],'pairs':v} for k,v in sorted(combos.items())],
         'sources':sources,'selection_script':record(Path(__file__)), 'sample_csv':record(dest),
         'selected_evidence_files':[record(ROOT/p) for p in sorted(set(Path(r[k]) for r in chosen for k in ['first_receipt_path','latest_receipt_path','first_provenance_path','latest_provenance_path']))],
         'inference_limit':'Purposive diagnostic coverage only; no population accuracy, error rate or statistical confidence interval.'}
    (ROOT/'paper/review-sample-manifest.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'pairs':20,'rows':40,'issuers':20,'fiscal_year_cutoff_counts':out['fiscal_year_cutoff_counts'],'proposed_slots':[{k:r[k] for k in ['sample_id','stratum','cik','ticker_current_annotation','fiscal_year','period']} for r in chosen]},indent=2))


if __name__=='__main__':main()
