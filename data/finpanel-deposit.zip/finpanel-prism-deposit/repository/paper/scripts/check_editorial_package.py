"""Read-only consistency check of the editorial package; writes a fresh check record."""
import argparse
from collections import Counter
import csv
from decimal import Decimal
from hashlib import sha256
import json
from pathlib import Path
import re
import subprocess
ROOT=Path(__file__).resolve().parents[2]


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',required=True,type=Path);a=p.parse_args()
    if a.output.exists():raise SystemExit('Refusing to overwrite an existing review record.')
    def read(path):return json.loads((ROOT/path).read_text())
    def hashed(path):return sha256((ROOT/path).read_bytes()).hexdigest()
    def csvrows(path):
        with (ROOT/path).open(newline='') as f:return list(csv.DictReader(f))
    old=read('paper/reviewer-runs/reviewer-manifest-before-editorial.json')
    protected=[r for r in old['files'] if not r['path'].startswith('paper/') or any(r['path'].startswith('paper/'+prefix) for prefix in ['audit/','reviewer-runs/','figures/','figure-data/','scripts/'])]
    for r in protected:assert hashed(r['path'])==r['sha256'],('Protected evidence changed',r['path'])
    figures=read('paper/figure-manifest.json')
    for r in figures['sources']+figures['scripts']+[r for fig in figures['figures'] for r in fig['files']+fig['data']]:assert hashed(r['path'])==r['sha256'],r['path']
    checkpoints={f'output/wp7/broad-shard-{n}/checkpoint.json':read(f'output/wp7/broad-shard-{n}/checkpoint.json') for n in range(2)}
    rows=[r for d in checkpoints.values() for r in d['state']['cells']];assert len(rows)==24000
    state=Counter(r['state'] for r in rows)
    for r in csvrows('paper/figure-data/figure-1-states.csv'):
        n=int(r['cells']);assert n==state[r['state']] and int(r['denominator'])==24000
        assert abs(Decimal(r['percent'])-Decimal(n)*100/24000)<Decimal('0.0000000001')
    for r in csvrows('paper/figure-data/figure-2-metrics.csv'):
        subset=[v for v in rows if v['metric']==r['metric']];assert len(subset)==4000
        c=Counter(v['state'] for v in subset)
        assert int(r['reported'])==c['resolved_reported'] and int(r['derived'])==c['resolved_derived']
        assert int(r['resolved'])==int(r['reported'])+int(r['derived'])==4000-int(r['unresolved'])
        assert abs(Decimal(r['coverage_percent'])-Decimal(r['resolved'])*100/4000)<Decimal('0.0000000001')
    for r in csvrows('paper/figure-data/figure-4-metric-period.csv'):
        c=Counter(v['state'] for v in rows if v['metric']==r['metric'] and v['period']==r['period']);assert sum(c.values())==800
        assert int(r['reported'])==c['resolved_reported'] and int(r['derived'])==c['resolved_derived']
        assert int(r['resolved'])==c['resolved_reported']+c['resolved_derived']
        assert abs(Decimal(r['coverage_percent'])-Decimal(r['resolved'])*100/800)<Decimal('0.0000000001')
    key=lambda r:tuple(r[k] for k in ['cik','metric','fiscal_year','period','as_of'])
    first={key(r):r for r in rows if r['revision_policy']=='first_reported'};latest={key(r):r for r in rows if r['revision_policy']=='latest_available'}
    assert len(first)==len(latest)==12000 and first.keys()==latest.keys()
    transitions=Counter((first[k]['state'],latest[k]['state']) for k in first)
    for r in csvrows('paper/figure-data/figure-3-transitions.csv'):assert transitions[r['first_state'],r['latest_state']]==int(r['pairs'])
    jointly=[k for k in first if first[k]['value'] is not None and latest[k]['value'] is not None]
    different=sum(Decimal(first[k]['value'])!=Decimal(latest[k]['value']) for k in jointly)
    assert len(jointly)==8339 and different==146
    assert sum(n for (f,l),n in transitions.items() if f!=l)==28==transitions['resolved_derived','conflicted']
    report=read('docs/release-scale-validation.json');assert report['software']['finpanel']=='0.1.0a1'
    assert report['source_verification_states']=={'instance_unavailable':187,'verified_multiple_equivalent':7,'verified_unique':6}
    assert state['resolved_reported']==14136 and state['resolved_derived']==2570
    assert (-1053836000)-(-772553000)==-281283000
    assert (-1054579000)-(-879286000)==-175293000
    assert (-530993000)-(-545906000)==14913000
    assert (-533299000)-(-542938000)==9639000
    text=(ROOT/'paper/manuscript.md').read_text();body=text.split('## Abstract',1)[1].split('## References',1)[0]
    words=len(body.split());assert 5000<=words<=7000
    bib=(ROOT/'paper/references.bib').read_text();keys=re.findall(r'@\w+\{([^,]+),',bib);assert len(keys)==len(set(keys)) and bib.count('{')==bib.count('}')
    cited=set(re.findall(r'@([\w-]+)',text));assert cited<=set(keys),cited-set(keys)
    matrix=(ROOT/'paper/evidence-matrix.md').read_text();ids=set(re.findall(r'^\| ([ACNKEI]\d{2})\b',matrix,re.M))
    used=set(re.findall(r'\b[ACNKEI]\d{2}\b',body))
    for letter,start,end in re.findall(r'\b([ACNKEI])(\d{2})–(?:[ACNKEI])?(\d{2})\b',body):used.update(f'{letter}{n:02}' for n in range(int(start),int(end)+1))
    assert used<=ids,used-ids
    imgs=re.findall(r'!\[[^\]]*\]\(([^)]+)\)',text);assert len(imgs)==4
    for path in imgs:assert (ROOT/'paper'/path).is_file()
    assert re.findall(r'^\*\*Figure (\d)\.',text,re.M)==['1','2','3','4']
    assert set(re.findall(r'\bFigure (\d+)\b',text))<=set('1234')
    assert not re.search(r'\[(?:name|role|venue|email|funding|editor)[^\]]*\]|\bTODO\b|\bTBD\b',text,re.I)
    assert '**Finley Dou**' in text and 'Shanghai High School International Division' in text
    assert 'Source:' not in text
    for name in ['reviewer-guide.md','review-response-template.md','author-guide.md','open-items.md']:assert (ROOT/'paper'/name).is_file()
    sample=csvrows('paper/review-sample.csv');sm=read('paper/review-sample-manifest.json')
    assert len(sample)==20 and len({r['cik'] for r in sample})==20 and len({r['sample_id'] for r in sample})==20
    assert {r['review_status'] for r in sample}=={'not reviewed'}
    assert not ({r['cik'] for r in sample}&set(sm['excluded_featured_ciks']))
    for r in sm['sources']+sm['selected_evidence_files']+[sm['sample_csv'],sm['selection_script']]:assert hashed(r['path'])==r['sha256'],r['path']
    pairmix=Counter()
    for r in sample:
        pairmix[r['fiscal_year'],r['as_of']]+=1
        for policy,expected_policy in [('first','first_reported'),('latest','latest_available')]:
            index=int(r[policy+'_checkpoint_pointer'].rsplit('/',1)[1]);v=checkpoints[r[policy+'_checkpoint']]['state']['cells'][index]
            assert v['row_id']==r[policy+'_row_id'] and v['receipt_id']==r[policy+'_receipt_id']
            assert v['revision_policy']==expected_policy and v['state']==r[policy+'_state']
            for field in ['cik','metric','fiscal_year','period','as_of']:assert str(v[field])==r[field]
    assert sorted(pairmix.values())==[5,5,5,5]
    original=read('paper/audit/verification.json');changed=[path for path,h in original['tracked_file_hashes'].items() if hashed(path)!=h];assert not changed
    commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert commit=='28dcecce208a578b4a7b507bbf6d93018b4ab1d6'
    output={'date':'2026-10-10','status':'Ready for author review and scoped external editorial assessment; independent human validation not performed; publication readiness not certified.',
            'commit':commit,'manuscript_word_count':words,'word_count_scope':'Whitespace tokens, Abstract through Conclusion inclusive; front matter and references excluded',
            'unique_bibliography_entries':len(keys),'citation_keys_resolve':True,'expanded_claim_id_ranges_resolve':True,
            'figures_referenced':4,'figure_source_data_and_image_hashes_match':True,'rows_recounted':24000,'matched_policy_pairs':12000,'jointly_resolved_pairs':8339,'different_numerical_values':146,'derived_to_conflicted_pairs':28,
            'author_information_matches_supplied_byline':True,'manuscript_disclosure_placeholders_found':False,
            'disclosure_status':'Conditional alternatives remain in disclosure-options.md; author/editor facts and final policy pending.',
            'proposed_sample':{'pairs':20,'rows':40,'distinct_issuers':20,'per_year_cutoff_combination':5,'human_verdicts_completed':0,'exact_checkpoint_and_evidence_locators_checked':True},
            'preexisting_protected_manifest_files_unchanged':len(protected),'tracked_source_and_evidence_files_changed':changed,
            'this_pass':'Read-only editorial checks and proposed sample selection only. No new financial experiment, test-suite run, replay, acquisition, human review or publication.',
            'paper_markdown_hashes':{str(path.relative_to(ROOT)):hashed(path.relative_to(ROOT)) for path in sorted((ROOT/'paper').glob('*.md'))}}
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({k:v for k,v in output.items() if k!='paper_markdown_hashes'},indent=2))


if __name__=='__main__':main()
