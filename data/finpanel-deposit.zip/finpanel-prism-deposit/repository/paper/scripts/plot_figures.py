"""Deterministic publication figures from exact extracted CSVs (no inferred cells)."""
import csv
from hashlib import sha256
import json
from pathlib import Path
import platform
import importlib.metadata

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch, Rectangle
from matplotlib.ticker import FuncFormatter
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
DATA=ROOT/'paper/figure-data';OUT=ROOT/'paper/figures'
NAVY='#0072B2';GREEN='#009E73';ORANGE='#D55E00';GREY='#D9DFE4';INK='#202D39'
METRICS=['assets','cash_and_cash_equivalents','liabilities','net_income','operating_cash_flow','revenue']
METRIC_LABELS=['Assets','Cash and cash\nequivalents','Liabilities','Net income','Operating cash flow','Revenue']
STATES=['resolved_reported','resolved_derived','unavailable','ambiguous_period','insufficient_evidence','conflicted','unsupported']
LABELS=['Reported','Derived','Unavailable','Ambiguous period','Insufficient evidence','Conflicted','Unsupported']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':13,'axes.labelsize':10,
                     'text.color':INK,'axes.labelcolor':INK,'xtick.color':INK,'ytick.color':INK,
                     'svg.hashsalt':'finpanel-paper-20261010','axes.spines.top':False,'axes.spines.right':False,
                     'axes.spines.left':False,'axes.edgecolor':'#88949E','savefig.facecolor':'white'})


def read(name):
    with (DATA/name).open(newline='') as f:return list(csv.DictReader(f))


def footer(fig, line):
    fig.text(.02,.056,line,fontsize=8,color='#46525D',va='bottom')
    fig.text(.02,.014,'Oct 2026 retrieval vintage • 0.1.0a1 archive • snapshot 7ee0bbe49b26… • scalar coverage, not accuracy',fontsize=7.3,va='bottom')


def save(fig, name):
    fig.savefig(OUT/(name+'.svg'),metadata={'Date':None,'Creator':'FinPanel paper plot_figures.py'})
    fig.savefig(OUT/(name+'.png'),dpi=400,metadata={'Software':'FinPanel paper plot_figures.py'})
    plt.close(fig)


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    a=read('figure-1-states.csv');labels=LABELS+['Verification failed'];counts=[int(r['cells']) for r in a]
    fig,ax=plt.subplots(figsize=(7.2,4.8));fig.subplots_adjust(left=.26,right=.97,top=.80,bottom=.19)
    colors=[NAVY,GREEN]+[GREY]*6
    bars=ax.barh(range(8),counts,color=colors,edgecolor='#74818D',linewidth=.5,height=.66)
    bars[1].set_hatch('////');ax.set_yticks(range(8),labels);ax.invert_yaxis();ax.set_xlim(0,17800)
    for i,n in enumerate(counts):ax.text(n+220,i,f'{n:,}  ({n/24000:.2%})',va='center',fontsize=9)
    ax.set_xticks([0,5000,10000,15000]);ax.xaxis.set_major_formatter(FuncFormatter(lambda x,p:f'{x:,.0f}'))
    ax.set_xlabel('Requested cells');ax.xaxis.grid(True,alpha=.18);ax.set_axisbelow(True)
    fig.text(.02,.94,'1  |  Every request retains an explicit result state',fontsize=13,weight='bold')
    fig.text(.02,.875,'16,706 resolved / 24,000 requests (69.61%); 7,294 unresolved',fontsize=10)
    footer(fig,'100 purposive issuers • FY2023–24 • two cutoffs × first-reported and latest-available')
    save(fig,'figure-1-result-states')

    b=read('figure-2-metrics.csv');fig,ax=plt.subplots(figsize=(7.2,4.8));fig.subplots_adjust(left=.27,right=.97,top=.76,bottom=.23)
    reported=np.array([int(r['reported']) for r in b]);derived=np.array([int(r['derived']) for r in b]);unresolved=4000-reported-derived
    ax.barh(range(6),reported,color=NAVY,height=.62,label='Reported')
    ax.barh(range(6),derived,left=reported,color=GREEN,edgecolor='white',hatch='////',height=.62,label='Derived')
    ax.barh(range(6),unresolved,left=reported+derived,color=GREY,height=.62,label='Unresolved')
    for i,(r,d) in enumerate(zip(reported,derived)):
        ax.text(r/2,i,f'{r:,}',color='white',ha='center',va='center',fontsize=9,weight='bold')
        if d:ax.text(r+d/2,i,f'{d:,}',color='white',ha='center',va='center',fontsize=9,weight='bold',bbox={'facecolor':GREEN,'edgecolor':'none','pad':1})
        ax.text(4060,i,f'{(r+d)/4000:.2%}',va='center',fontsize=9)
    ax.set_yticks(range(6),METRIC_LABELS);ax.invert_yaxis();ax.set_xlim(0,4800);ax.set_xticks([0,1000,2000,3000,4000]);ax.set_xlabel('Requests per metric (denominator = 4,000)')
    ax.xaxis.grid(True,alpha=.15);ax.set_axisbelow(True);ax.legend(loc='upper left',bbox_to_anchor=(-.36,1.18),ncol=3,frameon=False,fontsize=9)
    fig.text(.02,.94,'2  |  Reported and derived contributions differ by metric',fontsize=12.5,weight='bold')
    fig.text(.02,.875,'Segment labels are cell counts; right labels are total scalar coverage',fontsize=9.5)
    footer(fig,'100 purposive issuers • five periods • FY2023–24 • two cutoffs × two revision policies')
    save(fig,'figure-2-metric-coverage')

    c=read('figure-3-transitions.csv');lookup={(r['first_state'],r['latest_state']):int(r['pairs']) for r in c}
    fig,ax=plt.subplots(figsize=(7.2,6.2));fig.subplots_adjust(left=.24,right=.95,top=.79,bottom=.32)
    for i,a in enumerate(STATES):
        for j,b in enumerate(STATES):
            n=lookup[a,b];color='#DDECF5' if i==j else '#F9D9CA' if n else '#FFFFFF'
            ax.add_patch(Rectangle((j-.5,i-.5),1,1,facecolor=color,edgecolor='#BBC6CE',linewidth=.6))
            ax.text(j,i,f'{n:,}' if n else '—',ha='center',va='center',fontsize=9.5,color=INK if n else '#8A949C',weight='bold' if n else 'normal')
    ax.set_xlim(-.5,6.5);ax.set_ylim(6.5,-.5);ax.set_yticks(range(7),['Reported','Derived','Unavailable','Ambiguous\nperiod','Insufficient\nevidence','Conflicted','Unsupported'])
    ax.set_xticks(range(7),['Reported','Derived','Unavailable','Ambiguous','Insufficient','Conflicted','Unsupported'],rotation=40,ha='right',rotation_mode='anchor',fontsize=9)
    ax.tick_params(length=0);ax.set_ylabel('First-reported state');ax.set_xlabel('Latest-available state',labelpad=8)
    for sp in ax.spines.values():sp.set_visible(False)
    fig.text(.02,.945,'3  |  Matching policies reveals 28 lost scalar results',fontsize=13,weight='bold')
    fig.text(.02,.889,'12,000 matched requests; 28 move from derived to conflicted; none gain a scalar',fontsize=9.2)
    fig.text(.02,.845,'Among 8,339 pairs resolved under both policies, 146 change numerical value (1.75%)',fontsize=9.2)
    fig.legend(handles=[Patch(facecolor='#DDECF5',edgecolor='#BBC6CE',label='Same state'),Patch(facecolor='#F9D9CA',edgecolor='#BBC6CE',label='Changed state')],loc='lower left',bbox_to_anchor=(.02,.135),ncol=2,frameon=False,fontsize=9)
    footer(fig,'100 purposive issuers • match: CIK, metric, FY, period, cutoff • dash = zero pairs')
    save(fig,'figure-3-policy-transitions')

    d=read('figure-4-metric-period.csv');periods=['FY','Q1','Q2','Q3','Q4'];look={(r['metric'],r['period']):int(r['resolved']) for r in d}
    values=np.array([[look[m,p]/8 for p in periods] for m in METRICS])
    fig,ax=plt.subplots(figsize=(7.2,5.1));fig.subplots_adjust(left=.28,right=.91,top=.80,bottom=.19)
    im=ax.imshow(values,cmap='cividis',vmin=0,vmax=100,aspect='auto')
    for i,m in enumerate(METRICS):
        for j,p in enumerate(periods):
            n=look[m,p];ax.text(j,i,f'{n/800:.2%}\n{n:,}/800',ha='center',va='center',fontsize=9,color='white' if values[i,j]<52 else '#111111')
    ax.set_xticks(range(5),periods);ax.set_yticks(range(6),METRIC_LABELS);ax.tick_params(length=0)
    ax.set_xlabel('Requested fiscal period');ax.set_xticks(np.arange(-.5,5,1),minor=True);ax.set_yticks(np.arange(-.5,6,1),minor=True);ax.grid(which='minor',color='white',linewidth=1);ax.tick_params(which='minor',length=0)
    cb=fig.colorbar(im,ax=ax,fraction=.045,pad=.04);cb.set_label('Scalar coverage (%)',fontsize=9);cb.ax.tick_params(labelsize=8)
    fig.text(.02,.94,'4  |  Availability varies jointly by metric and period',fontsize=13,weight='bold')
    fig.text(.02,.875,'Each tile has 800 requests; exact counts accompany percentages',fontsize=10)
    footer(fig,'100 purposive issuers • FY2023–24 • two cutoffs × first-reported and latest-available')
    save(fig,'figure-4-metric-period')

    extraction=json.loads((DATA/'extraction-manifest.json').read_text())
    names=['figure-1-result-states','figure-2-metric-coverage','figure-3-policy-transitions','figure-4-metric-period']
    csvs=[['figure-1-states.csv'],['figure-2-metrics.csv'],['figure-3-transitions.csv','figure-3-summary.csv','figure-3-changed-pairs.csv'],['figure-4-metric-period.csv']]
    def record(p):return {'path':str(p.relative_to(ROOT)),'sha256':sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
    manifest={'format':'finpanel-paper-figures-v1','date':'2026-10-10','historical_software':extraction['historical_software'],
              'snapshot_id':extraction['snapshot_id'],'snapshot_retrieval_window_utc':extraction['snapshot_retrieval_window_utc'],
              'population':extraction['population'],'cutoffs':extraction['cutoffs'],'policies':extraction['policies'],
              'sources':extraction['sources'],'scripts':[record(ROOT/'paper/scripts'/n) for n in ['extract_figure_data.py','plot_figures.py']],
              'plot_environment':{'python':platform.python_version(),'matplotlib':matplotlib.__version__,'numpy':np.__version__},
              'png_dpi':400,'figures':[],'statistical_intervals':'None: purposive dependent request grid; no market inference.'}
    for n,(name,data) in enumerate(zip(names,csvs),1):
        manifest['figures'].append({'number':n,'name':name,'files':[record(OUT/(name+'.'+ext)) for ext in ['svg','png']],
                                    'data':[record(DATA/x) for x in data],'source_artifact_paths':[s['path'] for s in extraction['sources']],
                                    'denominator':12000 if n==3 else 800 if n==4 else 4000 if n==2 else 24000,
                                    'unit':'matched requests' if n==3 else 'requested cells'})
    (ROOT/'paper/figure-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('Rendered four SVG/400-DPI PNG figures and figure-manifest.json')


if __name__=='__main__':main()
