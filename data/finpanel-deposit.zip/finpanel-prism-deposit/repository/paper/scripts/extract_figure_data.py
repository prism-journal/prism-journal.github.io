"""Recount authentic archived rows and export exact plotted data and provenance.

Requires the current FinPanel environment; never calls the network or writes
historical files. Generated figure-data files are reproducible derived outputs.
"""
from collections import Counter
import csv
from decimal import Decimal
from hashlib import sha256
import json
from pathlib import Path

from finpanel.serialization import loads
from finpanel.snapshots.store import digest
from finpanel.snapshots.pipeline import software_identity

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'paper/figure-data'
STATES=['resolved_reported','resolved_derived','unavailable','ambiguous_period',
        'insufficient_evidence','conflicted','unsupported','source_verification_failed']
METRICS=['assets','cash_and_cash_equivalents','liabilities','net_income','operating_cash_flow','revenue']
PERIODS=['FY','Q1','Q2','Q3','Q4']


def write(name, rows):
    with (OUT/name).open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def pct(n,d):
    return format(Decimal(n)*100/Decimal(d),'.10f')


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    sources=[]
    def read(path):
        raw=(ROOT/path).read_bytes()
        sources.append({'path':str(path),'sha256':sha256(raw).hexdigest(),'bytes':len(raw)})
        return loads(raw)
    report=read(Path('docs/release-scale-validation.json'));rows=[]
    snapshot=read(Path('output/wp7/broad-corpus/evidence/snapshots')/(report['snapshot_id']+'.json'))
    retrieved=sorted(a['retrieved_at'] for a in snapshot['artifacts'])
    for n in range(2):
        checkpoint=read(Path(f'output/wp7/broad-shard-{n}/checkpoint.json'))
        receipt=read(Path(f'output/wp7/broad-shard-{n}/receipt.json'))
        local_report=read(Path(f'output/wp7/broad-shard-{n}/report.json'))
        assert digest(local_report)==receipt['report_hash']==report['shards'][n]['report_hash']
        assert digest(checkpoint['state']['cells'])==receipt['semantic_dataset_hash']
        rows.extend(checkpoint['state']['cells'])
    rows.sort(key=lambda r:tuple(r[k] for k in ('cik','revision_policy','as_of','fiscal_year','period','metric')))
    assert len(rows)==24000 and digest(rows)==report['semantic_dataset_hash']
    counts=Counter(r['state'] for r in rows)
    assert all(counts[s]==report['states'].get(s,0) for s in STATES)
    write('figure-1-states.csv',[{'state':s,'cells':counts[s],'denominator':24000,'percent':pct(counts[s],24000)} for s in STATES])
    metric_data=[];heat=[]
    for metric in METRICS:
        mr=[r for r in rows if r['metric']==metric];c=Counter(r['state'] for r in mr)
        assert len(mr)==4000
        resolved=c['resolved_reported']+c['resolved_derived']
        assert resolved==report['coverage_by']['metric'][metric]['resolved']
        metric_data.append({'metric':metric,'reported':c['resolved_reported'],'derived':c['resolved_derived'],
                            'unresolved':4000-resolved,'resolved':resolved,'denominator':4000,'coverage_percent':pct(resolved,4000)})
        for period in PERIODS:
            pr=[r for r in mr if r['period']==period];pc=Counter(r['state'] for r in pr)
            assert len(pr)==800
            resolved=pc['resolved_reported']+pc['resolved_derived']
            heat.append({'metric':metric,'period':period,'reported':pc['resolved_reported'],'derived':pc['resolved_derived'],
                         'resolved':resolved,'unresolved':800-resolved,'denominator':800,'coverage_percent':pct(resolved,800)})
    write('figure-2-metrics.csv',metric_data);write('figure-4-metric-period.csv',heat)
    key_fields=['cik','metric','fiscal_year','period','as_of']
    key=lambda r:tuple(r[k] for k in key_fields)
    groups={p:{key(r):r for r in rows if r['revision_policy']==p} for p in ['first_reported','latest_available']}
    first,latest=groups.values();assert len(first)==len(latest)==12000 and set(first)==set(latest)
    transitions=Counter();changed=[];both=changed_values=changed_states=lost=gained=0
    for k in sorted(first):
        a,b=first[k],latest[k];transitions[a['state'],b['state']]+=1
        ar=a['state'].startswith('resolved_');br=b['state'].startswith('resolved_')
        value_changed=False
        if ar and br:
            both+=1;assert a['unit']==b['unit']
            value_changed=Decimal(a['value'])!=Decimal(b['value'])
            changed_values+=value_changed
        state_changed=a['state']!=b['state'];changed_states+=state_changed
        lost+=ar and not br;gained+=br and not ar
        if state_changed or value_changed:
            changed.append({**dict(zip(key_fields,k)),'first_state':a['state'],'latest_state':b['state'],
                            'first_value':a['value'],'latest_value':b['value'],'unit':a['unit'],
                            'value_changed_when_both_resolved':value_changed,
                            'first_receipt_id':a['receipt_id'],'latest_receipt_id':b['receipt_id']})
    write('figure-3-transitions.csv',[{'first_state':a,'latest_state':b,'pairs':transitions[a,b],
                                     'denominator':12000,'percent_of_all_pairs':pct(transitions[a,b],12000)}
                                    for a in STATES for b in STATES])
    write('figure-3-changed-pairs.csv',changed)
    summary=[{'measure':k,'count':v,'denominator':d,'percent':pct(v,d)} for k,v,d in [
        ('same_state',12000-changed_states,12000),('changed_state',changed_states,12000),
        ('lost_scalar',lost,12000),('gained_scalar',gained,12000),('both_resolved',both,12000),
        ('changed_value_among_both_resolved',changed_values,both),
        ('unchanged_value_among_both_resolved',both-changed_values,both)]]
    write('figure-3-summary.csv',summary)
    assert sum(transitions.values())==12000
    out={'format':'finpanel-paper-figure-extraction-v1','snapshot_id':report['snapshot_id'],
         'historical_software':report['software'],'extraction_software':software_identity(),
         'sources':sources,'rows':24000,'matched_pairs':12000,'match_key':key_fields,
         'population':'100 purposively selected operating companies; FY2023/FY2024; repeated cutoff and policy variants; no independence or market-accuracy claim',
         'cutoffs':report['query']['as_of'],'policies':report['query']['revision_policies'],
         'snapshot_retrieval_window_utc':[retrieved[0],retrieved[-1]],
         'summary':{r['measure']:r for r in summary}}
    (OUT/'extraction-manifest.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out['summary'],indent=2))


if __name__=='__main__':main()
