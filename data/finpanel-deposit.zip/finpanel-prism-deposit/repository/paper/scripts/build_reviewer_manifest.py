"""Inventory accessible reviewer inputs and outputs, checking archived hashes."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[2]
DEST=ROOT/'paper/reviewer-manifest.json'


def main():
    records={}
    def add(path, role, expected=None):
        p=ROOT/path; raw=p.read_bytes();actual=sha256(raw).hexdigest()
        if expected is not None: assert actual==expected,(str(path),actual,expected)
        key=str(p.relative_to(ROOT))
        records[key]={'path':key,'sha256':actual,'bytes':len(raw),'role':role}
    report=json.loads((ROOT/'docs/release-scale-validation.json').read_text())
    snap=Path('output/wp7/broad-corpus/evidence/snapshots')/(report['snapshot_id']+'.json')
    add(snap,'historical snapshot manifest')
    snapshot=json.loads((ROOT/snap).read_text())
    for a in snapshot['artifacts']:
        path=Path('output/wp7/broad-corpus/evidence')/a['locator']
        add(path,'historical raw evidence object',a['sha256'])
        assert (ROOT/path).stat().st_size==a['size']
    for n in range(2):
        base=Path(f'output/wp7/broad-shard-{n}')
        for name in ['checkpoint.json','receipt.json','report.json']:add(base/name,'historical shard control')
        checkpoint=json.loads((ROOT/base/'checkpoint.json').read_text())
        for cik,outputs in checkpoint['completed'].items():
            for name,expected in outputs.items():add(base/cik/name,'historical completed output',expected)
    recovered=json.loads((ROOT/'paper/reviewer-runs/historical-recovery.json').read_text())
    for w in recovered['wheel_scan']:
        if w['path'] in recovered['matching_wheels']:add(Path(w['path']),'matching historical package wheel',w['sha256'])
    for w in recovered['wheelhouse']:add(Path(w['path']),'local historical dependency wheel',w['sha256'])
    for name in ['summary.json','receipt.json','panel.csv']:
        add(Path('output/paper-review-20261010/public-example')/name,'executed current public example')
    for path in ['docs/release-scale-validation.json','docs/release-golden-inventory.json','docs/release-temporal-audit.json','docs/release-resume-verification.json','src/finpanel/validation/release-universe.json','tests/fixtures/release/manifest.json','tests/fixtures/broad/manifest.json']:
        add(Path(path),'repository evidence')
    for p in sorted((ROOT/'paper').rglob('*')):
        if p.is_file() and p!=DEST and '__pycache__' not in p.parts:add(p.relative_to(ROOT),'paper supplement')
    out={'format':'finpanel-reviewer-manifest-v1','date':'2026-10-10','current_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
         'snapshot_id':report['snapshot_id'],'historical_software':report['software'],
         'scope':'Local inventory, not a published archive. Exact snapshot objects and checkpoint-listed outputs checked. Current source/fixtures identified by Git commit and paper audit.',
         'files':list(records.values())}
    DEST.write_text(json.dumps(out,indent=2)+'\n')
    print(f'Wrote {len(records)} file records to {DEST.relative_to(ROOT)}')


if __name__=='__main__':main()
