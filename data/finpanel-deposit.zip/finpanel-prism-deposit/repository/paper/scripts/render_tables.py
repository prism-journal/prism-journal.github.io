"""Render the exact numerical companion tables from figure CSVs; stdlib only."""
import csv
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
DATA=ROOT/'paper/figure-data'
SOURCES=['figure-1-states.csv','figure-2-metrics.csv','figure-3-summary.csv','figure-3-transitions.csv','figure-4-metric-period.csv']
parts=['# Exact numerical companions to Figures 1–4','Counts are exact; CSV percentage columns retain ten decimal places. These are descriptive request counts, not accuracy estimates. Population definitions and verification records accompany the paper supplement. The manuscript uses figures instead of duplicating these tables.']
for name in SOURCES:
    with (DATA/name).open(newline='') as f:
        reader=csv.DictReader(f);rows=list(reader);cols=reader.fieldnames
    table=['| '+' | '.join(cols)+' |','| '+' | '.join(['---']*len(cols))+' |']
    table.extend('| '+' | '.join(row[c] for c in cols)+' |' for row in rows)
    parts.extend(['## '+name,'\n'.join(table)])
(DATA/'tables.md').write_text('\n\n'.join(parts)+'\n')
print('Rendered companion tables from five CSV files.')
