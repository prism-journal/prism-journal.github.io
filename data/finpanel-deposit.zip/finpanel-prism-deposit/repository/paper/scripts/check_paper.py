"""Verify paper links, recorded counts, preserved files and deterministic renders.

Runs current-environment extraction/table scripts and a supplied plot interpreter.
Only derived paper chart artifacts are replaced; result destination must be fresh.
"""
import argparse
from collections import Counter
import csv
from decimal import Decimal
from hashlib import sha256
import json
from pathlib import Path
import re
import struct
import subprocess
import sys
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[2]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plot-python',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    a=parser.parse_args()
    if a.output.exists():raise SystemExit('Choose a new output record.')
    def hashfile(p):return sha256(p.read_bytes()).hexdigest()
    def readcsv(name):
        with (ROOT/'paper/figure-data'/name).open(newline='') as f:return list(csv.DictReader(f))
    # Compare before/after hashes, not just an asserted repeatable setting.
    chartpaths=sorted(list((ROOT/'paper/figures').glob('*'))+list((ROOT/'paper/figure-data').glob('*'))+[ROOT/'paper/figure-manifest.json'])
    before={str(p.relative_to(ROOT)):hashfile(p) for p in chartpaths}
    for cmd in [[sys.executable,'paper/scripts/extract_figure_data.py'],[sys.executable,'paper/scripts/render_tables.py'],[str(a.plot_python.absolute()),'paper/scripts/plot_figures.py']]:
        subprocess.run(cmd,cwd=ROOT,check=True,stdout=subprocess.DEVNULL)
    changed=[p for p,h in before.items() if hashfile(ROOT/p)!=h]
    assert not changed,changed
    figures=json.loads((ROOT/'paper/figure-manifest.json').read_text())
    for rec in figures['sources']+figures['scripts']+[r for f in figures['figures'] for r in f['files']+f['data']]:
        assert hashfile(ROOT/rec['path'])==rec['sha256'],rec['path']
    image_checks=[]
    for fig in figures['figures']:
        png=ROOT/fig['files'][1]['path'];raw=png.read_bytes();assert raw[:8]==b'\x89PNG\r\n\x1a\n'
        width,height=struct.unpack('>II',raw[16:24]);assert width==2880 and height>=1920
        svg=ET.parse(ROOT/fig['files'][0]['path']).getroot();assert svg.attrib['viewBox']
        image_checks.append({'number':fig['number'],'png_pixels':[width,height],'svg_viewBox':svg.attrib['viewBox']})
    rows=[]
    for n in range(2):rows+=json.loads((ROOT/f'output/wp7/broad-shard-{n}/checkpoint.json').read_text(),parse_float=Decimal)['state']['cells']
    assert len(rows)==24000
    counter=Counter(r['state'] for r in rows)
    for r in readcsv('figure-1-states.csv'):assert counter[r['state']]==int(r['cells'])
    for r in readcsv('figure-2-metrics.csv'):
        selected=[x for x in rows if x['metric']==r['metric']];assert len(selected)==4000
        for label,key in [('resolved_reported','reported'),('resolved_derived','derived')]:assert sum(x['state']==label for x in selected)==int(r[key])
    for r in readcsv('figure-4-metric-period.csv'):
        selected=[x for x in rows if x['metric']==r['metric'] and x['period']==r['period']];assert len(selected)==800
        assert sum(x['state'].startswith('resolved_') for x in selected)==int(r['resolved'])
    key=lambda r:tuple(r[x] for x in ['cik','metric','fiscal_year','period','as_of'])
    first={key(r):r for r in rows if r['revision_policy']=='first_reported'}
    latest={key(r):r for r in rows if r['revision_policy']=='latest_available'}
    assert len(first)==len(latest)==12000 and first.keys()==latest.keys()
    transitions=Counter((first[k]['state'],latest[k]['state']) for k in first)
    for r in readcsv('figure-3-transitions.csv'):assert transitions[r['first_state'],r['latest_state']]==int(r['pairs'])
    joint=[k for k in first if first[k]['value'] is not None and latest[k]['value'] is not None]
    numerical=sum(Decimal(first[k]['value'])!=Decimal(latest[k]['value']) for k in joint)
    assert len(joint)==8339 and numerical==146
    assert sum(v for (a1,b),v in transitions.items() if a1!=b)==28
    assert transitions['resolved_derived','conflicted']==28
    instant=[]
    for metric in ['assets','liabilities','cash_and_cash_equivalents']:
        pairs={}
        for r in rows:
            if r['metric']==metric and r['period'] in ['FY','Q4']:
                k=tuple(r[x] for x in ['cik','fiscal_year','as_of','revision_policy']);pairs.setdefault(k,{})[r['period']]=r
        assert len(pairs)==800
        for p in pairs.values():assert all(p['FY'][x]==p['Q4'][x] for x in ['period_end','state','value'])
        instant.append({'metric':metric,'identical_fy_q4_date_state_value_pairs':800})
    text=(ROOT/'paper/manuscript.md').read_text();body=text.split('## Abstract',1)[1].split('## References',1)[0]
    words=len(body.split());assert 5000<=words<=7000,words
    matrix=(ROOT/'paper/evidence-matrix.md').read_text();ids=set(re.findall(r'\| ([ACNKEI]\d{2})\b',matrix))
    used=set(re.findall(r'\b[ACNKEI]\d{2}\b',body));assert used<=ids,used-ids
    bib=(ROOT/'paper/references.bib').read_text();keys=set(re.findall(r'@\w+\{([^,]+),',bib));cited=set(re.findall(r'@([a-zA-Z][\w-]*)',text));assert cited<=keys,cited-keys
    assert bib.count('{')==bib.count('}')
    figures_used=re.findall(r'!\[[^\]]*\]\(([^)]+)\)',text);assert len(figures_used)==4
    for path in figures_used:assert (ROOT/'paper'/path).is_file(),path
    assert '**Finley Dou**' in text and 'Shanghai High School International Division' in text
    assert '**Table 1.' not in text and '**Table 2.' not in text and 'Source:' not in text
    questions=len(re.findall(r'^### \d+\.',(ROOT/'paper/oral-exam.md').read_text(),re.M));assert questions>=30
    original=json.loads((ROOT/'paper/audit/verification.json').read_text())
    changed_tracked=[p for p,h in original['tracked_file_hashes'].items() if hashfile(ROOT/p)!=h];assert not changed_tracked,changed_tracked
    out={'date':'2026-10-10','status':'ready for author review','manuscript_word_count':words,
         'word_count_method':'Whitespace-delimited Abstract through Conclusion, including headings/captions/citations; excluding front matter and References',
         'oral_exam_questions':questions,'bibliography_entries':len(keys),'all_manuscript_citations_and_claim_ids_resolve':True,
         'figure_manifest_hashes_match':True,'deterministic_regeneration_changed_files':changed,'image_checks':image_checks,
         'independently_recounted_rows':len(rows),'policy_pairs':len(first),'changed_state_pairs':28,'jointly_resolved':len(joint),'different_values':numerical,
         'instant_period_overlap_checked':instant,'tracked_files_changed':changed_tracked,
         'git_status':subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True).strip(),
         'executed':'Fresh archive audit, source/runtime recovery, one historical replay, six-cell current example, chart extraction/render/regeneration. No new full benchmark or external adjudication.',
         'paper_file_sha256':{str(p.relative_to(ROOT)):hashfile(p) for p in sorted((ROOT/'paper').glob('*.md'))}}
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ['paper_file_sha256','image_checks','instant_period_overlap_checked']},indent=2))


if __name__=='__main__':main()
