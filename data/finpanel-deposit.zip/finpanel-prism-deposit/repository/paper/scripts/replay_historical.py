"""Offline replay of archived panel receipts; default is one bounded smoke replay.

Use the recovered a1 interpreter. --all explicitly opts into 200 potentially
expensive panel replays; it does not acquire evidence or rerun validation invariants.
"""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import time

from finpanel.panel import PanelReceipt, reproduce
from finpanel.serialization import loads
from finpanel.snapshots import EvidenceStore
from finpanel.snapshots.pipeline import software_identity

ROOT = Path(__file__).resolve().parents[2]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--all',action='store_true')
    p.add_argument('--limit',type=int,default=1)
    p.add_argument('--store',type=Path,default=ROOT/'output/wp7/broad-corpus/evidence')
    p.add_argument('--archive-root',type=Path,default=ROOT/'output/wp7')
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    if a.output.exists():
        raise SystemExit('Refusing to overwrite a replay record; choose a fresh output.')
    if a.limit<1: raise SystemExit('limit must be positive')
    paths=sorted(a.archive_root.glob('broad-shard-*/*/*/receipt.json'))
    if len(paths)!=200: raise SystemExit(f'Expected 200 archived panel receipts, found {len(paths)}')
    paths=paths if a.all else paths[:a.limit]
    results=[];started=time.perf_counter()
    store=EvidenceStore(a.store)
    for path in paths:
        before=path.read_bytes(); receipt=PanelReceipt(**loads(before))
        assert receipt.semantic['software']==software_identity()
        result=reproduce(receipt,store=store)
        assert path.read_bytes()==before
        results.append({'receipt_path':str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path),
                        'receipt_file_sha256':sha256(before).hexdigest(),
                        'expected_receipt_id':receipt.receipt_id,'actual_receipt_id':result.receipt.receipt_id,
                        'rows':len(result.rows),'matched':True})
    out={'date':'2026-10-10','software':software_identity(),'replayed_panels':len(results),
         'rows':sum(r['rows'] for r in results),'scope':'all archived panel receipts' if a.all else 'bounded smoke replay',
         'elapsed_seconds':time.perf_counter()-started,'results':results,
         'not_executed':'No acquisition, source-verification rerun, mutation audit or full validation-invariant benchmark.'}
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='results'},indent=2))


if __name__=='__main__':main()
