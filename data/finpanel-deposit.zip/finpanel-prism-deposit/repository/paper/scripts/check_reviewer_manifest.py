"""Verify all locally accessible files in the saved reviewer manifest; no writes."""
from hashlib import sha256
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
data=json.loads((ROOT/'paper/reviewer-manifest.json').read_text())
for entry in data['files']:
    path=ROOT/entry['path']
    assert path.is_file(),f'Missing required file: {entry["path"]}'
    actual=sha256(path.read_bytes()).hexdigest()
    assert actual==entry['sha256'],f'Hash mismatch: {entry["path"]}'
    assert path.stat().st_size==entry['bytes'],entry['path']
print(f'Verified {len(data["files"])} files; no files modified.')
