"""Scan fingerprint-covered sources and optionally prepare an offline replay environment.

Never modifies Git, archived wheels, receipts, or source files.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
TARGET = 'c3756cfba783ccd3d11df39f3a8f24fdeb47cf6edf75876f3cc8369ec090e0ad'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(value):
    return sha((json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False)+'\n').encode())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--prepare-environment', type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit('Refusing to overwrite a recovery record; choose a fresh output.')
    report = json.loads((ROOT/'docs/release-scale-validation.json').read_text())
    commits = list(dict.fromkeys(git('rev-list','--all','--reflog').decode().splitlines()))
    blob_cache, scans = {}, []
    for commit in commits:
        source = {}
        for line in git('ls-tree','-r',commit,'src/finpanel').decode().splitlines():
            meta, path = line.split('\t')
            if not path.endswith('.py'):
                continue
            blob = meta.split()[2]
            if blob not in blob_cache:
                blob_cache[blob] = sha(git('cat-file','blob',blob))
            source[path.removeprefix('src/finpanel/')] = blob_cache[blob]
        scans.append({'commit':commit,'code_sha256':digest(source),'python_files':len(source)})
    wheels = []
    for path in sorted((ROOT/'output').rglob('finpanel-*.whl')):
        with zipfile.ZipFile(path) as z:
            source = {name.removeprefix('finpanel/'):sha(z.read(name)) for name in z.namelist()
                      if name.startswith('finpanel/') and name.endswith('.py')}
        wheels.append({'path':str(path.relative_to(ROOT)), 'sha256':sha(path.read_bytes()),
                       'code_sha256':digest(source),'python_files':len(source)})
    wheelhouse = [{'path':str(p.relative_to(ROOT)),'sha256':sha(p.read_bytes())}
                  for p in sorted((ROOT/'output/wp7/wheelhouse').glob('*.whl'))]
    out = {'format':'finpanel-paper-historical-recovery-v1', 'date':'2026-10-10',
           'historical_software':report['software'],'git_scan':scans,'wheel_scan':wheels,
           'matching_commits':[s['commit'] for s in scans if s['code_sha256']==TARGET],
           'matching_wheels':[w['path'] for w in wheels if w['code_sha256']==TARGET],
           'wheelhouse':wheelhouse,
           'meaning':'Exact Python-source fingerprint and receipt-compatible runtime; original full working tree and complete original OS environment are not uniquely identified.'}
    if args.prepare_environment:
        env = args.prepare_environment.resolve()
        if env.exists():
            raise SystemExit('Environment destination exists; choose a fresh path.')
        wheel = ROOT/'output/wp7/dist/finpanel-0.1.0a1-py3-none-any.whl'
        assert str(wheel.relative_to(ROOT)) in out['matching_wheels']
        subprocess.run([sys.executable,'-m','venv',str(env)],check=True)
        python = env/('Scripts/python.exe' if sys.platform=='win32' else 'bin/python')
        subprocess.run([str(python),'-m','pip','install','--no-index','--find-links',
                        str(ROOT/'output/wp7/wheelhouse'),str(wheel)],check=True)
        code = ('import json,platform,importlib.metadata; from finpanel.snapshots.pipeline import software_identity; '
                'print(json.dumps({"software":software_identity(),"platform":platform.platform(),'
                '"packages":{d.metadata["Name"]:d.version for d in importlib.metadata.distributions()}},sort_keys=True))')
        result = json.loads(subprocess.check_output([str(python),'-c',code],cwd=ROOT))
        assert result['software']==report['software'],result
        out['prepared_environment'] = str(env.relative_to(ROOT))
        out['environment'] = result
        out['receipt_software_identity_matches'] = True
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k in ('matching_commits','matching_wheels','receipt_software_identity_matches')},indent=2))


if __name__=='__main__':
    main()
