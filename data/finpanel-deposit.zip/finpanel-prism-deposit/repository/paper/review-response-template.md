# Reviewer comments and author responses

Template only. No reviewer comments, agreement, editorial handling or human approval are implied by empty fields. Preserve reviewers’ actual wording and identities according to the venue’s process. Do not fill this template with simulated reviewer approval.

## Review record

| Field | Entry |
|---|---|
| Review round / review date | |
| Manuscript filename, date and SHA-256 before review | |
| Evidence-manifest filename and SHA-256 | |
| Reviewer identifier, expertise and declared interests, if supplied | |
| Review scope: editorial / accounting cases / source sample / public example / full archive / other | |
| Inputs actually available; important unavailable inputs | |
| Author responding; response date | |
| Revised manuscript filename and SHA-256 | |
| Venue/editor instructions, if actually supplied | |

Do not call a review independent merely because it uses this template. Record the reviewer’s relationship to the author/project and let the relevant human/editor determine how to characterize the review.

## Comment register

| ID | Reviewer comment or faithful summary | Claim / figure / case | Type and severity | Owner | Author action | Reviewer disposition |
|---|---|---|---|---|---|---|
| | | | | | | |

Suggested types: factual error; missing evidence; accounting interpretation; reproducibility/access; scope/wording; citation; venue format/disclosure; optional research extension. Separate “needed to support a present claim” from “needed only for a proposed stronger claim.” Suggested dispositions: open; author response supplied; partly resolved; reviewer agrees resolved; unresolved disagreement; outside agreed scope. “Author response supplied” is not “reviewer agrees resolved.”

## Detailed response — copy for each comment

### Comment ID

**Reviewer’s actual comment:**

**Exact target:** manuscript version/hash, section/paragraph, figure, claim ID or sample ID; full request key where relevant.

**Evidence examined:**

| Artifact or source | Version / hash / accession | Exact pointer, page, context or test | What it supports | What it cannot establish |
|---|---|---|---|---|
| | | | | |

**Evidence unavailable or not examined:**

**Reviewer’s reasoning and expected result:** Include units, fiscal boundaries, eligibility dates, revision assumptions and arithmetic where relevant. Distinguish an incorrect computation from an inadequate accounting contract or insufficient evidence.

**Author’s position:** agree / partly agree / disagree / uncertain. Explain the position with evidence. Do not rely on test count, authority, a hash or the assistant’s judgment as a substitute for the disputed accounting inference.

**Action:** correct factual statement / narrow claim / add limitation / fix reference or denominator / retain with justification / request specified evidence / propose optional study / other.

**Exact manuscript change:**

- Before, with section and version:
- After, with section and version:
- Related changes to abstract, caption, conclusion, evidence matrix, author guide or open items:

**Checks actually performed after the change:** Record command/procedure, environment, dated output path and result. Mark proposed checks as proposed. Never overwrite old receipts or validation logs to make them match a revised interpretation.

**Unresolved disagreement:** State each side’s remaining position fairly; identify the missing discriminator and the effect on the current claim. If no new evidence is available, consider qualification or removal rather than inventing consensus.

**Reviewer follow-up:** date, actual reply and disposition. Leave blank until received.

**Editor’s decision, if supplied:** date and exact scope. An author cannot fill this with an assumed acceptance, recusal or publication decision.

## Accounting-case outcome summary

| Case/sample ID | Contract execution: agree/disagree/uncertain/not assessed | Accounting adequacy: agree/disagree/uncertain/not assessed | Missing evidence | Author change | Remaining reviewer concern |
|---|---|---|---|---|---|
| | | | | | |

Report counts only over cases actually assessed, separately identifying the proposed, accessible and completed sets. Repeated policy rows are not independent events. The 20-pair purposive proposal does not support population accuracy estimates, even if every reviewed case receives agreement. Do not recode uncertainty as agreement or omit inaccessible cases from the narrative.

## Round closeout

- Substantive factual issues corrected and their evidence:
- Present claims narrowed or removed:
- Disagreements still unresolved and their impact:
- Optional extensions declined or deferred, with reason:
- Venue-dependent requirements still pending:
- Author/editor facts and disclosures still awaiting confirmation:
- Human author’s confirmation of claim ownership, if actually given:
- Next review scope/access arrangement, if authorized:

Final disposition is for the responsible humans. This template records decisions; it does not certify publication readiness.
