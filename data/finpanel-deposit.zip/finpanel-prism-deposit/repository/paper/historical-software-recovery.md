# Historical software recovery

**Result: the fingerprint-covered historical Python sources and a receipt-compatible environment were recovered.** The original complete working tree and operating-system environment cannot be uniquely inferred. No historical result was relabeled and no archived evidence was rewritten.

## Identity and evidence

The archived benchmark's `docs/release-scale-validation.json:/software` records FinPanel 0.1.0a1, Python 3.12.14, httpx 0.28.1, simplejson 4.2.0, and code SHA-256:

`c3756cfba783ccd3d11df39f3a8f24fdeb47cf6edf75876f3cc8369ec090e0ad`

The current inspected commit is `28dcecce208a578b4a7b507bbf6d93018b4ab1d6`, version 0.1.0a2, code SHA-256 `abe3e1ec8d995516229d3be0a404ac189c186bdb8daefc7d530da2065fbe8408`. These identities remain separate.

`paper/scripts/recover_history.py` scanned all 18 locally reachable/reflog commits and local FinPanel wheels. It uses the package's fingerprint rule: hash each Python file's raw bytes, map package-relative paths to hashes, serialize with sorted keys, two-space indentation, unescaped Unicode and a terminal newline, then hash that serialization. Each matching tree contains 63 Python files. Exact matches occur at:

- `ce97d41378f2a11db711023db1aa8caf9978d054`
- `436e896e970a4cf4ea59ef140d16312d2d4f223b`
- `30ffbbe658fbc517ec838ba499859ec05093283b`
- `07f3e16fcf18019b16e5ac25d575e646d126c570`

The saved `output/wp7/dist/finpanel-0.1.0a1-py3-none-any.whl` has the same Python-source fingerprint. Five other saved wheel copies also match. Full wheel-byte hashes, every scanned commit, dependency-wheel hashes and installed package versions are in `paper/reviewer-runs/historical-recovery.json`. Different full repository commits can contain identical fingerprint-covered code; the receipt does not identify which complete checkout, documentation tree or uncommitted state produced the original run. A source-hash match is therefore not proof of a unique original commit.

## Executed recovery

From the repository root, the following was executed with a previously nonexistent environment/output destination:

```sh
.venv/bin/python paper/scripts/recover_history.py --output paper/reviewer-runs/historical-recovery.json --prepare-environment output/paper-review-20261010/historical-env
```

Installation used only the saved a1 wheel and `output/wp7/wheelhouse`, with `pip --no-index`. Python was 3.12.14. The resulting `software_identity()` exactly equals the historical report's complete recorded software object. The reconstructed platform was macOS 26.5 ARM64. This is an observed reconstruction environment, not proof of the original benchmark's complete machine state. The wheelhouse includes platform-specific Python 3.12 macOS ARM64 wheels; it is not a cross-platform distribution.

A bounded offline replay then executed:

```sh
output/paper-review-20261010/historical-env/bin/python paper/scripts/replay_historical.py --output paper/reviewer-runs/historical-smoke-replay.json
```

It selected `output/wp7/broad-shard-0/0000001800/first_reported/receipt.json`, recomputed 120 rows, and reproduced receipt ID `1434ff6c8b197a77b3ff6a92cd81568e489322983564ddc5b181484a9abfe576`. The input receipt's bytes remained unchanged. See the JSON and corresponding log. This is one newly executed replay, not 200 new replays. The 200-success count in the manuscript remains an archived benchmark result.

## Recoverable scope and remaining uncertainty

The historical Python implementation is available in Git and a preserved installable wheel; replay need no longer be described as blocked by unidentified Python code. A compatible recorded runtime is demonstrated for one authentic panel. No replacement benchmark is needed merely to repair that identification gap.

The identity function omits non-Python package data from its source hash and does not lock every dependency, timezone database, OS library, or export engine. The preserved wheel supplies non-Python assets for the executed reconstruction, but the receipt alone cannot certify their complete historical identity. Recovering the fingerprint is weaker than recovering a hermetic original machine. Whole-wheel and dependency hashes now make the local reconstruction inspectable.

Full financial recomputation of all 200 archived panels, the original invariant suite, source-verification queries and mutation experiment were not newly executed. A compatible environment and one replay increase confidence in the access path without establishing independent replication. The full corpus and wheels remain local; author-approved reviewer access and long-term distribution remain open.

## Repeat without overwriting records

Use the commands in `reproducibility.md` with fresh output names. The recovery and replay programs refuse an existing result destination. To inspect a complete candidate source tree separately, create a fresh directory and extract `git archive ce97d41378f2a11db711023db1aa8caf9978d054` there. Do not check out that commit over the current working tree or describe it as the uniquely proven original benchmark checkout.
