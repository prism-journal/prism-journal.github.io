# Exact numerical companions to Figures 1–4

Counts are exact; CSV percentage columns retain ten decimal places. These are descriptive request counts, not accuracy estimates. Population definitions and verification records accompany the paper supplement. The manuscript uses figures instead of duplicating these tables.

## figure-1-states.csv

| state | cells | denominator | percent |
| --- | --- | --- | --- |
| resolved_reported | 14136 | 24000 | 58.9000000000 |
| resolved_derived | 2570 | 24000 | 10.7083333333 |
| unavailable | 4108 | 24000 | 17.1166666667 |
| ambiguous_period | 1502 | 24000 | 6.2583333333 |
| insufficient_evidence | 1336 | 24000 | 5.5666666667 |
| conflicted | 312 | 24000 | 1.3000000000 |
| unsupported | 36 | 24000 | 0.1500000000 |
| source_verification_failed | 0 | 24000 | 0.0000000000 |

## figure-2-metrics.csv

| metric | reported | derived | unresolved | resolved | denominator | coverage_percent |
| --- | --- | --- | --- | --- | --- | --- |
| assets | 3480 | 0 | 520 | 3480 | 4000 | 87.0000000000 |
| cash_and_cash_equivalents | 3050 | 0 | 950 | 3050 | 4000 | 76.2500000000 |
| liabilities | 2088 | 0 | 1912 | 2088 | 4000 | 52.2000000000 |
| net_income | 2246 | 478 | 1276 | 2724 | 4000 | 68.1000000000 |
| operating_cash_flow | 1246 | 1664 | 1090 | 2910 | 4000 | 72.7500000000 |
| revenue | 2026 | 428 | 1546 | 2454 | 4000 | 61.3500000000 |

## figure-3-summary.csv

| measure | count | denominator | percent |
| --- | --- | --- | --- |
| same_state | 11972 | 12000 | 99.7666666667 |
| changed_state | 28 | 12000 | 0.2333333333 |
| lost_scalar | 28 | 12000 | 0.2333333333 |
| gained_scalar | 0 | 12000 | 0.0000000000 |
| both_resolved | 8339 | 12000 | 69.4916666667 |
| changed_value_among_both_resolved | 146 | 8339 | 1.7508094496 |
| unchanged_value_among_both_resolved | 8193 | 8339 | 98.2491905504 |

## figure-3-transitions.csv

| first_state | latest_state | pairs | denominator | percent_of_all_pairs |
| --- | --- | --- | --- | --- |
| resolved_reported | resolved_reported | 7068 | 12000 | 58.9000000000 |
| resolved_reported | resolved_derived | 0 | 12000 | 0.0000000000 |
| resolved_reported | unavailable | 0 | 12000 | 0.0000000000 |
| resolved_reported | ambiguous_period | 0 | 12000 | 0.0000000000 |
| resolved_reported | insufficient_evidence | 0 | 12000 | 0.0000000000 |
| resolved_reported | conflicted | 0 | 12000 | 0.0000000000 |
| resolved_reported | unsupported | 0 | 12000 | 0.0000000000 |
| resolved_reported | source_verification_failed | 0 | 12000 | 0.0000000000 |
| resolved_derived | resolved_reported | 0 | 12000 | 0.0000000000 |
| resolved_derived | resolved_derived | 1271 | 12000 | 10.5916666667 |
| resolved_derived | unavailable | 0 | 12000 | 0.0000000000 |
| resolved_derived | ambiguous_period | 0 | 12000 | 0.0000000000 |
| resolved_derived | insufficient_evidence | 0 | 12000 | 0.0000000000 |
| resolved_derived | conflicted | 28 | 12000 | 0.2333333333 |
| resolved_derived | unsupported | 0 | 12000 | 0.0000000000 |
| resolved_derived | source_verification_failed | 0 | 12000 | 0.0000000000 |
| unavailable | resolved_reported | 0 | 12000 | 0.0000000000 |
| unavailable | resolved_derived | 0 | 12000 | 0.0000000000 |
| unavailable | unavailable | 2054 | 12000 | 17.1166666667 |
| unavailable | ambiguous_period | 0 | 12000 | 0.0000000000 |
| unavailable | insufficient_evidence | 0 | 12000 | 0.0000000000 |
| unavailable | conflicted | 0 | 12000 | 0.0000000000 |
| unavailable | unsupported | 0 | 12000 | 0.0000000000 |
| unavailable | source_verification_failed | 0 | 12000 | 0.0000000000 |
| ambiguous_period | resolved_reported | 0 | 12000 | 0.0000000000 |
| ambiguous_period | resolved_derived | 0 | 12000 | 0.0000000000 |
| ambiguous_period | unavailable | 0 | 12000 | 0.0000000000 |
| ambiguous_period | ambiguous_period | 751 | 12000 | 6.2583333333 |
| ambiguous_period | insufficient_evidence | 0 | 12000 | 0.0000000000 |
| ambiguous_period | conflicted | 0 | 12000 | 0.0000000000 |
| ambiguous_period | unsupported | 0 | 12000 | 0.0000000000 |
| ambiguous_period | source_verification_failed | 0 | 12000 | 0.0000000000 |
| insufficient_evidence | resolved_reported | 0 | 12000 | 0.0000000000 |
| insufficient_evidence | resolved_derived | 0 | 12000 | 0.0000000000 |
| insufficient_evidence | unavailable | 0 | 12000 | 0.0000000000 |
| insufficient_evidence | ambiguous_period | 0 | 12000 | 0.0000000000 |
| insufficient_evidence | insufficient_evidence | 668 | 12000 | 5.5666666667 |
| insufficient_evidence | conflicted | 0 | 12000 | 0.0000000000 |
| insufficient_evidence | unsupported | 0 | 12000 | 0.0000000000 |
| insufficient_evidence | source_verification_failed | 0 | 12000 | 0.0000000000 |
| conflicted | resolved_reported | 0 | 12000 | 0.0000000000 |
| conflicted | resolved_derived | 0 | 12000 | 0.0000000000 |
| conflicted | unavailable | 0 | 12000 | 0.0000000000 |
| conflicted | ambiguous_period | 0 | 12000 | 0.0000000000 |
| conflicted | insufficient_evidence | 0 | 12000 | 0.0000000000 |
| conflicted | conflicted | 142 | 12000 | 1.1833333333 |
| conflicted | unsupported | 0 | 12000 | 0.0000000000 |
| conflicted | source_verification_failed | 0 | 12000 | 0.0000000000 |
| unsupported | resolved_reported | 0 | 12000 | 0.0000000000 |
| unsupported | resolved_derived | 0 | 12000 | 0.0000000000 |
| unsupported | unavailable | 0 | 12000 | 0.0000000000 |
| unsupported | ambiguous_period | 0 | 12000 | 0.0000000000 |
| unsupported | insufficient_evidence | 0 | 12000 | 0.0000000000 |
| unsupported | conflicted | 0 | 12000 | 0.0000000000 |
| unsupported | unsupported | 18 | 12000 | 0.1500000000 |
| unsupported | source_verification_failed | 0 | 12000 | 0.0000000000 |
| source_verification_failed | resolved_reported | 0 | 12000 | 0.0000000000 |
| source_verification_failed | resolved_derived | 0 | 12000 | 0.0000000000 |
| source_verification_failed | unavailable | 0 | 12000 | 0.0000000000 |
| source_verification_failed | ambiguous_period | 0 | 12000 | 0.0000000000 |
| source_verification_failed | insufficient_evidence | 0 | 12000 | 0.0000000000 |
| source_verification_failed | conflicted | 0 | 12000 | 0.0000000000 |
| source_verification_failed | unsupported | 0 | 12000 | 0.0000000000 |
| source_verification_failed | source_verification_failed | 0 | 12000 | 0.0000000000 |

## figure-4-metric-period.csv

| metric | period | reported | derived | resolved | unresolved | denominator | coverage_percent |
| --- | --- | --- | --- | --- | --- | --- | --- |
| assets | FY | 622 | 0 | 622 | 178 | 800 | 77.7500000000 |
| assets | Q1 | 792 | 0 | 792 | 8 | 800 | 99.0000000000 |
| assets | Q2 | 786 | 0 | 786 | 14 | 800 | 98.2500000000 |
| assets | Q3 | 658 | 0 | 658 | 142 | 800 | 82.2500000000 |
| assets | Q4 | 622 | 0 | 622 | 178 | 800 | 77.7500000000 |
| cash_and_cash_equivalents | FY | 546 | 0 | 546 | 254 | 800 | 68.2500000000 |
| cash_and_cash_equivalents | Q1 | 692 | 0 | 692 | 108 | 800 | 86.5000000000 |
| cash_and_cash_equivalents | Q2 | 688 | 0 | 688 | 112 | 800 | 86.0000000000 |
| cash_and_cash_equivalents | Q3 | 578 | 0 | 578 | 222 | 800 | 72.2500000000 |
| cash_and_cash_equivalents | Q4 | 546 | 0 | 546 | 254 | 800 | 68.2500000000 |
| liabilities | FY | 372 | 0 | 372 | 428 | 800 | 46.5000000000 |
| liabilities | Q1 | 472 | 0 | 472 | 328 | 800 | 59.0000000000 |
| liabilities | Q2 | 476 | 0 | 476 | 324 | 800 | 59.5000000000 |
| liabilities | Q3 | 396 | 0 | 396 | 404 | 800 | 49.5000000000 |
| liabilities | Q4 | 372 | 0 | 372 | 428 | 800 | 46.5000000000 |
| net_income | FY | 560 | 0 | 560 | 240 | 800 | 70.0000000000 |
| net_income | Q1 | 550 | 0 | 550 | 250 | 800 | 68.7500000000 |
| net_income | Q2 | 540 | 0 | 540 | 260 | 800 | 67.5000000000 |
| net_income | Q3 | 548 | 0 | 548 | 252 | 800 | 68.5000000000 |
| net_income | Q4 | 48 | 478 | 526 | 274 | 800 | 65.7500000000 |
| operating_cash_flow | FY | 600 | 0 | 600 | 200 | 800 | 75.0000000000 |
| operating_cash_flow | Q1 | 590 | 0 | 590 | 210 | 800 | 73.7500000000 |
| operating_cash_flow | Q2 | 28 | 540 | 568 | 232 | 800 | 71.0000000000 |
| operating_cash_flow | Q3 | 28 | 544 | 572 | 228 | 800 | 71.5000000000 |
| operating_cash_flow | Q4 | 0 | 580 | 580 | 220 | 800 | 72.5000000000 |
| revenue | FY | 470 | 0 | 470 | 330 | 800 | 58.7500000000 |
| revenue | Q1 | 508 | 0 | 508 | 292 | 800 | 63.5000000000 |
| revenue | Q2 | 500 | 0 | 500 | 300 | 800 | 62.5000000000 |
| revenue | Q3 | 514 | 0 | 514 | 286 | 800 | 64.2500000000 |
| revenue | Q4 | 34 | 428 | 462 | 338 | 800 | 57.7500000000 |
