# Related-work comparison and access boundary

As of 10 October 2026, a full-text comparison with the closely related Wang working paper is **not complete**. The contribution is positioned as a bounded implementation and evidence audit, without priority or superiority claims.

## Verified record and name

The [SSRN record](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=7183438) identifies *Point-In-Time Data Integrity in Quantitative Equity Research: A Reproducible Framework for Eliminating Look-Ahead Bias*, DOI `10.2139/ssrn.7183438`, written 20 June 2026 and posted 6 August 2026. Its suggested citation uses Xindi Wang, whereas its profile heading displays Arthur Wang. An indexed [first-person announcement on Xindi Wang's public profile](https://uk.linkedin.com/in/xindi-wang19990526) names the same paper. This corroborates using Xindi Wang in the bibliography; it does not establish why the SSRN heading differs. No assertion about an alias or legal identity is made.

Ordinary retrieval of the SSRN landing page, its PDF delivery endpoint and DOI destination returned HTTP 403 HTML, not a PDF; `reviewer-runs/literature-access.json` records the requests. Exact-title and institutional/author searches did not yield a full copy. No access controls were bypassed, author contacted, or full-text reading claimed. The profile announcement is bibliographic corroboration, not peer review or validation of results.

## Comparison by evidence level

Wang-column statements below are limited to the SSRN abstract. Unknown means unassessed, not absent. The FinPanel column is supported by the exact repository locators under the cited evidence-matrix IDs.

| Dimension | Wang: abstract-level evidence only | FinPanel: inspected artifact and evidence | Defensible implication |
|---|---|---|---|
| Research question | Timing-induced bias in quantitative equity research | RQ1–RQ3 concern eligibility, conservative decisions and replay; no return experiment (I01) | Related motivation; different evaluated scope here |
| Temporal semantics | Separate timing layers | Retrieval vintage distinguished from filing proxy; date-only exclusion; filter before calendar inference (C01–C04) | Broad overlap; detailed rule equivalence unknown |
| Revision handling | Revision preservation and quarter lineage | First/latest/all policies, explicit conflict, shared-filing guard for revised operands (C05, C08–C11, K05–K06) | Cannot claim Wang lacks these guards |
| Provenance | Parent lineage | Raw hashes, pointers, filing accessions and derivation operands (C14) | Common objective; schema equivalence unknown |
| Reproducibility | Experiment manifests | Snapshot-bound receipts, fail-closed semantic replay, recovered a1 runtime and one fresh replay (C15–C17, A06–A07) | No inference about Wang's replay implementation |
| Implementation | Detailed code availability unassessed | Bounded a2 commit, inspectable tests, archived a1 Python fingerprint (A01–A04, A06) | Available evidence differs; quality ranking unsupported |
| Evaluation | Detailed protocol unassessed | Archived purposive grid, current tests, descriptive matched-policy recount; no external adjudication or baseline experiment (N01–N18) | No numerical or superiority comparison justified |

## Broader foundations

Temporal database valid/transaction time provides vocabulary (Jensen et al., E04), not proof that a recent SEC capture reconstructs historical upstream delivery. SEC API documentation and XBRL context semantics explain the source-specific timing and accounting-context constraints (E01–E02). PROV and FAIR motivate traceable transformations and reusable metadata without establishing conformance certification (E05–E06). The National Academies' reproducibility distinction supports separating same-input replay from independent research confirmation (E07). Banz and Breen's publisher abstract motivates concern about dataset construction; its portfolio results are not imported as a FinPanel effect estimate (E03).

## Contribution that survives skeptical comparison

FinPanel operationalizes an evidence-bearing decision—including refusal—as the reproducible object. The paper makes those contracts inspectable through a fixed implementation, authentic difficult cases, a recount of preserved results and executable replay instructions. It does not claim to invent timing layers, provenance, quarter arithmetic or manifests. A full-text review may further narrow the contribution. Before stronger novelty language, examine Wang's algorithms, timing contracts, revision pairing, source and code access, evaluation protocol and limitations using page/section locators from an actually obtained copy. No invented page references are supplied here.


## Consequence for review readiness

The present narrow contribution remains defensible for review without a detailed full-text comparison: its claim is to document and audit this identifiable implementation, not establish priority, feature uniqueness, comparative superiority or an exhaustive literature survey. This is a reasoned editorial assessment, not proof of originality. The available overlap is acknowledged, the access failure is disclosed, and no unexamined Wang method is characterized as absent.

An editor can assess whether that contribution fits the intended article type while the access limitation remains. If a venue requires full comparison, or if the author wants a stronger novelty claim, obtaining and reading the text becomes necessary for that claim or submission. Any relevant full text later received should be evaluated before final publication decisions. No additional access attempt, author contact or new literature experiment was undertaken in this editorial pass.
