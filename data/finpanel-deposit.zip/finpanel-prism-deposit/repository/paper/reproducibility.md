# Reviewer reproducibility package

Status: executable local instructions, a recovered historical runtime, checked archived bytes, four rendered figures, and two bounded replay examples. **Ready for author review and scoped external editorial assessment.** This is not an independent accounting review or a public corpus release.

All commands below run from the repository root. Use Python **3.12.14** for receipt-compatible execution. Use fresh output destinations; audit/recovery/replay scripts and the public example refuse existing results. Never point new output at `output/wp7`, `docs`, or existing audit records. Do not run Python with `-O`: audit assertions are intentional verification gates.

## Environment boundaries

For the compact editorial ZIP, start with `review-package-readme.md`. It can rebuild the review PDF from Markdown and BibTeX using `typesetting/README.md`; it deliberately omits the local raw corpus, historical wheels and full local inventory. The historical commands below require those separately authorized inputs. The PDF build is a separate document environment and does not rerun FinPanel experiments.

| Purpose | Version / identity | Local interpreter actually used |
|---|---|---|
| Current example, supplementary audit and figure extraction | a2, commit `28dcecce208a578b4a7b507bbf6d93018b4ab1d6`; fingerprint `abe3e1ec8d995516229d3be0a404ac189c186bdb8daefc7d530da2065fbe8408` | `.venv/bin/python` |
| Historical panel replay | a1; fingerprint `c3756cfba783ccd3d11df39f3a8f24fdeb47cf6edf75876f3cc8369ec090e0ad` | `output/paper-review-20261010/historical-env/bin/python` |
| Figures only | Python 3.12.14, Matplotlib 3.11.2, NumPy 2.5.3 | `output/paper-review-20261010/plot-env/bin/python` |

`historical-software-recovery.md` explains why four Git commits match the historical Python fingerprint without identifying a unique original whole checkout. Current runtime pins are in `scripts/current-runtime-requirements.txt`; observed historical packages and available wheel hashes are in `reviewer-runs/historical-recovery.json`; plotting dependencies are in `scripts/plot-requirements.txt`. These are reconstruction records, not a claim of a completely archived original OS.

## 1. Small offline example

With the existing current interpreter:

```sh
.venv/bin/python -m finpanel.example output/reviewer-public-example
```

This imports bundled authentic fixture bytes, builds six HRB FY2022 metric requests at 2022-08-17T12:00:00Z, exports CSV/Parquet/DuckDB and provenance, and verifies semantic replay without SEC access or credentials. The executed run used `output/paper-review-20261010/public-example`; its summary and receipt are included in `reviewer-manifest.json` and log in `reviewer-runs/public-example.log`. Expected under the observed environment: six cells, three resolved reported, three ambiguous-period, replay true, snapshot `d876a6da085adb10addacfed0a861e79136d8142eb6fd4775f6af48c8e0b7c01`, receipt `c974c0ab1afe53765c2049ecfa140930ed83f903cd994ae626213a0872d5bd50`.

For a separately provisioned current environment in a fresh checkout at the stated commit, the following is a setup recipe; it was not a second executed replication:

```sh
python3.12 -m venv output/reviewer-current-env
output/reviewer-current-env/bin/python -m pip install -r paper/scripts/current-runtime-requirements.txt
output/reviewer-current-env/bin/python -m pip install --no-deps .
output/reviewer-current-env/bin/python -m finpanel.example output/reviewer-public-example
```

Verify that `python3.12 --version` is 3.12.14 first. Package installation may require network access and a build backend; the example execution itself is offline. This recipe installs from the current source, not a1. On Windows substitute the virtual environment's `Scripts/python.exe`. Cross-platform execution has not been freshly demonstrated in this paper audit. Container bytes can differ; the expected criterion is represented semantics and receipt compatibility.

## 2. Supplementary archive audit

Required local artifacts: both complete `output/wp7/broad-shard-{0,1}` trees, the selected broad-corpus snapshot and raw objects, checked-in reports, fixture manifests and frozen fixture bytes, and golden ledgers.

```sh
.venv/bin/python paper/audit/verify_evidence.py --output paper/reviewer-runs/reviewer-verification.json
```

The executed revision is `reviewer-runs/verification-v2.json` with its log. It recounts 24,000 cells, rehashes 900 checkpoint-listed output files and 406 raw artifacts, checks 96 compressed/raw fixture pairs and 255 ledger expectations, and verifies report and semantic hashes. It does not rerun the benchmark's financial resolver, original-source verification or mutation transformations. The older `audit/verification.json` and regression log remain preserved. Current regression previously passed 814 tests; no unchanged full suite was rerun solely for figure editing.

## 3. Regenerate every figure and numerical companion table

```sh
.venv/bin/python paper/scripts/extract_figure_data.py
.venv/bin/python paper/scripts/render_tables.py
python3.12 -m venv output/reviewer-plot-env
output/reviewer-plot-env/bin/python -m pip install -r paper/scripts/plot-requirements.txt
output/reviewer-plot-env/bin/python paper/scripts/plot_figures.py
```

Use a new environment path, or reuse the already prepared plotting interpreter for the final command. Extraction needs the archived checkpoints/reports/receipts and snapshot manifest; table rendering needs the companion CSVs. Plotting additionally reads `figure-data/extraction-manifest.json` and hashes the extraction/plot scripts; keep the paper supplement’s relative layout intact. It does not reopen the raw corpus for plotting. These programs intentionally replace **derived paper figure data/images**, never archived evidence.

`figure-data/tables.md` is a generated accessible numerical companion. The manuscript uses Figures 1–4 instead of duplicating those tables. Conceptual comparison tables and the evidence matrix are edited prose, not additional experimental datasets. Figure 3's 12,000 joins use CIK, metric, fiscal year, period and cutoff. Its 146 numerical changes use the distinct denominator 8,339 jointly resolved pairs. The 64-cell CSV transition matrix retains the all-zero eighth state omitted from the visual.

Each figure has SVG and 400-DPI PNG exports at 7.2-inch width. Exact CSV counts, percentage denominators, source-file hashes, script hashes, package versions and output hashes are in `figure-manifest.json`. SVG timestamps are removed and the SVG hash seed fixed. Identical regeneration was checked in the observed plotting environment; other font/rendering/library environments can change image bytes. Semantic data equality is the portable criterion. No confidence intervals are drawn for this dependent purposive grid.

## 4. Recover and replay historical software

The saved wheelhouse is local-only and includes native macOS ARM64 Python 3.12 wheels. This route cannot be presumed portable to other platforms. Use fresh destinations:

```sh
.venv/bin/python paper/scripts/recover_history.py --output paper/reviewer-runs/reviewer-recovery.json --prepare-environment output/reviewer-historical-env
output/reviewer-historical-env/bin/python paper/scripts/replay_historical.py --output paper/reviewer-runs/reviewer-smoke-replay.json
```

The preparation installs from local wheels with `--no-index`, checks the package's complete recorded software identity, and records installed versions. The executed recovery and smoke replay are documented in `historical-software-recovery.md`. The default replay performs only the first of 200 preserved panel receipts: 120 rows. It reads a pinned evidence store and verifies receipt identity without acquisition or archived-output writes.

To replay every archived panel, the following is an **optional, potentially expensive command, not newly executed for this revision**:

```sh
output/reviewer-historical-env/bin/python paper/scripts/replay_historical.py --all --output paper/reviewer-runs/reviewer-all-replays.json
```

This recomputes the financial semantics of 200 panels totaling 24,000 rows. It does not recreate the original validation job's invariant instrumentation, mutation experiment, source-verification queries, resource timings or completed-job resume. Those experiments remain separately archived evidence. `--limit N` supports intermediate bounded checks. `--archive-root PATH` and `--store PATH` can select an authorized copy of the archived receipt trees and evidence store. The current audit and extraction scripts expect the original repository-relative layout.

If the wheel archive is unavailable, inspect a Git tree with the matching Python fingerprint using a separate extraction directory:

```sh
mkdir -p output/reviewer-a1-source
git archive ce97d41378f2a11db711023db1aa8caf9978d054 | tar -x -C output/reviewer-a1-source
```

Use an empty destination. A source installation with explicitly reconstructed dependency versions is an alternative procedure, **not the executed wheel recovery**. Verify its software identity before replay. Building on another platform may need different wheel bytes; a matching fingerprint still does not certify a full original OS reconstruction.

## 5. Manifests, access and limitations

`reviewer-manifest.json` records paper scripts/records, public-example receipt and summary, selected snapshot manifest, reports/checkpoints/receipts, all checkpoint-listed output files, raw object hashes and sizes, available historical wheels and dependency wheels. `scripts/build_reviewer_manifest.py` regenerates it and checks input hashes. `scripts/check_reviewer_manifest.py` verifies a saved manifest without modifying it. Run from the repository root:

```sh
.venv/bin/python paper/scripts/build_reviewer_manifest.py
.venv/bin/python paper/scripts/check_reviewer_manifest.py
```

The large corpus and saved wheels are ignored local artifacts; neither hashes nor a public Git clone supplies their bytes. Reviewer access, redistribution permissions, storage location and a stable archival identifier require author decisions. No corpus was uploaded or published. Bundled example data can exercise the public interface but cannot substitute for the large experiment. Missing local objects should cause a visible failure, never silent reacquisition from today's SEC endpoints.

The closest Wang paper's full text remains unavailable to this audit; acquisition attempts and a restrained comparison are documented separately. Internal goldens, byte integrity and replay do not replace independent accounting adjudication. The reviewer-guide.md separates editorial assessment, public-example inspection and local-corpus review. Author endorsement and venue decisions remain pending; preparing this package does not establish independent validation or certify publication readiness.
